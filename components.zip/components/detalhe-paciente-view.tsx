"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Calendar, Phone, Mail, MapPin, User, CreditCard, Clock, Plus, Edit, Eye } from "lucide-react"
import Link from "next/link"
import { AgendarConsultaDialog } from "@/components/agendar-consulta-dialog"
import { DetalheConsultaDialog } from "@/components/detalhe-consulta-dialog"
import type { Paciente, Usuario } from "@/types/database.types"

interface Consulta {
  id: string
  data_hora: string
  data_fim: string | null
  valor: number | null
  status: string
  status_pagamento: string
  observacoes: string | null
  tipos_consulta: {
    nome: string
    cor: string
    valor_padrao: number | null
  } | null
}

interface TipoConsulta {
  id: string
  nome: string
  valor_padrao: number | null
  duracao: number
  cor: string
}

interface DetalhePacienteViewProps {
  paciente: Paciente
  consultas: Consulta[]
  tiposConsulta: TipoConsulta[]
  usuario: Usuario
}

export function DetalhePacienteView({ paciente, consultas, tiposConsulta, usuario }: DetalhePacienteViewProps) {
  const [showAgendarDialog, setShowAgendarDialog] = useState(false)
  const [showDetalheConsulta, setShowDetalheConsulta] = useState(false)
  const [consultaSelecionada, setConsultaSelecionada] = useState<Consulta | null>(null)
  const router = useRouter()
  const { toast } = useToast()

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString("pt-BR")
  }

  const formatPhone = (phone: string | null) => {
    if (!phone) return "-"
    return phone.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
  }

  const formatCPF = (cpf: string | null) => {
    if (!cpf) return "-"
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmado":
        return "bg-green-100 text-green-800"
      case "agendado":
        return "bg-blue-100 text-blue-800"
      case "realizado":
        return "bg-gray-100 text-gray-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "pago":
        return "bg-green-100 text-green-800"
      case "pendente":
        return "bg-yellow-100 text-yellow-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleConsultaAgendada = () => {
    setShowAgendarDialog(false)
    toast({
      title: "Consulta agendada!",
      description: "A consulta foi agendada com sucesso.",
    })
    router.refresh()
  }

  const handleVerDetalheConsulta = (consulta: Consulta) => {
    setConsultaSelecionada(consulta)
    setShowDetalheConsulta(true)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" asChild>
            <Link href="/pacientes">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{paciente.nome}</h1>
            <p className="text-muted-foreground">Cadastrado em {formatDate(paciente.created_at)}</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => setShowAgendarDialog(true)}>
            <Calendar className="w-4 h-4 mr-2" />
            Agendar Consulta
          </Button>
          <Button variant="outline" asChild>
            <Link href={`/pacientes/${paciente.id}/editar`}>
              <Edit className="w-4 h-4 mr-2" />
              Editar
            </Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="dados" className="space-y-4">
        <TabsList>
          <TabsTrigger value="dados">Dados Pessoais</TabsTrigger>
          <TabsTrigger value="consultas">Consultas ({consultas.length})</TabsTrigger>
          <TabsTrigger value="prontuarios">Prontuários</TabsTrigger>
        </TabsList>

        <TabsContent value="dados" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Informações Pessoais */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="w-5 h-5 mr-2" />
                  Informações Pessoais
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Nome Completo</label>
                    <p className="text-sm">{paciente.nome}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">CPF</label>
                    <p className="text-sm">{formatCPF(paciente.cpf)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Data de Nascimento</label>
                    <p className="text-sm">{paciente.nascimento ? formatDate(paciente.nascimento) : "-"}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Gênero</label>
                    <p className="text-sm capitalize">{paciente.genero || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contato */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="w-5 h-5 mr-2" />
                  Contato
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Telefone</label>
                  <p className="text-sm flex items-center">
                    <Phone className="w-4 h-4 mr-2" />
                    {formatPhone(paciente.telefone)}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">E-mail</label>
                  <p className="text-sm flex items-center">
                    <Mail className="w-4 h-4 mr-2" />
                    {paciente.email || "-"}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Endereço */}
            {paciente.endereco && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="w-5 h-5 mr-2" />
                    Endereço
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm">
                    {paciente.endereco.logradouro && (
                      <p>
                        {paciente.endereco.logradouro}, {paciente.endereco.numero}
                      </p>
                    )}
                    {paciente.endereco.complemento && <p>{paciente.endereco.complemento}</p>}
                    {paciente.endereco.bairro && <p>{paciente.endereco.bairro}</p>}
                    {paciente.endereco.cidade && paciente.endereco.estado && (
                      <p>
                        {paciente.endereco.cidade} - {paciente.endereco.estado}
                      </p>
                    )}
                    {paciente.endereco.cep && <p>CEP: {paciente.endereco.cep}</p>}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Convênio */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="w-5 h-5 mr-2" />
                  Convênio
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Plano</label>
                  <div className="text-sm">
                    {paciente.convenio ? (
                      <Badge variant="secondary">{paciente.convenio}</Badge>
                    ) : (
                      <Badge variant="outline">Particular</Badge>
                    )}
                  </div>
                </div>
                {paciente.numero_convenio && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Número da Carteirinha</label>
                    <p className="text-sm">{paciente.numero_convenio}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Observações */}
          {paciente.observacoes && (
            <Card>
              <CardHeader>
                <CardTitle>Observações</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm whitespace-pre-wrap">{paciente.observacoes}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="consultas" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Histórico de Consultas</h3>
            <Button onClick={() => setShowAgendarDialog(true)} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Nova Consulta
            </Button>
          </div>

          {consultas.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">Nenhuma consulta agendada</p>
                <Button onClick={() => setShowAgendarDialog(true)} className="mt-4">
                  Agendar primeira consulta
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {consultas.map((consulta) => (
                <Card key={consulta.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-gray-500" />
                          <span className="font-medium">{formatDateTime(consulta.data_hora)}</span>
                        </div>
                        {consulta.tipos_consulta && (
                          <Badge
                            style={{
                              backgroundColor: consulta.tipos_consulta.cor + "20",
                              color: consulta.tipos_consulta.cor,
                              borderColor: consulta.tipos_consulta.cor,
                            }}
                            variant="outline"
                          >
                            {consulta.tipos_consulta.nome}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={getStatusColor(consulta.status)}>{consulta.status}</Badge>
                        <Badge className={getPaymentStatusColor(consulta.status_pagamento)}>
                          {consulta.status_pagamento}
                        </Badge>
                        {consulta.valor && (
                          <span className="text-sm font-medium">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(consulta.valor)}
                          </span>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => handleVerDetalheConsulta(consulta)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    {consulta.observacoes && <p className="text-sm text-gray-600 mt-2">{consulta.observacoes}</p>}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="prontuarios">
          <Card>
            <CardContent className="text-center py-8">
              <p className="text-gray-500">Funcionalidade de prontuários em desenvolvimento</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialog para agendar consulta */}
      <AgendarConsultaDialog
        open={showAgendarDialog}
        onOpenChange={setShowAgendarDialog}
        paciente={paciente}
        tiposConsulta={tiposConsulta}
        usuario={usuario}
        onConsultaAgendada={handleConsultaAgendada}
      />

      {/* Dialog para ver detalhes da consulta */}
      {consultaSelecionada && (
        <DetalheConsultaDialog
          open={showDetalheConsulta}
          onOpenChange={setShowDetalheConsulta}
          consulta={consultaSelecionada}
          paciente={paciente}
        />
      )}
    </div>
  )
}
