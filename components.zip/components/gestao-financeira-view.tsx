"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  DollarSign, 
  CreditCard, 
  CheckCircle, 
  AlertCircle, 
  TrendingUp,
  TrendingDown,
  Calendar,
  Download,
  Filter,
  Search,
  RefreshCw
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Pagamento {
  id: string
  valor: number
  status: string
  created_at: string
  data_pagamento?: string
  metodo_pagamento?: string
  usuario_id?: string
  usuario?: {
    nome: string
    email: string
  }
}

export default function GestaoFinanceiraView() {
  const [pagamentos, setPagamentos] = useState<Pagamento[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("todos")
  const [stats, setStats] = useState({
    totalReceita: 0,
    receitaMes: 0,
    pagamentosPendentes: 0,
    pagamentosPagos: 0,
    mediaTicket: 0
  })

  const supabase = createClient()

  useEffect(() => {
    carregarDadosFinanceiros()
  }, [])

  const carregarDadosFinanceiros = async () => {
    try {
      setLoading(true)

      // Buscar todos os pagamentos
      const { data: pagamentosData, error } = await supabase
        .from("pagamentos")
        .select(`
          *,
          usuario:usuarios(nome, email)
        `)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Erro ao buscar pagamentos:", error)
        return
      }

      setPagamentos(pagamentosData || [])

      // Calcular estatísticas
      const pagos = pagamentosData?.filter(p => p.status === "pago") || []
      const pendentes = pagamentosData?.filter(p => p.status === "pendente") || []
      
      const totalReceita = pagos.reduce((sum, p) => sum + Number(p.valor), 0)
      const receitaMes = pagos
        .filter(p => {
          const dataPagamento = new Date(p.data_pagamento || p.created_at)
          const hoje = new Date()
          return dataPagamento.getMonth() === hoje.getMonth() && 
                 dataPagamento.getFullYear() === hoje.getFullYear()
        })
        .reduce((sum, p) => sum + Number(p.valor), 0)

      setStats({
        totalReceita,
        receitaMes,
        pagamentosPendentes: pendentes.length,
        pagamentosPagos: pagos.length,
        mediaTicket: pagos.length > 0 ? totalReceita / pagos.length : 0
      })

    } catch (error) {
      console.error("Erro ao carregar dados financeiros:", error)
    } finally {
      setLoading(false)
    }
  }

  const filtrarPagamentos = () => {
    let filtrados = pagamentos

    // Filtro por busca
    if (searchTerm) {
      filtrados = filtrados.filter(pagamento =>
        pagamento.usuario?.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pagamento.usuario?.email?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filtro por status
    if (statusFilter !== "todos") {
      filtrados = filtrados.filter(pagamento => pagamento.status === statusFilter)
    }

    return filtrados
  }

  const exportarRelatorio = () => {
    const dados = filtrarPagamentos()
    const csvContent = [
      ["Cliente", "Email", "Valor", "Status", "Data Pagamento", "Método"],
      ...dados.map(pagamento => [
        pagamento.usuario?.nome || "N/A",
        pagamento.usuario?.email || "N/A",
        `R$ ${Number(pagamento.valor).toFixed(2)}`,
        pagamento.status,
        pagamento.data_pagamento ? format(new Date(pagamento.data_pagamento), "dd/MM/yyyy", { locale: ptBR }) : "-",
        pagamento.metodo_pagamento || "-"
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `relatorio-financeiro-${format(new Date(), "dd-MM-yyyy")}.csv`
    a.click()
  }

  const pagamentosFiltrados = filtrarPagamentos()

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando dados financeiros...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Gestão Financeira</h1>
        <p className="text-gray-600 mt-2">Controle completo de pagamentos e receita</p>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ {stats.totalReceita.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Toda a receita</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita do Mês</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">R$ {stats.receitaMes.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Este mês</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagamentos Pagos</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.pagamentosPagos}</div>
            <p className="text-xs text-muted-foreground">Confirmados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagamentos Pendentes</CardTitle>
            <AlertCircle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.pagamentosPendentes}</div>
            <p className="text-xs text-muted-foreground">Aguardando</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ticket Médio</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">R$ {stats.mediaTicket.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Por pagamento</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros e Ações</CardTitle>
          <CardDescription>Filtre e gerencie pagamentos</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por cliente..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-full md:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="pendente">Pendentes</SelectItem>
                  <SelectItem value="pago">Pagos</SelectItem>
                  <SelectItem value="cancelado">Cancelados</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={exportarRelatorio} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Exportar CSV
            </Button>
            <Button onClick={carregarDadosFinanceiros} variant="outline" className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Atualizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Pagamentos */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Pagamentos</CardTitle>
          <CardDescription>
            {pagamentosFiltrados.length} pagamento(s) encontrado(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Método</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pagamentosFiltrados.map((pagamento) => (
                  <TableRow key={pagamento.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{pagamento.usuario?.nome || "N/A"}</div>
                        <div className="text-sm text-gray-500">{pagamento.usuario?.email || "N/A"}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">R$ {Number(pagamento.valor).toFixed(2)}</div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          pagamento.status === "pago"
                            ? "default"
                            : pagamento.status === "pendente"
                            ? "secondary"
                            : "destructive"
                        }
                      >
                        {pagamento.status === "pago" && "✅ Pago"}
                        {pagamento.status === "pendente" && "⏳ Pendente"}
                        {pagamento.status === "cancelado" && "❌ Cancelado"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {pagamento.data_pagamento ? 
                        format(new Date(pagamento.data_pagamento), "dd/MM/yyyy", { locale: ptBR }) :
                        format(new Date(pagamento.created_at), "dd/MM/yyyy", { locale: ptBR })
                      }
                    </TableCell>
                    <TableCell>
                      {pagamento.metodo_pagamento || "N/A"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 