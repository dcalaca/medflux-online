"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { toast } from "sonner"
import { UserPlus, Users, Mail, Phone, Building, RefreshCw, Key, BarChart3, DollarSign, Lock, CreditCard } from "lucide-react"

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  ativo: boolean
  telefone?: string
  created_at: string
}

export function CadastroUsuariosView() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [loading, setLoading] = useState(true)
  const [showDialog, setShowDialog] = useState(false)
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
  })
  const [submitting, setSubmitting] = useState(false)
  const [emailStatus, setEmailStatus] = useState<{
    checking: boolean
    exists: boolean
    message: string
  }>({
    checking: false,
    exists: false,
    message: ""
  })

  const supabase = createClient()

  useEffect(() => {
    carregarUsuarios()
  }, [])

  // Verificar email em tempo real
  useEffect(() => {
    const checkEmail = async () => {
      if (!formData.email || formData.email.length < 3) {
        setEmailStatus({
          checking: false,
          exists: false,
          message: ""
        })
        return
      }

      setEmailStatus(prev => ({ ...prev, checking: true }))

      try {
        const response = await fetch("/api/verificar-email", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: formData.email }),
        })

        const result = await response.json()

        if (response.ok) {
          setEmailStatus({
            checking: false,
            exists: result.exists,
            message: result.message
          })
        } else {
          setEmailStatus({
            checking: false,
            exists: false,
            message: "Erro ao verificar email"
          })
        }
      } catch (error) {
        setEmailStatus({
          checking: false,
          exists: false,
          message: "Erro ao verificar email"
        })
      }
    }

    const timeoutId = setTimeout(checkEmail, 500)
    return () => clearTimeout(timeoutId)
  }, [formData.email])

  const carregarUsuarios = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // Buscar usuários da mesma clínica (apenas recepcionistas)
      const { data: usuarioData } = await supabase
        .from("usuarios")
        .select("clinica_id")
        .eq("id", user.id)
        .single()

      if (usuarioData?.clinica_id) {
        const { data, error } = await supabase
          .from("usuarios")
          .select("*")
          .eq("clinica_id", usuarioData.clinica_id)
          .eq("tipo", "recepcionista")
          .order("created_at", { ascending: false })

        if (error) throw error
        setUsuarios(data || [])
      }
    } catch (error) {
      console.error("Erro ao carregar usuários:", error)
      toast.error("Erro ao carregar usuários")
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      // Validações
      if (!formData.nome || !formData.email) {
        toast.error("Nome e email são obrigatórios")
        return
      }

      // Verificar novamente se o email não existe antes de cadastrar
      if (emailStatus.exists) {
        toast.error("Email já cadastrado. Por favor, use um email diferente.")
        return
      }

      // Chamar a API route para cadastrar o usuário
      const response = await fetch("/api/cadastrar-recepcionista-simples", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nome: formData.nome,
          email: formData.email,
          telefone: formData.telefone,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        const errorMessage = result.error || "Erro ao cadastrar usuário"
        const errorDetails = result.details ? ` - ${result.details}` : ""
        const errorCode = result.code ? ` (Código: ${result.code})` : ""
        
        // Se for erro de email duplicado, mostrar mensagem mais amigável
        if (result.code === "EMAIL_ALREADY_EXISTS") {
          toast.error(`Email já cadastrado! ${result.details}`)
        } else {
          throw new Error(`${errorMessage}${errorDetails}${errorCode}`)
        }
        return
      }

      toast.success("Recepcionista cadastrado com sucesso!")
      setShowDialog(false)
      setFormData({ nome: "", email: "", telefone: "" })
      carregarUsuarios()
    } catch (error: any) {
      console.error("Erro ao cadastrar usuário:", error)
      toast.error(error.message || "Erro ao cadastrar usuário")
    } finally {
      setSubmitting(false)
    }
  }

  const toggleStatus = async (userId: string, ativo: boolean) => {
    try {
      const { error } = await supabase
        .from("usuarios")
        .update({ ativo: !ativo })
        .eq("id", userId)

      if (error) throw error

      toast.success(`Usuário ${ativo ? "desativado" : "ativado"} com sucesso!`)
      carregarUsuarios()
    } catch (error) {
      console.error("Erro ao alterar status:", error)
      toast.error("Erro ao alterar status do usuário")
    }
  }

  const criarLoginRecepcionista = async (email: string) => {
    try {
      // Buscar dados do usuário primeiro
      const { data: usuario } = await supabase
        .from("usuarios")
        .select("nome, telefone")
        .eq("email", email)
        .single()

      if (!usuario) {
        toast.error("Usuário não encontrado")
        return
      }

      const response = await fetch("/api/criar-login-recepcionista-simples", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Erro ao criar login")
      }

      toast.success(result.message)
      carregarUsuarios()
    } catch (error: any) {
      console.error("Erro ao criar login:", error)
      toast.error(error.message || "Erro ao criar login")
    }
  }

  const verificarCriarLogins = async () => {
    try {
      const response = await fetch("/api/criar-logins-existentes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Erro ao verificar logins")
      }

      toast.success(result.message)
      carregarUsuarios()
    } catch (error: any) {
      console.error("Erro ao verificar logins:", error)
      toast.error(error.message || "Erro ao verificar logins")
    }
  }

  const redefinirSenhas = async () => {
    try {
      const response = await fetch("/api/redefinir-senhas-final", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Erro ao redefinir senhas")
      }

      toast.success(result.message)
      carregarUsuarios()
    } catch (error: any) {
      console.error("Erro ao redefinir senhas:", error)
      toast.error(error.message || "Erro ao redefinir senhas")
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Cadastro de Usuários</h1>
          <p className="text-gray-600 mt-2">Gerencie os recepcionistas da sua clínica</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={verificarCriarLogins}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Verificar/Criar Logins
          </Button>
          <Button variant="outline" onClick={redefinirSenhas}>
            <Key className="mr-2 h-4 w-4" />
            Redefinir Senhas
          </Button>
          <Button variant="outline" onClick={async () => {
            try {
              const response = await fetch("/api/atualizar-dias-teste", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
              })

              const result = await response.json()

              if (response.ok) {
                toast.success(result.message)
                console.log("📊 Resultados da atualização:", result.resultados)
              } else {
                toast.error(result.error || "Erro ao atualizar dias de teste")
              }
            } catch (error) {
              console.error("Erro ao atualizar dias de teste:", error)
              toast.error("Erro ao atualizar dias de teste")
            }
          }}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Atualizar Dias Teste
          </Button>
          <Button variant="outline" onClick={async () => {
            try {
              const response = await fetch("/api/estatisticas-dias-teste", {
                method: "GET",
                headers: {
                  "Content-Type": "application/json",
                },
              })

              const result = await response.json()

              if (response.ok) {
                console.log("📊 Estatísticas:", result)
                toast.success(`Estatísticas: ${result.estatisticas?.total_usuarios || 0} usuários`)
                
                // Mostrar detalhes no console
                if (result.usuarios_proximos_vencimento?.length > 0) {
                  console.log("⚠️ Usuários próximos do vencimento:", result.usuarios_proximos_vencimento)
                }
              } else {
                toast.error(result.error || "Erro ao buscar estatísticas")
              }
            } catch (error) {
              console.error("Erro ao buscar estatísticas:", error)
              toast.error("Erro ao buscar estatísticas")
            }
          }}>
            <BarChart3 className="mr-2 h-4 w-4" />
            Ver Estatísticas
          </Button>
          <Button variant="outline" onClick={async () => {
            try {
              const response = await fetch("/api/gerenciar-cobranca", {
                method: "GET",
                headers: {
                  "Content-Type": "application/json",
                },
              })

              const result = await response.json()

              if (response.ok) {
                console.log("💰 Relatório de Cobrança:", result)
                
                const relatorio = result.relatorio
                const notificacoes = result.notificacoes
                const expirados = result.usuarios_expirados
                
                toast.success(`Cobrança: ${relatorio.usuarios_expirando || 0} expirando, ${expirados.length} expirados`)
                
                // Mostrar detalhes no console
                if (notificacoes.length > 0) {
                  console.log("⚠️ Notificações de vencimento:", notificacoes)
                }
                if (expirados.length > 0) {
                  console.log("🔒 Usuários expirados:", expirados)
                }
                if (relatorio.receita_potencial > 0) {
                  console.log(`💰 Receita potencial: R$ ${relatorio.receita_potencial}`)
                }
              } else {
                toast.error(result.error || "Erro ao buscar relatório de cobrança")
              }
            } catch (error) {
              console.error("Erro ao buscar relatório de cobrança:", error)
              toast.error("Erro ao buscar relatório de cobrança")
            }
          }}>
            <DollarSign className="mr-2 h-4 w-4" />
            Relatório Cobrança
          </Button>
          <Button variant="outline" onClick={async () => {
            try {
              const response = await fetch("/api/gerenciar-cobranca", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({ action: "bloquear_expirados" }),
              })

              const result = await response.json()

              if (response.ok) {
                console.log("🔒 Bloqueio executado:", result)
                toast.success("Usuários expirados bloqueados com sucesso")
                
                // Recarregar lista de usuários
                carregarUsuarios()
              } else {
                toast.error(result.error || "Erro ao bloquear usuários")
              }
            } catch (error) {
              console.error("Erro ao bloquear usuários:", error)
              toast.error("Erro ao bloquear usuários")
            }
          }}>
            <Lock className="mr-2 h-4 w-4" />
            Bloquear Expirados
          </Button>
          <Button variant="outline" onClick={async () => {
            try {
              const response = await fetch("/api/gerenciar-cobranca", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({ action: "criar_pagamentos_automaticos" }),
              })

              const result = await response.json()

              if (response.ok) {
                console.log("💰 Pagamentos criados:", result)
                toast.success("Pagamentos automáticos criados com sucesso")
              } else {
                toast.error(result.error || "Erro ao criar pagamentos")
              }
            } catch (error) {
              console.error("Erro ao criar pagamentos:", error)
              toast.error("Erro ao criar pagamentos")
            }
          }}>
            <CreditCard className="mr-2 h-4 w-4" />
            Criar Pagamentos
          </Button>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <UserPlus className="h-4 w-4" />
                Novo Recepcionista
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md z-50">
              <DialogHeader>
                <DialogTitle>Cadastrar Recepcionista</DialogTitle>
                <DialogDescription>
                  Preencha os dados do novo recepcionista da clínica.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Completo *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    placeholder="Nome completo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    placeholder="email@exemplo.com"
                    className={emailStatus.exists ? "border-red-500" : ""}
                  />
                  {emailStatus.checking && (
                    <p className="text-sm text-gray-500 mt-1">Verificando email...</p>
                  )}
                  {emailStatus.message && (
                    <p className={`text-sm ${emailStatus.exists ? "text-red-500" : "text-green-500"} mt-1`}>
                      {emailStatus.message}
                    </p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input
                    id="telefone"
                    value={formData.telefone}
                    onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                    placeholder="(11) 99999-9999"
                  />
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="flex-1">
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={submitting || emailStatus.exists || emailStatus.checking} 
                    className="flex-1"
                  >
                    {submitting ? "Cadastrando..." : "Cadastrar"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Recepcionistas
          </CardTitle>
          <CardDescription>
            Lista de recepcionistas cadastrados na clínica
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : usuarios.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Nenhum recepcionista cadastrado</p>
              <p className="text-sm">Clique em "Novo Recepcionista" para começar</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Telefone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Cadastro</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {usuarios.map((usuario) => (
                  <TableRow key={usuario.id}>
                    <TableCell className="font-medium">{usuario.nome}</TableCell>
                    <TableCell className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gray-400" />
                      {usuario.email}
                    </TableCell>
                    <TableCell className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-gray-400" />
                      {usuario.telefone || "Não informado"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={usuario.ativo ? "default" : "secondary"}>
                        {usuario.ativo ? "Ativo" : "Inativo"}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatDate(usuario.created_at)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleStatus(usuario.id, usuario.ativo)}
                        >
                          {usuario.ativo ? "Desativar" : "Ativar"}
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => criarLoginRecepcionista(usuario.email)}
                        >
                          Criar Login
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
} 