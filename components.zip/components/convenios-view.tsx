"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Plus, Edit, Trash2, Building, Users } from "lucide-react"
import { useRouter } from "next/navigation"

interface Convenio {
  id: string
  nome: string
  ativo: boolean
  created_at: string
}

interface ConsultaConvenio {
  convenio_id: string
  convenios: {
    nome: string
  }
}

interface ConveniosViewProps {
  convenios: Convenio[]
  consultasConvenio: ConsultaConvenio[]
}

export function ConveniosView({ convenios: initialConvenios, consultasConvenio }: ConveniosViewProps) {
  const [convenios, setConvenios] = useState(initialConvenios)
  const [loading, setLoading] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingConvenio, setEditingConvenio] = useState<Convenio | null>(null)
  const [formData, setFormData] = useState({
    nome: "",
    ativo: true,
  })

  const { toast } = useToast()
  const router = useRouter()
  const supabase = createClient()

  // Calcular estatísticas
  const conveniosAtivos = convenios.filter((c) => c.ativo).length
  const conveniosInativos = convenios.filter((c) => !c.ativo).length

  // Contar consultas por convênio
  const consultasPorConvenio = consultasConvenio.reduce(
    (acc, consulta) => {
      const nome = consulta.convenios.nome
      acc[nome] = (acc[nome] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (editingConvenio) {
        // Atualizar convênio existente
        const { error } = await supabase
          .from("convenios")
          .update({
            nome: formData.nome,
            ativo: formData.ativo,
          })
          .eq("id", editingConvenio.id)

        if (error) throw error

        setConvenios((prev) =>
          prev.map((conv) =>
            conv.id === editingConvenio.id ? { ...conv, nome: formData.nome, ativo: formData.ativo } : conv,
          ),
        )

        toast({
          title: "Convênio atualizado!",
          description: "O convênio foi atualizado com sucesso.",
        })
      } else {
        // Criar novo convênio
        const { data, error } = await supabase
          .from("convenios")
          .insert({
            nome: formData.nome,
            ativo: formData.ativo,
          })
          .select()
          .single()

        if (error) throw error

        setConvenios((prev) => [...prev, data])

        toast({
          title: "Convênio criado!",
          description: "O novo convênio foi adicionado com sucesso.",
        })
      }

      setDialogOpen(false)
      setEditingConvenio(null)
      setFormData({ nome: "", ativo: true })
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Ocorreu um erro ao salvar o convênio.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = (convenio: Convenio) => {
    setEditingConvenio(convenio)
    setFormData({
      nome: convenio.nome,
      ativo: convenio.ativo,
    })
    setDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este convênio?")) {
      return
    }

    try {
      const { error } = await supabase.from("convenios").delete().eq("id", id)

      if (error) throw error

      setConvenios((prev) => prev.filter((conv) => conv.id !== id))

      toast({
        title: "Convênio excluído!",
        description: "O convênio foi removido com sucesso.",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Ocorreu um erro ao excluir o convênio.",
        variant: "destructive",
      })
    }
  }

  const handleToggleStatus = async (convenio: Convenio) => {
    try {
      const { error } = await supabase.from("convenios").update({ ativo: !convenio.ativo }).eq("id", convenio.id)

      if (error) throw error

      setConvenios((prev) => prev.map((conv) => (conv.id === convenio.id ? { ...conv, ativo: !conv.ativo } : conv)))

      toast({
        title: "Status atualizado!",
        description: `Convênio ${!convenio.ativo ? "ativado" : "desativado"} com sucesso.`,
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Ocorreu um erro ao atualizar o status.",
        variant: "destructive",
      })
    }
  }

  const openNewDialog = () => {
    setEditingConvenio(null)
    setFormData({ nome: "", ativo: true })
    setDialogOpen(true)
  }

  return (
    <div className="px-2 sm:px-0">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Building className="h-6 w-6 text-blue-600" />
          <h2 className="text-2xl font-bold">Convênios Médicos</h2>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNewDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Convênio
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingConvenio ? "Editar Convênio" : "Novo Convênio"}</DialogTitle>
              <DialogDescription>
                {editingConvenio ? "Atualize os dados do convênio" : "Adicione um novo convênio médico"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome do Convênio</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  placeholder="Ex: Unimed"
                  required
                />
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="ativo"
                  checked={formData.ativo}
                  onChange={(e) => setFormData({ ...formData, ativo: e.target.checked })}
                  className="rounded"
                />
                <Label htmlFor="ativo">Convênio ativo</Label>
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? "Salvando..." : "Salvar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Estatísticas */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Convênios</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{convenios.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Convênios Ativos</CardTitle>
            <Badge variant="default" className="h-4 w-4 p-0"></Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{conveniosAtivos}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Convênios Inativos</CardTitle>
            <Badge variant="secondary" className="h-4 w-4 p-0"></Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{conveniosInativos}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Consultas com Convênio</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{consultasConvenio.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Tabela */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Convênios</CardTitle>
          <CardDescription>Gerencie todos os convênios médicos disponíveis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto w-full max-w-full">
            <Table className="min-w-[600px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Consultas</TableHead>
                  <TableHead>Data de Criação</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {convenios.map((convenio) => (
                  <TableRow key={convenio.id}>
                    <TableCell className="font-medium">{convenio.nome}</TableCell>
                    <TableCell>
                      <Badge variant={convenio.ativo ? "default" : "secondary"}>
                        {convenio.ativo ? "Ativo" : "Inativo"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-gray-600">{consultasPorConvenio[convenio.nome] || 0} consultas</span>
                    </TableCell>
                    <TableCell>{new Date(convenio.created_at).toLocaleDateString("pt-BR")}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleToggleStatus(convenio)}>
                          {convenio.ativo ? "Desativar" : "Ativar"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleEdit(convenio)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(convenio.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
