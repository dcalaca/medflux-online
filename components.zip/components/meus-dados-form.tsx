"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { User, Building, Save } from "lucide-react"
import type { Usuario } from "@/types/database.types"

interface Clinica {
  id: string
  nome: string
  endereco: string | null
  telefone: string | null
  email: string | null
  cnpj: string | null
}

interface MeusDadosFormProps {
  usuario: Usuario
  clinica: Clinica | null
}

export function MeusDadosForm({ usuario, clinica }: MeusDadosFormProps) {
  const [loading, setLoading] = useState(false)
  const [userFormData, setUserFormData] = useState({
    nome: usuario.nome || "",
    crm: usuario.crm || "",
    cro: usuario.cro || "",
    especialidade: usuario.especialidade || "",
  })

  const [clinicaFormData, setClinicaFormData] = useState({
    nome: clinica?.nome || "",
    endereco: clinica?.endereco || "",
    telefone: clinica?.telefone || "",
    email: clinica?.email || "",
  })

  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const { error } = await supabase
        .from("usuarios")
        .update({
          nome: userFormData.nome,
          crm: userFormData.crm,
          cro: userFormData.cro,
          especialidade: userFormData.especialidade,
        })
        .eq("id", usuario.id)

      if (error) throw error

      toast({
        title: "Dados atualizados!",
        description: "Suas informações pessoais foram atualizadas com sucesso.",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar dados",
        description: "Ocorreu um erro ao atualizar suas informações.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleClinicaSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (!clinica) {
        throw new Error("Clínica não encontrada")
      }

      const { error } = await supabase
        .from("clinicas")
        .update({
          nome: clinicaFormData.nome,
          endereco: clinicaFormData.endereco,
          telefone: clinicaFormData.telefone,
          email: clinicaFormData.email,
        })
        .eq("id", clinica.id)

      if (error) throw error

      toast({
        title: "Dados da clínica atualizados!",
        description: "As informações da clínica foram atualizadas com sucesso.",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar clínica",
        description: "Ocorreu um erro ao atualizar os dados da clínica.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-xl mx-auto p-2 sm:p-8">
      <Tabs defaultValue="pessoal" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pessoal" className="flex items-center space-x-2">
            <User className="w-4 h-4" />
            <span>Dados Pessoais</span>
          </TabsTrigger>
          <TabsTrigger value="clinica" className="flex items-center space-x-2">
            <Building className="w-4 h-4" />
            <span>Dados da Clínica</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pessoal">
          <Card>
            <CardHeader>
              <CardTitle>Informações Pessoais</CardTitle>
              <CardDescription>Atualize suas informações pessoais e profissionais</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUserSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nome">Nome Completo *</Label>
                    <Input
                      id="nome"
                      value={userFormData.nome}
                      onChange={(e) => setUserFormData({ ...userFormData, nome: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      value={usuario.email}
                      disabled
                      className="bg-gray-50"
                    />
                    <p className="text-xs text-gray-500 mt-1">Email não pode ser alterado</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="crm">CRM</Label>
                    <Input
                      id="crm"
                      value={userFormData.crm}
                      onChange={(e) => setUserFormData({ ...userFormData, crm: e.target.value })}
                      placeholder="Ex: 123456-SP"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cro">CRO</Label>
                    <Input
                      id="cro"
                      value={userFormData.cro}
                      onChange={(e) => setUserFormData({ ...userFormData, cro: e.target.value })}
                      placeholder="Ex: 12345-SP"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="especialidade">Especialidade</Label>
                  <Input
                    id="especialidade"
                    value={userFormData.especialidade}
                    onChange={(e) => setUserFormData({ ...userFormData, especialidade: e.target.value })}
                    placeholder="Ex: Cardiologia, Dermatologia..."
                  />
                </div>

                <div className="flex justify-end">
                  <Button type="submit" disabled={loading}>
                    <Save className="w-4 h-4 mr-2" />
                    {loading ? "Salvando..." : "Salvar Alterações"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clinica">
          {clinica ? (
            <Card>
              <CardHeader>
                <CardTitle>Dados da Clínica</CardTitle>
                <CardDescription>Atualize as informações da sua clínica</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleClinicaSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clinica-nome">Nome da Clínica *</Label>
                      <Input
                        id="clinica-nome"
                        value={clinicaFormData.nome}
                        onChange={(e) => setClinicaFormData({ ...clinicaFormData, nome: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="clinica-cnpj">CNPJ</Label>
                      <Input
                        id="clinica-cnpj"
                        value={clinica.cnpj || ""}
                        disabled
                        className="bg-gray-50"
                      />
                      <p className="text-xs text-gray-500 mt-1">CNPJ não pode ser alterado</p>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="clinica-endereco">Endereço</Label>
                    <Input
                      id="clinica-endereco"
                      value={clinicaFormData.endereco}
                      onChange={(e) => setClinicaFormData({ ...clinicaFormData, endereco: e.target.value })}
                      placeholder="Rua, número, bairro, cidade/estado"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clinica-telefone">Telefone</Label>
                      <Input
                        id="clinica-telefone"
                        value={clinicaFormData.telefone}
                        onChange={(e) => setClinicaFormData({ ...clinicaFormData, telefone: e.target.value })}
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                    <div>
                      <Label htmlFor="clinica-email">Email da Clínica</Label>
                      <Input
                        id="clinica-email"
                        value={clinicaFormData.email}
                        onChange={(e) => setClinicaFormData({ ...clinicaFormData, email: e.target.value })}
                        placeholder="contato@clinica.com"
                        type="email"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={loading}>
                      <Save className="w-4 h-4 mr-2" />
                      {loading ? "Salvando..." : "Salvar Alterações"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <Building className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">Você não está associado a uma clínica</p>
                <p className="text-sm text-gray-400 mt-2">
                  Entre em contato com o administrador para associar sua conta a uma clínica.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
} 
