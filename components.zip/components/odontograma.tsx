"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"

interface OdontogramaProps {
  prontuarioId: string
  odontogramaData?: any[]
  onSave?: () => void
}

interface DenteData {
  numero: number
  faces: {
    oclusal?: string
    mesial?: string
    distal?: string
    vestibular?: string
    lingual?: string
  }
  observacoes?: string
}

export function Odontograma({ prontuarioId, odontogramaData = [], onSave }: OdontogramaProps) {
  const [dentes, setDentes] = useState<Record<number, DenteData>>(() => {
    const initialDentes: Record<number, DenteData> = {}

    // Inicializar todos os dentes (1-32 para adulto)
    for (let i = 1; i <= 32; i++) {
      initialDentes[i] = {
        numero: i,
        faces: {},
        observacoes: "",
      }
    }

    // Carregar dados existentes
    odontogramaData.forEach((item) => {
      if (initialDentes[item.dente_numero]) {
        initialDentes[item.dente_numero].faces = item.faces || {}
        initialDentes[item.dente_numero].observacoes = item.observacoes || ""
      }
    })

    return initialDentes
  })

  const [selectedDente, setSelectedDente] = useState<number | null>(null)
  const [selectedFace, setSelectedFace] = useState<string>("")
  const [selectedStatus, setSelectedStatus] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const { toast } = useToast()
  const supabase = createClient()

  const statusOptions = [
    { value: "sadio", label: "Saudável", color: "#22c55e" },
    { value: "carie", label: "Cárie", color: "#ef4444" },
    { value: "restaurado", label: "Restaurado", color: "#3b82f6" },
    { value: "extraido", label: "Extraído", color: "#6b7280" },
    { value: "implante", label: "Implante", color: "#8b5cf6" },
    { value: "protese", label: "Prótese", color: "#f59e0b" },
  ]

  const faces = [
    { key: "oclusal", label: "Oclusal" },
    { key: "mesial", label: "Mesial" },
    { key: "distal", label: "Distal" },
    { key: "vestibular", label: "Vestibular" },
    { key: "lingual", label: "Lingual" },
  ]

  const handleDenteClick = (numero: number) => {
    setSelectedDente(numero)
  }

  const handleFaceUpdate = (face: string, status: string) => {
    if (!selectedDente) return

    setDentes((prev) => ({
      ...prev,
      [selectedDente]: {
        ...prev[selectedDente],
        faces: {
          ...prev[selectedDente].faces,
          [face]: status,
        },
      },
    }))
  }

  const handleObservacaoUpdate = (observacao: string) => {
    if (!selectedDente) return

    setDentes((prev) => ({
      ...prev,
      [selectedDente]: {
        ...prev[selectedDente],
        observacoes: observacao,
      },
    }))
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      // Deletar registros existentes
      await supabase.from("odontograma").delete().eq("prontuario_id", prontuarioId)

      // Inserir novos registros
      const registros = Object.values(dentes)
        .filter((dente) => Object.keys(dente.faces).length > 0 || dente.observacoes)
        .map((dente) => ({
          prontuario_id: prontuarioId,
          dente_numero: dente.numero,
          faces: dente.faces,
          observacoes: dente.observacoes,
        }))

      if (registros.length > 0) {
        const { error } = await supabase.from("odontograma").insert(registros)
        if (error) throw error
      }

      toast({
        title: "Odontograma salvo!",
        description: "As informações do odontograma foram salvas com sucesso.",
      })

      if (onSave) onSave()
    } catch (error) {
      console.error("Erro ao salvar odontograma:", error)
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar o odontograma.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getDenteColor = (numero: number) => {
    const dente = dentes[numero]
    const faces = Object.values(dente.faces)

    if (faces.includes("extraido")) return "#6b7280"
    if (faces.includes("carie")) return "#ef4444"
    if (faces.includes("restaurado")) return "#3b82f6"
    if (faces.includes("implante")) return "#8b5cf6"
    if (faces.includes("protese")) return "#f59e0b"

    return "#22c55e" // saudável
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Odontograma</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Arcada Superior */}
          <div className="mb-8">
            <h3 className="text-sm font-medium mb-4">Arcada Superior</h3>
            <div className="grid grid-cols-8 gap-2 mb-4">
              {[18, 17, 16, 15, 14, 13, 12, 11].map((numero) => (
                <button
                  key={numero}
                  onClick={() => handleDenteClick(numero)}
                  className={`w-12 h-12 rounded border-2 text-xs font-medium transition-all ${
                    selectedDente === numero
                      ? "border-blue-500 ring-2 ring-blue-200"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                  style={{ backgroundColor: getDenteColor(numero) + "40" }}
                >
                  {numero}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-8 gap-2">
              {[21, 22, 23, 24, 25, 26, 27, 28].map((numero) => (
                <button
                  key={numero}
                  onClick={() => handleDenteClick(numero)}
                  className={`w-12 h-12 rounded border-2 text-xs font-medium transition-all ${
                    selectedDente === numero
                      ? "border-blue-500 ring-2 ring-blue-200"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                  style={{ backgroundColor: getDenteColor(numero) + "40" }}
                >
                  {numero}
                </button>
              ))}
            </div>
          </div>

          {/* Arcada Inferior */}
          <div className="mb-8">
            <h3 className="text-sm font-medium mb-4">Arcada Inferior</h3>
            <div className="grid grid-cols-8 gap-2 mb-4">
              {[48, 47, 46, 45, 44, 43, 42, 41].map((numero) => (
                <button
                  key={numero}
                  onClick={() => handleDenteClick(numero)}
                  className={`w-12 h-12 rounded border-2 text-xs font-medium transition-all ${
                    selectedDente === numero
                      ? "border-blue-500 ring-2 ring-blue-200"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                  style={{ backgroundColor: getDenteColor(numero) + "40" }}
                >
                  {numero}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-8 gap-2">
              {[31, 32, 33, 34, 35, 36, 37, 38].map((numero) => (
                <button
                  key={numero}
                  onClick={() => handleDenteClick(numero)}
                  className={`w-12 h-12 rounded border-2 text-xs font-medium transition-all ${
                    selectedDente === numero
                      ? "border-blue-500 ring-2 ring-blue-200"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                  style={{ backgroundColor: getDenteColor(numero) + "40" }}
                >
                  {numero}
                </button>
              ))}
            </div>
          </div>

          {/* Legenda */}
          <div className="mb-6">
            <h4 className="text-sm font-medium mb-2">Legenda</h4>
            <div className="flex flex-wrap gap-2">
              {statusOptions.map((status) => (
                <Badge
                  key={status.value}
                  variant="outline"
                  style={{ backgroundColor: status.color + "20", borderColor: status.color }}
                >
                  {status.label}
                </Badge>
              ))}
            </div>
          </div>

          {/* Detalhes do Dente Selecionado */}
          {selectedDente && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Dente {selectedDente}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Faces do Dente</Label>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    {faces.map((face) => (
                      <div key={face.key} className="space-y-2">
                        <Label className="text-xs">{face.label}</Label>
                        <select
                          value={dentes[selectedDente].faces[face.key] || ""}
                          onChange={(e) => handleFaceUpdate(face.key, e.target.value)}
                          className="w-full p-2 border rounded text-sm"
                        >
                          <option value="">Selecione...</option>
                          {statusOptions.map((status) => (
                            <option key={status.value} value={status.value}>
                              {status.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    value={dentes[selectedDente].observacoes || ""}
                    onChange={(e) => handleObservacaoUpdate(e.target.value)}
                    placeholder="Observações específicas sobre este dente..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={loading}>
              {loading ? "Salvando..." : "Salvar Odontograma"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
