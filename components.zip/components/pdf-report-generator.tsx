"use client"

import { jsPDF } from "jspdf"
import "jspdf-autotable"
import { Button } from "@/components/ui/button"
import { Download, FileText, TrendingUp, DollarSign, Calendar } from "lucide-react"

interface Consulta {
  id: string
  data_hora: string
  valor: number | null
  status: string
  status_pagamento: string
  forma_pagamento: string | null
  pacientes: {
    nome: string
  } | null
  tipos_consulta: {
    nome: string
    cor: string
  } | null
}

interface PDFReportGeneratorProps {
  consultas: Consulta[]
  filtroMes: string
  filtroAno: string
  totalFaturamento: number
  totalPendente: number
  totalConsultas: number
  consultasPagas: number
}

export function PDFReportGenerator({
  consultas,
  filtroMes,
  filtroAno,
  totalFaturamento,
  totalPendente,
  totalConsultas,
  consultasPagas,
}: PDFReportGeneratorProps) {
  const meses = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ]

  const nomeMes = meses[parseInt(filtroMes)]
  const taxaRecebimento = totalConsultas > 0 ? Math.round((consultasPagas / totalConsultas) * 100) : 0

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pago":
        return "#10B981" // green
      case "pendente":
        return "#F59E0B" // yellow
      case "cancelado":
        return "#EF4444" // red
      default:
        return "#6B7280" // gray
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pago":
        return "Pago"
      case "pendente":
        return "Pendente"
      case "cancelado":
        return "Cancelado"
      default:
        return "Desconhecido"
    }
  }

  const generatePDF = () => {
    const doc = new jsPDF()
    
    // Configurações do documento
    const pageWidth = doc.internal.pageSize.width
    const pageHeight = doc.internal.pageSize.height
    const margin = 20
    
    // Cores
    const primaryColor = [59, 130, 246] // blue-500
    const secondaryColor = [107, 114, 128] // gray-500
    const successColor = [16, 185, 129] // green-500
    const warningColor = [245, 158, 11] // yellow-500

    // Cabeçalho
    doc.setFontSize(24)
    doc.setTextColor(...primaryColor)
    doc.text("Relatório Financeiro", pageWidth / 2, 30, { align: "center" })
    
    doc.setFontSize(12)
    doc.setTextColor(...secondaryColor)
    doc.text(`${nomeMes} ${filtroAno}`, pageWidth / 2, 45, { align: "center" })
    
    // Linha separadora
    doc.setDrawColor(...primaryColor)
    doc.setLineWidth(0.5)
    doc.line(margin, 55, pageWidth - margin, 55)

    // Resumo financeiro
    doc.setFontSize(16)
    doc.setTextColor(...primaryColor)
    doc.text("Resumo Financeiro", margin, 75)
    
    doc.setFontSize(10)
    doc.setTextColor(...secondaryColor)
    
    // Métricas
    const metrics = [
      { label: "Faturamento Total", value: formatCurrency(totalFaturamento), color: successColor },
      { label: "Pendente", value: formatCurrency(totalPendente), color: warningColor },
      { label: "Total de Consultas", value: totalConsultas.toString(), color: primaryColor },
      { label: "Taxa de Recebimento", value: `${taxaRecebimento}%`, color: successColor },
    ]

    let yPos = 90
    metrics.forEach((metric, index) => {
      const xPos = margin + (index % 2) * 85
      if (index > 0 && index % 2 === 0) yPos += 15
      
      doc.setTextColor(...metric.color)
      doc.setFontSize(12)
      doc.text(metric.value, xPos, yPos)
      
      doc.setTextColor(...secondaryColor)
      doc.setFontSize(8)
      doc.text(metric.label, xPos, yPos + 5)
    })

    // Tabela de consultas
    if (consultas.length > 0) {
      doc.addPage()
      
      doc.setFontSize(16)
      doc.setTextColor(...primaryColor)
      doc.text("Detalhamento de Consultas", margin, 30)
      
      // Preparar dados da tabela
      const tableData = consultas.map(consulta => [
        formatDate(consulta.data_hora),
        consulta.pacientes?.nome || "N/A",
        consulta.tipos_consulta?.nome || "N/A",
        formatCurrency(consulta.valor || 0),
        getStatusText(consulta.status_pagamento),
        consulta.forma_pagamento || "N/A"
      ])

      // Configurar tabela
      const tableConfig = {
        head: [["Data", "Paciente", "Tipo", "Valor", "Status", "Forma Pagamento"]],
        body: tableData,
        startY: 45,
        styles: {
          fontSize: 8,
          cellPadding: 3,
        },
        headStyles: {
          fillColor: primaryColor,
          textColor: [255, 255, 255],
          fontStyle: "bold",
        },
        alternateRowStyles: {
          fillColor: [248, 250, 252], // gray-50
        },
        columnStyles: {
          0: { cellWidth: 25 }, // Data
          1: { cellWidth: 40 }, // Paciente
          2: { cellWidth: 30 }, // Tipo
          3: { cellWidth: 25 }, // Valor
          4: { cellWidth: 25 }, // Status
          5: { cellWidth: 30 }, // Forma Pagamento
        },
      }

      // Adicionar tabela
      doc.autoTable(tableConfig)
    }

    // Rodapé
    const currentPage = doc.getCurrentPageInfo().pageNumber
    const totalPages = doc.getNumberOfPages()
    
    doc.setFontSize(8)
    doc.setTextColor(...secondaryColor)
    doc.text(`Página ${currentPage} de ${totalPages}`, pageWidth / 2, pageHeight - 10, { align: "center" })
    doc.text(`Gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}`, pageWidth / 2, pageHeight - 5, { align: "center" })

    // Salvar PDF
    const fileName = `relatorio-financeiro-${nomeMes.toLowerCase()}-${filtroAno}.pdf`
    doc.save(fileName)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Relatórios</h3>
          <p className="text-sm text-muted-foreground">
            Exporte relatórios detalhados em PDF
          </p>
        </div>
        <Button onClick={generatePDF} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Exportar PDF
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="p-4 border rounded-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-600">Faturamento</p>
              <p className="text-2xl font-bold text-blue-700">
                {formatCurrency(totalFaturamento)}
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-blue-500" />
          </div>
        </div>

        <div className="p-4 border rounded-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-600">Pendente</p>
              <p className="text-2xl font-bold text-yellow-700">
                {formatCurrency(totalPendente)}
              </p>
            </div>
            <Calendar className="h-8 w-8 text-yellow-500" />
          </div>
        </div>

        <div className="p-4 border rounded-lg bg-gradient-to-br from-green-50 to-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-600">Consultas</p>
              <p className="text-2xl font-bold text-green-700">{totalConsultas}</p>
            </div>
            <FileText className="h-8 w-8 text-green-500" />
          </div>
        </div>

        <div className="p-4 border rounded-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-600">Taxa Recebimento</p>
              <p className="text-2xl font-bold text-purple-700">{taxaRecebimento}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-500" />
          </div>
        </div>
      </div>

      <div className="p-6 border rounded-lg bg-gray-50">
        <div className="flex items-center gap-2 mb-4">
          <FileText className="h-5 w-5 text-blue-500" />
          <h4 className="font-semibold">Informações do Relatório</h4>
        </div>
        <div className="grid gap-2 text-sm text-gray-600">
          <p>• <strong>Período:</strong> {nomeMes} {filtroAno}</p>
          <p>• <strong>Total de consultas:</strong> {totalConsultas}</p>
          <p>• <strong>Consultas pagas:</strong> {consultasPagas}</p>
          <p>• <strong>Consultas pendentes:</strong> {totalConsultas - consultasPagas}</p>
          <p>• <strong>Valor total faturado:</strong> {formatCurrency(totalFaturamento)}</p>
          <p>• <strong>Valor pendente:</strong> {formatCurrency(totalPendente)}</p>
        </div>
      </div>
    </div>
  )
} 
