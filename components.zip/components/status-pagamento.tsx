"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, XCircle, CreditCard } from "lucide-react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import Link from "next/link"

interface StatusPagamento {
  ativo: boolean
  ultimoPagamento?: {
    status: string
    data_pagamento: string
    valor: number
  }
}

export function StatusPagamento() {
  const [status, setStatus] = useState<StatusPagamento | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClientComponentClient()

  useEffect(() => {
    async function fetchStatus() {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) return

        // Buscar status do usuário
        const { data: usuario } = await supabase.from("usuarios").select("ativo").eq("id", user.id).single()

        // Buscar último pagamento
        const { data: pagamento } = await supabase
          .from("pagamentos")
          .select("status, data_pagamento, valor")
          .eq("usuario_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .single()

        setStatus({
          ativo: usuario?.ativo || false,
          ultimoPagamento: pagamento || undefined,
        })
      } catch (error) {
        console.error("Erro ao buscar status:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStatus()
  }, [supabase])

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!status) return null

  const getStatusIcon = () => {
    if (status.ativo) return <CheckCircle className="w-5 h-5 text-green-600" />
    if (status.ultimoPagamento?.status === "pendente") return <Clock className="w-5 h-5 text-yellow-600" />
    return <XCircle className="w-5 h-5 text-red-600" />
  }

  const getStatusText = () => {
    if (status.ativo) return "Plano Ativo"
    if (status.ultimoPagamento?.status === "pendente") return "Pagamento Pendente"
    return "Plano Inativo"
  }

  const getStatusColor = () => {
    if (status.ativo) return "bg-green-100 text-green-800"
    if (status.ultimoPagamento?.status === "pendente") return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          {getStatusIcon()}
          Status da Assinatura
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Badge className={getStatusColor()}>{getStatusText()}</Badge>
          <span className="text-sm text-gray-600">R$ 99/mês</span>
        </div>

        {status.ultimoPagamento && (
          <div className="text-sm text-gray-600">
            <p>Último pagamento: {new Date(status.ultimoPagamento.data_pagamento).toLocaleDateString("pt-BR")}</p>
            <p>Valor: R$ {status.ultimoPagamento.valor.toFixed(2)}</p>
          </div>
        )}

        {!status.ativo && (
          <Button size="sm" className="w-full" asChild>
            <Link href="/pagamento">
              <CreditCard className="w-4 h-4 mr-2" />
              Ativar Plano
            </Link>
          </Button>
        )}

        {status.ativo && (
          <div className="text-xs text-gray-500">
            <p>Próxima cobrança: {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR")}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
