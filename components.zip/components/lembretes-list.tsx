"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Plus, Mail } from "lucide-react"

interface Lembrete {
  id: string
  paciente_id: string
  tipo: string
  titulo: string
  mensagem: string
  data_envio: string
  canal: string
  status: string
  enviado: boolean
}

export function LembretesList() {
  const [lembretes, setLembretes] = useState<Lembrete[]>([])
  const [loading, setLoading] = useState(true)
  const [filtro, setFiltro] = useState<string>("")
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({
    paciente_id: "",
    tipo: "Personalizado",
    titulo: "",
    mensagem: "",
    data_envio: "",
    canal: "Email",
  })
  const [salvando, setSalvando] = useState(false)

  useEffect(() => {
    buscarLembretes()
  }, [filtro])

  async function buscarLembretes() {
    setLoading(true)
    let url = "/api/lembretes"
    if (filtro) url += `?status=${filtro}`
    const res = await fetch(url)
    const data = await res.json()
    setLembretes(data.lembretes || [])
    setLoading(false)
  }

  async function criarLembrete(e: React.FormEvent) {
    e.preventDefault()
    setSalvando(true)
    const res = await fetch("/api/lembretes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
    if (res.ok) {
      setShowModal(false)
      setForm({ paciente_id: "", tipo: "Personalizado", titulo: "", mensagem: "", data_envio: "", canal: "Email" })
      buscarLembretes()
    }
    setSalvando(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Lembretes e Notificações</h2>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="w-4 h-4 mr-2" /> Novo Lembrete
        </Button>
      </div>
      <div className="flex space-x-2 mb-4">
        <Button variant={filtro === "" ? "default" : "outline"} onClick={() => setFiltro("")}>Todos</Button>
        <Button variant={filtro === "pendente" ? "default" : "outline"} onClick={() => setFiltro("pendente")}>Pendentes</Button>
        <Button variant={filtro === "enviado" ? "default" : "outline"} onClick={() => setFiltro("enviado")}>Enviados</Button>
        <Button variant={filtro === "hoje" ? "default" : "outline"} onClick={() => setFiltro("hoje")}>Hoje</Button>
      </div>
      {loading ? (
        <div>Carregando lembretes...</div>
      ) : lembretes.length === 0 ? (
        <div className="text-gray-500 flex flex-col items-center py-12">
          <BellIcon className="w-12 h-12 mb-2 text-gray-300" />
          Nenhum lembrete encontrado
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {lembretes.map((l) => (
            <Card key={l.id}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <Mail className="w-4 h-4 text-blue-500" /> {l.titulo}
                </CardTitle>
                <Badge className={l.status === "enviado" ? "bg-green-100 text-green-800" : l.status === "pendente" ? "bg-yellow-100 text-yellow-800" : "bg-gray-100 text-gray-800"}>
                  {l.status || (l.enviado ? "enviado" : "pendente")}
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-gray-700 mb-2">{l.mensagem}</div>
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <Calendar className="w-3 h-3" /> {new Date(l.data_envio).toLocaleString("pt-BR")}
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  <span className="text-xs">Canal: {l.canal}</span>
                  <span className="text-xs">Tipo: {l.tipo}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Modal de novo lembrete */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novo Lembrete</DialogTitle>
          </DialogHeader>
          <form onSubmit={criarLembrete} className="space-y-4">
            <Input
              placeholder="Título do lembrete"
              value={form.titulo}
              onChange={e => setForm({ ...form, titulo: e.target.value })}
              required
            />
            <Textarea
              placeholder="Mensagem do lembrete"
              value={form.mensagem}
              onChange={e => setForm({ ...form, mensagem: e.target.value })}
              required
            />
            <Input
              type="datetime-local"
              value={form.data_envio}
              onChange={e => setForm({ ...form, data_envio: e.target.value })}
              required
            />
            <Select value={form.tipo} onValueChange={v => setForm({ ...form, tipo: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Personalizado">Personalizado</SelectItem>
                <SelectItem value="Retorno">Retorno</SelectItem>
                <SelectItem value="Procedimento">Procedimento</SelectItem>
                <SelectItem value="Aniversário">Aniversário</SelectItem>
              </SelectContent>
            </Select>
            <Select value={form.canal} onValueChange={v => setForm({ ...form, canal: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Canal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Email">Email</SelectItem>
                <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                <SelectItem value="SMS">SMS</SelectItem>
              </SelectContent>
            </Select>
            {/* Aqui pode adicionar seleção de paciente se desejar */}
            <div className="flex justify-end">
              <Button type="button" variant="outline" onClick={() => setShowModal(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="ml-2" disabled={salvando}>
                {salvando ? "Salvando..." : "Criar Lembrete"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function BellIcon(props: any) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path d="M12 22a2 2 0 0 0 2-2H10a2 2 0 0 0 2 2Zm6-6V11a6 6 0 1 0-12 0v5l-2 2v1h16v-1l-2-2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
} 
