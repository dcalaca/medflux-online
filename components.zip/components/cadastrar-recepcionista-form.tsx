"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"

export default function CadastrarRecepcionistaForm({ clinicaId, medicoId }: { clinicaId: string, medicoId: string }) {
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
    cpf: "",
  })
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const supabase = createClient()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    
    console.log("Enviando dados:", {
      ...formData,
      clinica_id: clinicaId,
      medico_id: medicoId,
    })
    
    try {
      const response = await fetch("/api/cadastrar-recepcionista-final", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          clinica_id: clinicaId,
          medico_id: medicoId,
        }),
      })
      
      console.log("Status da resposta:", response.status)
      const data = await response.json()
      console.log("Dados da resposta:", data)
      
      if (!response.ok) {
        console.error("Erro na resposta:", response.status, data)
        toast({
          title: "Erro ao cadastrar recepcionista",
          description: data.error || "Erro na comunicação com o servidor.",
          variant: "destructive",
        })
        return
      }
      
      if (data?.error) {
        console.error("Erro retornado pela API:", data.error)
        toast({
          title: "Erro ao cadastrar recepcionista",
          description: data.error + (data.details ? ` - ${data.details}` : ""),
          variant: "destructive",
        })
        return
      }
      
      if (data?.success) {
        toast({
          title: "Recepcionista cadastrada com sucesso!",
          description: data.message || "A recepcionista foi adicionada ao sistema.",
        })
        router.push("/dashboard")
      } else {
        toast({
          title: "Erro ao cadastrar recepcionista",
          description: "Resposta inesperada do servidor.",
          variant: "destructive",
        })
      }
    } catch (err) {
      console.error("Erro inesperado:", err)
      toast({
        title: "Erro ao cadastrar recepcionista",
        description: "Ocorreu um erro inesperado. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="max-w-xl mx-auto mt-8 mb-8">
      <CardHeader>
        <CardTitle>Cadastrar Recepcionista</CardTitle>
        <p className="text-sm text-muted-foreground">Preencha os dados da nova recepcionista</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nome">Nome Completo</Label>
            <Input id="nome" name="nome" value={formData.nome} onChange={handleChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="telefone">Telefone</Label>
            <Input id="telefone" name="telefone" value={formData.telefone} onChange={handleChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cpf">CPF</Label>
            <Input id="cpf" name="cpf" value={formData.cpf} onChange={handleChange} />
          </div>
          <div className="flex justify-end space-x-2 pt-6 pb-4">
            <Button type="button" variant="outline" onClick={() => router.back()}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? "Salvando..." : "Cadastrar Recepcionista"}</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
} 