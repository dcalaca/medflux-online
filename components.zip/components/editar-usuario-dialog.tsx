"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Edit, User, Mail, Phone, Calendar, Shield, Stethoscope, Building } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useToast } from "@/hooks/use-toast"

interface Clinica {
  id: string
  nome: string
  cnpj?: string
}

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  status_conta: string
  dias_teste_restantes?: number
  data_inicio_teste?: string
  created_at: string
  telefone?: string
  clinica_id?: string
  clinica?: Clinica
}

interface EditarUsuarioDialogProps {
  usuario: Usuario
  onUpdate: () => void
}

export function EditarUsuarioDialog({ usuario, onUpdate }: EditarUsuarioDialogProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [clinicas, setClinicas] = useState<Clinica[]>([])
  const [formData, setFormData] = useState({
    nome: usuario.nome,
    email: usuario.email,
    telefone: usuario.telefone || "",
    tipo: usuario.tipo,
    status_conta: usuario.status_conta,
    dias_teste_restantes: usuario.dias_teste_restantes || 0,
    clinica_id: usuario.clinica_id || "sem-clinica"
  })

  const { toast } = useToast()
  const supabase = createClient()

  useEffect(() => {
    if (open) {
      carregarClinicas()
    }
  }, [open])

  const carregarClinicas = async () => {
    try {
      const { data: clinicasData, error } = await supabase
        .from("clinicas")
        .select("id, nome, cnpj")
        .order("nome")

      if (error) {
        console.error("Erro ao carregar clínicas:", error)
        return
      }

      setClinicas(clinicasData || [])
    } catch (error) {
      console.error("Erro ao carregar clínicas:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const { error } = await supabase
        .from("usuarios")
        .update({
          nome: formData.nome,
          email: formData.email,
          telefone: formData.telefone || null,
          tipo: formData.tipo,
          status_conta: formData.status_conta,
          dias_teste_restantes: formData.dias_teste_restantes,
          clinica_id: formData.clinica_id === "sem-clinica" ? null : formData.clinica_id
        })
        .eq("id", usuario.id)

      if (error) {
        throw error
      }

      toast({
        title: "Usuário atualizado",
        description: "As informações foram salvas com sucesso.",
      })

      onUpdate()
      setOpen(false)
    } catch (error) {
      console.error("Erro ao atualizar usuário:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o usuário.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "admin": return <Shield className="h-4 w-4" />
      case "medico": return <Stethoscope className="h-4 w-4" />
      case "recepcionista": return <User className="h-4 w-4" />
      default: return <User className="h-4 w-4" />
    }
  }

  const getTipoLabel = (tipo: string) => {
    switch (tipo) {
      case "admin": return "Administrador"
      case "medico": return "Médico"
      case "recepcionista": return "Recepcionista"
      default: return tipo
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Edit className="h-3 w-3" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Editar Usuário</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Informações Básicas */}
          <div className="space-y-2">
            <Label htmlFor="nome">Nome</Label>
            <Input
              id="nome"
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="telefone">Telefone</Label>
            <Input
              id="telefone"
              value={formData.telefone}
              onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
              placeholder="(11) 99999-9999"
            />
          </div>

          {/* Clínica */}
          <div className="space-y-2">
            <Label htmlFor="clinica">Clínica</Label>
            <Select value={formData.clinica_id || "sem-clinica"} onValueChange={(value) => setFormData({ ...formData, clinica_id: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma clínica" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sem-clinica">Sem clínica</SelectItem>
                {clinicas.map((clinica) => (
                  <SelectItem key={clinica.id} value={clinica.id}>
                    <div className="flex items-center gap-2">
                      <Building className="h-4 w-4" />
                      {clinica.nome}
                      {clinica.cnpj && (
                        <span className="text-xs text-gray-500">({clinica.cnpj})</span>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Tipo de Usuário */}
          <div className="space-y-2">
            <Label htmlFor="tipo">Tipo de Usuário</Label>
            <Select value={formData.tipo} onValueChange={(value) => setFormData({ ...formData, tipo: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="medico">
                  <div className="flex items-center gap-2">
                    <Stethoscope className="h-4 w-4" />
                    Médico
                  </div>
                </SelectItem>
                <SelectItem value="recepcionista">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Recepcionista
                  </div>
                </SelectItem>
                <SelectItem value="admin">
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    Administrador
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Status da Conta */}
          <div className="space-y-2">
            <Label htmlFor="status">Status da Conta</Label>
            <Select value={formData.status_conta} onValueChange={(value) => setFormData({ ...formData, status_conta: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="teste">Em Teste</SelectItem>
                <SelectItem value="assinante">Assinante</SelectItem>
                <SelectItem value="expirado">Expirado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Dias Restantes (apenas para médicos) */}
          {formData.tipo === "medico" && (
            <div className="space-y-2">
              <Label htmlFor="dias">Dias de Teste Restantes</Label>
              <Input
                id="dias"
                type="number"
                min="0"
                max="365"
                value={formData.dias_teste_restantes}
                onChange={(e) => setFormData({ ...formData, dias_teste_restantes: parseInt(e.target.value) || 0 })}
              />
            </div>
          )}

          {/* Informações do Sistema */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-2">
            <h4 className="font-medium text-sm text-gray-700">Informações do Sistema</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">ID:</span>
                <p className="font-mono text-xs">{usuario.id}</p>
              </div>
              <div>
                <span className="text-gray-500">Cadastro:</span>
                <p>{format(new Date(usuario.created_at), "dd/MM/yyyy", { locale: ptBR })}</p>
              </div>
            </div>
          </div>

          {/* Botões */}
          <div className="flex gap-2 pt-4">
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? "Salvando..." : "Salvar Alterações"}
            </Button>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
} 