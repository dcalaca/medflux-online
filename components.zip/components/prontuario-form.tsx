"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Odontograma } from "./odontograma"
import { PrescricaoDigital } from "./prescricao-digital"

interface ProntuarioFormProps {
  pacienteId: string
  prontuarioId?: string
  initialData?: any
}

export function ProntuarioForm({ pacienteId, prontuarioId, initialData }: ProntuarioFormProps) {
  const [loading, setLoading] = useState(false)
  const [liberadoPaciente, setLiberadoPaciente] = useState(initialData?.liberado_paciente || false)
  const [formData, setFormData] = useState({
    queixa_principal: initialData?.queixa_principal || "",
    historia_doenca_atual: initialData?.historia_doenca_atual || "",
    exame_fisico: initialData?.exame_fisico || "",
    hipotese_diagnostica: initialData?.hipotese_diagnostica || "",
    receituario: initialData?.receituario || "",
    observacoes: initialData?.observacoes || "",
    data_consulta: initialData?.data_consulta || new Date().toISOString().split("T")[0],
  })

  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuário não autenticado")

      const prontuarioData = {
        ...formData,
        paciente_id: pacienteId,
        medico_id: user.id,
        liberado_paciente: liberadoPaciente,
        updated_at: new Date().toISOString(),
      }

      if (prontuarioId) {
        // Atualizar prontuário existente
        const { error } = await supabase.from("prontuarios").update(prontuarioData).eq("id", prontuarioId)

        if (error) throw error
        toast.success("Prontuário atualizado com sucesso!")
      } else {
        // Criar novo prontuário
        const { error } = await supabase.from("prontuarios").insert({
          ...prontuarioData,
          id: crypto.randomUUID(),
          created_at: new Date().toISOString(),
        })

        if (error) throw error
        toast.success("Prontuário criado com sucesso!")
      }

      router.push(`/pacientes/${pacienteId}`)
    } catch (error) {
      console.error("Erro ao salvar prontuário:", error)
      toast.error("Erro ao salvar prontuário")
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <Card>
        <CardHeader>
          <CardTitle>{prontuarioId ? "Editar Prontuário" : "Novo Prontuário"}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="data_consulta">Data da Consulta</Label>
                <Input
                  id="data_consulta"
                  type="date"
                  value={formData.data_consulta}
                  onChange={(e) => handleInputChange("data_consulta", e.target.value)}
                  required
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="liberado_paciente" checked={liberadoPaciente} onCheckedChange={setLiberadoPaciente} />
                <Label htmlFor="liberado_paciente">Liberar para visualização do paciente</Label>
              </div>
            </div>

            <Tabs defaultValue="anamnese" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="anamnese">Anamnese</TabsTrigger>
                <TabsTrigger value="exame">Exame</TabsTrigger>
                <TabsTrigger value="odontograma">Odontograma</TabsTrigger>
                <TabsTrigger value="prescricao">Prescrição</TabsTrigger>
              </TabsList>

              <TabsContent value="anamnese" className="space-y-4">
                <div>
                  <Label htmlFor="queixa_principal">Queixa Principal</Label>
                  <Textarea
                    id="queixa_principal"
                    placeholder="Descreva a queixa principal do paciente..."
                    value={formData.queixa_principal}
                    onChange={(e) => handleInputChange("queixa_principal", e.target.value)}
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="historia_doenca_atual">História da Doença Atual</Label>
                  <Textarea
                    id="historia_doenca_atual"
                    placeholder="Descreva a história da doença atual..."
                    value={formData.historia_doenca_atual}
                    onChange={(e) => handleInputChange("historia_doenca_atual", e.target.value)}
                    rows={4}
                  />
                </div>
              </TabsContent>

              <TabsContent value="exame" className="space-y-4">
                <div>
                  <Label htmlFor="exame_fisico">Exame Físico</Label>
                  <Textarea
                    id="exame_fisico"
                    placeholder="Descreva os achados do exame físico..."
                    value={formData.exame_fisico}
                    onChange={(e) => handleInputChange("exame_fisico", e.target.value)}
                    rows={4}
                  />
                </div>

                <div>
                  <Label htmlFor="hipotese_diagnostica">Hipótese Diagnóstica</Label>
                  <Textarea
                    id="hipotese_diagnostica"
                    placeholder="Descreva a hipótese diagnóstica..."
                    value={formData.hipotese_diagnostica}
                    onChange={(e) => handleInputChange("hipotese_diagnostica", e.target.value)}
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    placeholder="Observações adicionais..."
                    value={formData.observacoes}
                    onChange={(e) => handleInputChange("observacoes", e.target.value)}
                    rows={3}
                  />
                </div>
              </TabsContent>

              <TabsContent value="odontograma">
                <Odontograma pacienteId={pacienteId} />
              </TabsContent>

              <TabsContent value="prescricao">
                <PrescricaoDigital
                  pacienteId={pacienteId}
                  onPrescricaoChange={(prescricao) => handleInputChange("receituario", prescricao)}
                  initialValue={formData.receituario}
                />
              </TabsContent>
            </Tabs>

            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline" onClick={() => router.back()}>
                Cancelar
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? "Salvando..." : "Salvar Prontuário"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
