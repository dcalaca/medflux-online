"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, CreditCard } from "lucide-react"
import Link from "next/link"

export function TrialCountdown() {
  const [diasRestantes, setDiasRestantes] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    buscarDiasRestantes()

    // Atualizar a cada hora
    const interval = setInterval(buscarDiasRestantes, 60 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const buscarDiasRestantes = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        setLoading(false)
        return
      }

      const { data, error } = await supabase
        .from("usuarios")
        .select("status_conta, data_fim_teste")
        .eq("id", user.id)
        .single()

      if (error) {
        console.error("Erro ao buscar dias restantes:", error)
        setLoading(false)
        return
      }

      if (data) {
        // Se não for conta de teste, não mostrar o countdown
        if (data.status_conta !== "teste") {
          setDiasRestantes(null)
        } else {
          // Calcular dias restantes
          const dataFim = new Date(data.data_fim_teste)
          const agora = new Date()
          const diffTime = dataFim.getTime() - agora.getTime()
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
          setDiasRestantes(Math.max(0, diffDays))
        }
      }
    } catch (error) {
      console.error("Erro ao buscar dias restantes:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading || diasRestantes === null) {
    return null
  }

  const getCardColor = () => {
    if (diasRestantes <= 3) return "border-red-200 bg-red-50"
    if (diasRestantes <= 7) return "border-orange-200 bg-orange-50"
    return "border-blue-200 bg-blue-50"
  }

  const getTextColor = () => {
    if (diasRestantes <= 3) return "text-red-900"
    if (diasRestantes <= 7) return "text-orange-900"
    return "text-blue-900"
  }

  const getBadgeColor = () => {
    if (diasRestantes <= 3) return "bg-red-100 text-red-800"
    if (diasRestantes <= 7) return "bg-orange-100 text-orange-800"
    return "bg-blue-100 text-blue-800"
  }

  return (
    <Card className={`${getCardColor()} border-2`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className={`h-5 w-5 ${getTextColor()}`} />
            <div>
              <p className={`font-semibold ${getTextColor()}`}>Período de teste</p>
              <p className="text-sm text-gray-600">Aproveite todos os recursos do MedFlux gratuitamente.</p>
            </div>
          </div>
          <div className="text-right">
            <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getBadgeColor()}`}>
              {diasRestantes} {diasRestantes === 1 ? "dia restante" : "dias restantes"}
            </div>
            <div className="mt-2">
              <Button asChild size="sm" variant="outline">
                <Link href="/planos">
                  <CreditCard className="w-4 h-4 mr-1" />
                  Ver Planos
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
