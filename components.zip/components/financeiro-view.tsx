"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import { DollarSign, TrendingUp, Clock, CheckCircle, Calendar } from "lucide-react"
import { ExportReports } from "./export-reports"

interface Consulta {
  id: string
  data_hora: string
  valor: number | null
  status: string
  status_pagamento: string
  forma_pagamento: string | null
  pacientes: {
    nome: string
  } | null
  tipos_consulta: {
    nome: string
    cor: string
  } | null
}

interface FinanceiroViewProps {
  consultas: Consulta[]
}

export function FinanceiroView({ consultas }: FinanceiroViewProps) {
  const [loading, setLoading] = useState<string | null>(null)
  const [filtroMes, setFiltroMes] = useState(new Date().getMonth().toString())
  const [filtroAno, setFiltroAno] = useState(new Date().getFullYear().toString())
  const { toast } = useToast()
  const supabase = createClient()

  // Filtrar consultas por mês/ano
  const consultasFiltradas = consultas.filter((consulta) => {
    const data = new Date(consulta.data_hora)
    return data.getMonth() === Number.parseInt(filtroMes) && data.getFullYear() === Number.parseInt(filtroAno)
  })

  // Calcular totais
  const totalFaturamento = consultasFiltradas
    .filter((c) => c.status_pagamento === "pago" && c.valor)
    .reduce((total, c) => total + (c.valor || 0), 0)

  const totalPendente = consultasFiltradas
    .filter((c) => c.status_pagamento === "pendente" && c.valor)
    .reduce((total, c) => total + (c.valor || 0), 0)

  const totalConsultas = consultasFiltradas.length
  const consultasPagas = consultasFiltradas.filter((c) => c.status_pagamento === "pago").length

  const handleMarcarComoPago = async (consultaId: string) => {
    setLoading(consultaId)
    try {
      const { error } = await supabase.from("consultas").update({ status_pagamento: "pago" }).eq("id", consultaId)

      if (error) throw error

      toast({
        title: "Pagamento confirmado!",
        description: "O status do pagamento foi atualizado.",
      })

      // Atualizar a consulta localmente
      const consulta = consultas.find((c) => c.id === consultaId)
      if (consulta) {
        consulta.status_pagamento = "pago"
      }
    } catch (error) {
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar o pagamento.",
        variant: "destructive",
      })
    } finally {
      setLoading(null)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pago":
        return "bg-green-100 text-green-800"
      case "pendente":
        return "bg-yellow-100 text-yellow-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const meses = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ]

  const anos = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Controle Financeiro</h1>
          <p className="text-muted-foreground">Acompanhe seus recebimentos e pagamentos</p>
        </div>
        <div className="flex space-x-2">
          <Select value={filtroMes} onValueChange={setFiltroMes}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {meses.map((mes, index) => (
                <SelectItem key={index} value={index.toString()}>
                  {mes}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filtroAno} onValueChange={setFiltroAno}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {anos.map((ano) => (
                <SelectItem key={ano} value={ano.toString()}>
                  {ano}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Cards de resumo */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Faturamento</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalFaturamento)}</div>
            <p className="text-xs text-muted-foreground">Recebido no período</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendente</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{formatCurrency(totalPendente)}</div>
            <p className="text-xs text-muted-foreground">A receber</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Consultas</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalConsultas}</div>
            <p className="text-xs text-muted-foreground">Total no período</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Recebimento</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalConsultas > 0 ? Math.round((consultasPagas / totalConsultas) * 100) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">Consultas pagas</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="consultas" className="space-y-4">
        <TabsList>
          <TabsTrigger value="consultas">Consultas</TabsTrigger>
          <TabsTrigger value="pendentes">Pendentes</TabsTrigger>
          <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
        </TabsList>

        <TabsContent value="consultas">
          <Card>
            <CardHeader>
              <CardTitle>Todas as Consultas</CardTitle>
              <CardDescription>
                {meses[Number.parseInt(filtroMes)]} de {filtroAno} - {consultasFiltradas.length} consultas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto w-full max-w-full">
                <Table className="min-w-[600px]">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {consultasFiltradas.map((consulta) => (
                      <TableRow key={consulta.id}>
                        <TableCell>{formatDate(consulta.data_hora)}</TableCell>
                        <TableCell>{consulta.pacientes?.nome}</TableCell>
                        <TableCell>
                          {consulta.tipos_consulta && (
                            <Badge
                              style={{
                                backgroundColor: consulta.tipos_consulta.cor + "20",
                                color: consulta.tipos_consulta.cor,
                              }}
                              variant="outline"
                            >
                              {consulta.tipos_consulta.nome}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{consulta.valor ? formatCurrency(consulta.valor) : "-"}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(consulta.status_pagamento)}>{consulta.status_pagamento}</Badge>
                        </TableCell>
                        <TableCell>
                          {consulta.status_pagamento === "pendente" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleMarcarComoPago(consulta.id)}
                              disabled={loading === consulta.id}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              {loading === consulta.id ? "..." : "Pago"}
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pendentes">
          <Card>
            <CardHeader>
              <CardTitle>Pagamentos Pendentes</CardTitle>
              <CardDescription>Consultas com pagamento em aberto</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto w-full max-w-full">
                <Table className="min-w-[600px]">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {consultasFiltradas
                      .filter((c) => c.status_pagamento === "pendente")
                      .map((consulta) => (
                        <TableRow key={consulta.id}>
                          <TableCell>{formatDate(consulta.data_hora)}</TableCell>
                          <TableCell>{consulta.pacientes?.nome}</TableCell>
                          <TableCell className="font-medium">
                            {consulta.valor ? formatCurrency(consulta.valor) : "-"}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              onClick={() => handleMarcarComoPago(consulta.id)}
                              disabled={loading === consulta.id}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              {loading === consulta.id ? "..." : "Marcar como Pago"}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="relatorios">
          <ExportReports
            consultas={consultasFiltradas}
            filtroMes={filtroMes}
            filtroAno={filtroAno}
            totalFaturamento={totalFaturamento}
            totalPendente={totalPendente}
            totalConsultas={totalConsultas}
            consultasPagas={consultasPagas}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
