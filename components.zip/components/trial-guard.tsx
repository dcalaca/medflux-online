"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CreditCard, Clock } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

interface TrialGuardProps {
  children: React.ReactNode
}

export function TrialGuard({ children }: TrialGuardProps) {
  const [trialExpired, setTrialExpired] = useState(false)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    verificarTrial()
  }, [])

  const verificarTrial = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        setLoading(false)
        return
      }

      // Verificar diretamente na tabela usuarios
      const { data, error } = await supabase
        .from("usuarios")
        .select("status_conta, data_fim_teste")
        .eq("id", user.id)
        .single()

      if (error) {
        console.error("Erro ao verificar trial:", error)
        setLoading(false)
        return
      }

      if (data) {
        // Se não for conta de teste, permitir acesso
        if (data.status_conta !== "teste") {
          setTrialExpired(false)
        } else {
          // Verificar se o trial expirou
          const dataFim = new Date(data.data_fim_teste)
          const agora = new Date()
          setTrialExpired(agora > dataFim)
        }
      }
    } catch (error) {
      console.error("Erro ao verificar trial:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Verificando acesso...</p>
        </div>
      </div>
    )
  }

  if (trialExpired) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4">
              <Image src="/logo-medflux.png" alt="MedFlux" width={64} height={64} />
            </div>
            <AlertTriangle className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <CardTitle className="text-xl text-gray-900">Período de teste expirado</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-600">
              Seus dias de teste da plataforma acabaram. Para continuar usando o MedFlux, favor efetuar o pagamento de
              um plano.
            </p>

            <div className="bg-blue-50 p-4 rounded-lg">
              <Clock className="mx-auto h-8 w-8 text-blue-600 mb-2" />
              <p className="text-sm text-blue-800">
                Durante o período de teste você teve acesso completo a todas as funcionalidades do sistema.
              </p>
            </div>

            <div className="space-y-3">
              <Button asChild className="w-full" size="lg">
                <Link href="/planos">
                  <CreditCard className="w-5 h-5 mr-2" />
                  Ver Planos e Assinar
                </Link>
              </Button>

              <Button asChild variant="outline" className="w-full bg-transparent">
                <Link href="/login">Fazer Logout</Link>
              </Button>
            </div>

            <p className="text-xs text-gray-500">Precisa de ajuda? Entre em contato com nosso suporte.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return <>{children}</>
}
