"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import { Plus, Edit, Trash2, Stethoscope } from "lucide-react"

interface Especialidade {
  id: string
  nome: string
  ativo: boolean
  created_at: string
  updated_at: string
}

interface EspecialidadesViewProps {
  especialidades: Especialidade[]
}

export function EspecialidadesView({ especialidades: initialEspecialidades }: EspecialidadesViewProps) {
  const [especialidades, setEspecialidades] = useState(initialEspecialidades)
  const [loading, setLoading] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingEspecialidade, setEditingEspecialidade] = useState<Especialidade | null>(null)
  const [formData, setFormData] = useState({
    nome: "",
    ativo: true,
  })

  const { toast } = useToast()
  const supabase = createClient()

  const resetForm = () => {
    setFormData({
      nome: "",
      ativo: true,
    })
    setEditingEspecialidade(null)
  }

  const handleOpenDialog = (especialidade?: Especialidade) => {
    if (especialidade) {
      setEditingEspecialidade(especialidade)
      setFormData({
        nome: especialidade.nome,
        ativo: especialidade.ativo,
      })
    } else {
      resetForm()
    }
    setDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setDialogOpen(false)
    resetForm()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.nome.trim()) {
      toast({
        title: "Erro",
        description: "Nome da especialidade é obrigatório.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      if (editingEspecialidade) {
        // Atualizar especialidade existente
        const { data, error } = await supabase
          .from("especialidades")
          .update({
            nome: formData.nome.trim(),
            ativo: formData.ativo,
            updated_at: new Date().toISOString(),
          })
          .eq("id", editingEspecialidade.id)
          .select()
          .single()

        if (error) throw error

        setEspecialidades((prev) => prev.map((esp) => (esp.id === editingEspecialidade.id ? data : esp)))

        toast({
          title: "Especialidade atualizada!",
          description: "A especialidade foi atualizada com sucesso.",
        })
      } else {
        // Criar nova especialidade
        const { data, error } = await supabase
          .from("especialidades")
          .insert({
            nome: formData.nome.trim(),
            ativo: formData.ativo,
          })
          .select()
          .single()

        if (error) throw error

        setEspecialidades((prev) => [...prev, data])

        toast({
          title: "Especialidade criada!",
          description: "A nova especialidade foi criada com sucesso.",
        })
      }

      handleCloseDialog()
    } catch (error: any) {
      console.error("Erro ao salvar especialidade:", error)

      let errorMessage = "Ocorreu um erro ao salvar a especialidade."
      if (error.message?.includes("duplicate key")) {
        errorMessage = "Já existe uma especialidade com este nome."
      }

      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleToggleAtivo = async (especialidade: Especialidade) => {
    setLoading(true)

    try {
      const { data, error } = await supabase
        .from("especialidades")
        .update({
          ativo: !especialidade.ativo,
          updated_at: new Date().toISOString(),
        })
        .eq("id", especialidade.id)
        .select()
        .single()

      if (error) throw error

      setEspecialidades((prev) => prev.map((esp) => (esp.id === especialidade.id ? data : esp)))

      toast({
        title: "Status atualizado!",
        description: `Especialidade ${data.ativo ? "ativada" : "desativada"} com sucesso.`,
      })
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status da especialidade.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (especialidade: Especialidade) => {
    if (!confirm(`Tem certeza que deseja excluir a especialidade "${especialidade.nome}"?`)) {
      return
    }

    setLoading(true)

    try {
      const { error } = await supabase.from("especialidades").delete().eq("id", especialidade.id)

      if (error) throw error

      setEspecialidades((prev) => prev.filter((esp) => esp.id !== especialidade.id))

      toast({
        title: "Especialidade excluída!",
        description: "A especialidade foi excluída com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao excluir especialidade:", error)
      toast({
        title: "Erro",
        description: "Não foi possível excluir a especialidade.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const especialidadesAtivas = especialidades.filter((esp) => esp.ativo).length
  const especialidadesInativas = especialidades.filter((esp) => !esp.ativo).length

  return (
    <div className="px-2 sm:px-0">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Especialidades Médicas</h1>
          <p className="text-muted-foreground">Gerencie as especialidades disponíveis no sistema</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Nova Especialidade
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingEspecialidade ? "Editar Especialidade" : "Nova Especialidade"}</DialogTitle>
              <DialogDescription>
                {editingEspecialidade
                  ? "Edite as informações da especialidade."
                  : "Adicione uma nova especialidade médica ao sistema."}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome da Especialidade</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                    placeholder="Digite o nome da especialidade"
                    required
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="ativo"
                    checked={formData.ativo}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, ativo: checked }))}
                  />
                  <Label htmlFor="ativo">Especialidade ativa</Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? "Salvando..." : editingEspecialidade ? "Atualizar" : "Criar"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Estatísticas */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Especialidades</CardTitle>
            <Stethoscope className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{especialidades.length}</div>
            <p className="text-xs text-muted-foreground">Especialidades cadastradas</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Especialidades Ativas</CardTitle>
            <Stethoscope className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{especialidadesAtivas}</div>
            <p className="text-xs text-muted-foreground">Disponíveis para seleção</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Especialidades Inativas</CardTitle>
            <Stethoscope className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{especialidadesInativas}</div>
            <p className="text-xs text-muted-foreground">Desabilitadas</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabela de especialidades */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Especialidades</CardTitle>
          <CardDescription>Gerencie todas as especialidades médicas do sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto w-full max-w-full">
            <Table className="min-w-[600px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Criado em</TableHead>
                  <TableHead>Atualizado em</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {especialidades.map((especialidade) => (
                  <TableRow key={especialidade.id}>
                    <TableCell className="font-medium">{especialidade.nome}</TableCell>
                    <TableCell>
                      <Badge variant={especialidade.ativo ? "default" : "secondary"}>
                        {especialidade.ativo ? "Ativa" : "Inativa"}
                      </Badge>
                    </TableCell>
                    <TableCell>{new Date(especialidade.created_at).toLocaleDateString("pt-BR")}</TableCell>
                    <TableCell>{new Date(especialidade.updated_at).toLocaleDateString("pt-BR")}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleToggleAtivo(especialidade)}
                          disabled={loading}
                        >
                          {especialidade.ativo ? "Desativar" : "Ativar"}
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleOpenDialog(especialidade)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(especialidade)} disabled={loading}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
