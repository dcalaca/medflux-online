"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import { FileText } from "lucide-react"

interface ProntuarioDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultaId: string
  pacienteId: string
  medicoId: string
  clinicaId: string
  onProntuarioSalvo: () => void
}

export function ProntuarioDialog({
  open,
  onOpenChange,
  consultaId,
  pacienteId,
  medicoId,
  clinicaId,
  onProntuarioSalvo,
}: ProntuarioDialogProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    tipo_consulta: "",
    diagnostico: "",
    evolucao: "",
    conduta: "",
    medicamentos: "",
    observacoes_privadas: "",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const supabase = createClient()

      const { error } = await supabase.from("prontuarios").insert({
        paciente_id: pacienteId,
        medico_id: medicoId,
        consulta_id: consultaId,
        clinica_id: clinicaId,
        tipo_consulta: formData.tipo_consulta,
        diagnostico: formData.diagnostico,
        evolucao: formData.evolucao,
        conduta: formData.conduta,
        medicamentos: formData.medicamentos,
        observacoes_privadas: formData.observacoes_privadas,
        liberado_paciente: false,
      })

      if (error) throw error

      toast({
        title: "Prontuário salvo!",
        description: "As informações da consulta foram registradas.",
      })

      setFormData({
        tipo_consulta: "",
        diagnostico: "",
        evolucao: "",
        conduta: "",
        medicamentos: "",
        observacoes_privadas: "",
      })

      onProntuarioSalvo()
      onOpenChange(false)
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar o prontuário.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span>Prontuário da Consulta</span>
          </DialogTitle>
          <DialogDescription>Registre as informações médicas da consulta</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4 max-h-96 overflow-y-auto">
            <div className="space-y-2">
              <Label htmlFor="tipo_consulta">Tipo de Consulta</Label>
              <Input
                id="tipo_consulta"
                value={formData.tipo_consulta}
                onChange={(e) => setFormData({ ...formData, tipo_consulta: e.target.value })}
                placeholder="Ex: Consulta inicial, Retorno..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="diagnostico">Diagnóstico</Label>
              <Textarea
                id="diagnostico"
                value={formData.diagnostico}
                onChange={(e) => setFormData({ ...formData, diagnostico: e.target.value })}
                placeholder="Diagnóstico principal e secundários..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="evolucao">Evolução/Exame Físico</Label>
              <Textarea
                id="evolucao"
                value={formData.evolucao}
                onChange={(e) => setFormData({ ...formData, evolucao: e.target.value })}
                placeholder="Descrição do exame físico e evolução do quadro..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="conduta">Conduta</Label>
              <Textarea
                id="conduta"
                value={formData.conduta}
                onChange={(e) => setFormData({ ...formData, conduta: e.target.value })}
                placeholder="Orientações, procedimentos, encaminhamentos..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="medicamentos">Medicamentos</Label>
              <Textarea
                id="medicamentos"
                value={formData.medicamentos}
                onChange={(e) => setFormData({ ...formData, medicamentos: e.target.value })}
                placeholder="Prescrições e medicamentos..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="observacoes_privadas">Observações Privadas</Label>
              <Textarea
                id="observacoes_privadas"
                value={formData.observacoes_privadas}
                onChange={(e) => setFormData({ ...formData, observacoes_privadas: e.target.value })}
                placeholder="Anotações privadas do médico..."
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Salvando..." : "Salvar Prontuário"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
