import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Calendar, Users, UserPlus, FileText, BarChart3, DollarSign, Settings, Shield, Building } from "lucide-react"

interface NavItem {
  href: string
  label: string
  icon: any
}

interface BottomNavBarProps {
  userType: string
}

const medicoNav: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/agenda", label: "Agenda", icon: Calendar },
  { href: "/pacientes", label: "Pacientes", icon: Users },
  { href: "/usuarios", label: "Usuários", icon: Users },
  { href: "/tipos-consulta", label: "Tipos de Consulta", icon: FileText },
  { href: "/convenios", label: "Convênios", icon: FileText },
  { href: "/especialidades", label: "Especialidades", icon: FileText },
  { href: "/relatorios", label: "Relatórios", icon: BarChart3 },
  { href: "/financeiro", label: "Financeiro", icon: DollarSign },
  { href: "/meus-dados", label: "Meus Dados", icon: Settings },
]

const recepcionistaSection: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/agenda", label: "Agenda", icon: Calendar },
  { href: "/pacientes", label: "Pacientes", icon: Users },
  { href: "/pacientes/novo", label: "Novo Paciente", icon: UserPlus },
  { href: "/meus-dados", label: "Meus Dados", icon: Settings },
]

const adminSection: NavItem[] = [
  { href: "/admin", label: "Administração", icon: Shield },
  { href: "/admin/relatorios", label: "Relatórios", icon: BarChart3 },
  { href: "/admin/gestao-financeira", label: "Gestão Financeira", icon: DollarSign },
  { href: "/admin/gestao-usuarios", label: "Gestão de Usuários", icon: Users },
  { href: "/admin/gestao-clinicas", label: "Gestão de Clínicas", icon: Building },
]

export function BottomNavBar({ userType }: BottomNavBarProps) {
  const pathname = usePathname()
  const navigationItems = userType === "admin" ? adminSection : userType === "recepcionista" ? recepcionistaSection : medicoNav

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
      <ul className="flex overflow-x-auto no-scrollbar">
        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <li key={item.href} className="flex-1 min-w-[80px]">
              <Link href={item.href} className="flex flex-col items-center justify-center py-2 px-3 hover:bg-gray-100 transition-all">
                <Icon className={`h-5 w-5 mb-1 ${isActive ? "text-blue-600" : "text-gray-500"}`} />
                <span className={`text-xs ${isActive ? "text-blue-600 font-semibold" : "text-gray-700"}`}>{item.label}</span>
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
} 