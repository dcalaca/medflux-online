"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Eye, Phone, Mail, User, Calendar, CreditCard, Clock } from "lucide-react"
import Link from "next/link"
import type { Paciente } from "@/types/database.types"

interface PacientesTableProps {
  pacientes: Paciente[]
}

export function PacientesTable({ pacientes }: PacientesTableProps) {
  const [filteredPacientes, setFilteredPacientes] = useState(pacientes)

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatPhone = (phone: string | null) => {
    if (!phone) return "-"
    return phone.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
  }

  const formatCPF = (cpf: string | null) => {
    if (!cpf) return "-"
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  return (
    <>
      {/* Tabela Desktop */}
      <div className="hidden lg:block rounded-md border overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>CPF</TableHead>
              <TableHead>Nascimento</TableHead>
              <TableHead>Contato</TableHead>
              <TableHead>Convênio</TableHead>
              <TableHead>Cadastro</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPacientes.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  <div className="text-muted-foreground">Nenhum paciente encontrado</div>
                </TableCell>
              </TableRow>
            ) : (
              filteredPacientes.map((paciente) => (
                <TableRow key={paciente.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{paciente.nome}</div>
                      <div className="text-sm text-muted-foreground capitalize">{paciente.genero}</div>
                    </div>
                  </TableCell>
                  <TableCell>{formatCPF(paciente.cpf)}</TableCell>
                  <TableCell>{paciente.nascimento ? formatDate(paciente.nascimento) : "-"}</TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      {paciente.telefone && (
                        <div className="flex items-center text-sm">
                          <Phone className="w-3 h-3 mr-1" />
                          {formatPhone(paciente.telefone)}
                        </div>
                      )}
                      {paciente.email && (
                        <div className="flex items-center text-sm">
                          <Mail className="w-3 h-3 mr-1" />
                          {paciente.email}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    {paciente.convenio ? (
                      <Badge variant="secondary">{paciente.convenio}</Badge>
                    ) : (
                      <Badge variant="outline">Particular</Badge>
                    )}
                  </TableCell>
                  <TableCell>{formatDate(paciente.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/pacientes/${paciente.id}`}>
                        <Eye className="w-4 h-4" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Cards Mobile */}
      <div className="lg:hidden space-y-4">
        {filteredPacientes.length === 0 ? (
          <Card>
            <CardContent className="flex items-center justify-center py-8">
              <div className="text-center text-muted-foreground">
                <User className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Nenhum paciente encontrado</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredPacientes.map((paciente) => (
            <Card key={paciente.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg leading-tight">{paciente.nome}</h3>
                    <p className="text-sm text-muted-foreground capitalize">{paciente.genero}</p>
                  </div>
                  <Button variant="ghost" size="sm" asChild className="ml-2">
                    <Link href={`/pacientes/${paciente.id}`}>
                      <Eye className="w-4 h-4" />
                    </Link>
                  </Button>
                </div>

                <div className="space-y-2">
                  {/* CPF */}
                  <div className="flex items-center text-sm">
                    <CreditCard className="w-4 h-4 mr-2 text-muted-foreground" />
                    <span className="text-muted-foreground mr-2">CPF:</span>
                    <span>{formatCPF(paciente.cpf)}</span>
                  </div>

                  {/* Nascimento */}
                  {paciente.nascimento && (
                    <div className="flex items-center text-sm">
                      <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground mr-2">Nascimento:</span>
                      <span>{formatDate(paciente.nascimento)}</span>
                    </div>
                  )}

                  {/* Telefone */}
                  {paciente.telefone && (
                    <div className="flex items-center text-sm">
                      <Phone className="w-4 h-4 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground mr-2">Telefone:</span>
                      <span>{formatPhone(paciente.telefone)}</span>
                    </div>
                  )}

                  {/* Email */}
                  {paciente.email && (
                    <div className="flex items-center text-sm">
                      <Mail className="w-4 h-4 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground mr-2">Email:</span>
                      <span className="break-all">{paciente.email}</span>
                    </div>
                  )}

                  {/* Convênio e Data de Cadastro */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="flex items-center">
                      {paciente.convenio ? (
                        <Badge variant="secondary" className="text-xs">
                          {paciente.convenio}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-xs">
                          Particular
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatDate(paciente.created_at)}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </>
  )
}
