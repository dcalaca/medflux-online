"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  DollarSign, 
  Users, 
  CreditCard, 
  CheckCircle, 
  AlertCircle, 
  Download, 
  Search,
  Filter,
  BarChart3,
  TrendingUp,
  Calendar,
  Mail,
  Phone,
  Building
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Cliente {
  id: string
  nome: string
  email: string
  telefone?: string
  tipo: string
  status_conta: string
  dias_teste_restantes?: number
  data_inicio_teste?: string
  created_at: string
  pagamentos?: Pagamento[]
}

interface Pagamento {
  id: string
  valor: number
  status: string
  created_at: string
  data_pagamento?: string
  metodo_pagamento?: string
}

export default function RelatoriosAdminView() {
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("todos")
  const [stats, setStats] = useState({
    totalClientes: 0,
    clientesAtivos: 0,
    clientesExpirados: 0,
    receitaTotal: 0,
    pagamentosPendentes: 0
  })

  const supabase = createClient()

  useEffect(() => {
    carregarRelatorios()
  }, [])

  const carregarRelatorios = async () => {
    try {
      setLoading(true)

      // Buscar todos os clientes (médicos)
      const { data: clientesData, error: clientesError } = await supabase
        .from("usuarios")
        .select("*")
        .eq("tipo", "medico")
        .order("created_at", { ascending: false })

      if (clientesError) {
        console.error("Erro ao buscar clientes:", clientesError)
        return
      }

      // Buscar pagamentos para cada cliente
      const clientesComPagamentos = await Promise.all(
        (clientesData || []).map(async (cliente) => {
          const { data: pagamentos } = await supabase
            .from("pagamentos")
            .select("*")
            .eq("usuario_id", cliente.id)
            .order("created_at", { ascending: false })

          return {
            ...cliente,
            pagamentos: pagamentos || []
          }
        })
      )

      setClientes(clientesComPagamentos)

      // Calcular estatísticas
      const totalClientes = clientesComPagamentos.length
      const clientesAtivos = clientesComPagamentos.filter(c => c.status_conta === "assinante").length
      const clientesExpirados = clientesComPagamentos.filter(c => c.status_conta === "expirado").length
      
      const receitaTotal = clientesComPagamentos.reduce((total, cliente) => {
        const pagamentosPagos = cliente.pagamentos?.filter(p => p.status === "pago") || []
        return total + pagamentosPagos.reduce((sum, p) => sum + Number(p.valor), 0)
      }, 0)

      const pagamentosPendentes = clientesComPagamentos.reduce((total, cliente) => {
        const pendentes = cliente.pagamentos?.filter(p => p.status === "pendente") || []
        return total + pendentes.length
      }, 0)

      setStats({
        totalClientes,
        clientesAtivos,
        clientesExpirados,
        receitaTotal,
        pagamentosPendentes
      })

    } catch (error) {
      console.error("Erro ao carregar relatórios:", error)
    } finally {
      setLoading(false)
    }
  }

  const filtrarClientes = () => {
    let filtrados = clientes

    // Filtro por busca
    if (searchTerm) {
      filtrados = filtrados.filter(cliente =>
        cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.email.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filtro por status
    if (statusFilter !== "todos") {
      filtrados = filtrados.filter(cliente => cliente.status_conta === statusFilter)
    }

    return filtrados
  }

  const exportarRelatorio = () => {
    const dados = filtrarClientes()
    const csvContent = [
      ["Nome", "Email", "Telefone", "Status", "Dias Restantes", "Data Cadastro", "Total Pagamentos", "Receita Total"],
      ...dados.map(cliente => [
        cliente.nome,
        cliente.email,
        cliente.telefone || "",
        cliente.status_conta,
        cliente.dias_teste_restantes?.toString() || "",
        format(new Date(cliente.created_at), "dd/MM/yyyy", { locale: ptBR }),
        cliente.pagamentos?.length.toString() || "0",
        cliente.pagamentos?.filter(p => p.status === "pago").reduce((sum, p) => sum + Number(p.valor), 0).toString() || "0"
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `relatorio-clientes-${format(new Date(), "dd-MM-yyyy")}.csv`
    a.click()
  }

  const clientesFiltrados = filtrarClientes()

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando relatórios...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="px-2 sm:px-0">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Relatórios de Gestão</h1>
        <p className="text-gray-600 mt-2">Relatórios completos dos clientes do MedFlux</p>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalClientes}</div>
            <p className="text-xs text-muted-foreground">Médicos cadastrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Ativos</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.clientesAtivos}</div>
            <p className="text-xs text-muted-foreground">Assinaturas ativas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Expirados</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.clientesExpirados}</div>
            <p className="text-xs text-muted-foreground">Período expirado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {stats.receitaTotal.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Receita realizada</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagamentos Pendentes</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pagamentosPendentes}</div>
            <p className="text-xs text-muted-foreground">Aguardando pagamento</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Busca */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros e Busca</CardTitle>
          <CardDescription>Filtre e busque clientes específicos</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por nome ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-full md:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="teste">Em Teste</SelectItem>
                  <SelectItem value="assinante">Assinante</SelectItem>
                  <SelectItem value="expirado">Expirado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={exportarRelatorio} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Exportar CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Clientes */}
      <Card>
        <CardHeader>
          <CardTitle>Relatório Completo de Clientes</CardTitle>
          <CardDescription>
            {clientesFiltrados.length} cliente(s) encontrado(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto w-full max-w-full">
            <Table className="min-w-[600px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Dias Restantes</TableHead>
                  <TableHead>Data Cadastro</TableHead>
                  <TableHead>Pagamentos</TableHead>
                  <TableHead>Receita</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clientesFiltrados.map((cliente) => {
                  const pagamentosPagos = cliente.pagamentos?.filter(p => p.status === "pago") || []
                  const pagamentosPendentes = cliente.pagamentos?.filter(p => p.status === "pendente") || []
                  const receitaTotal = pagamentosPagos.reduce((sum, p) => sum + Number(p.valor), 0)

                  return (
                    <TableRow key={cliente.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{cliente.nome}</div>
                          <div className="text-sm text-gray-500">{cliente.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {cliente.telefone && (
                            <div className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              <span className="text-sm">{cliente.telefone}</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            cliente.status_conta === "assinante"
                              ? "default"
                              : cliente.status_conta === "teste"
                              ? "secondary"
                              : "destructive"
                          }
                        >
                          {cliente.status_conta === "assinante" && "✅ Assinante"}
                          {cliente.status_conta === "teste" && "⏳ Em Teste"}
                          {cliente.status_conta === "expirado" && "🔒 Expirado"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {cliente.dias_teste_restantes !== null ? (
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{cliente.dias_teste_restantes}</span>
                            <span className="text-sm text-gray-500">dias</span>
                          </div>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {format(new Date(cliente.created_at), "dd/MM/yyyy", { locale: ptBR })}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-3 w-3 text-green-600" />
                            <span className="text-sm">{pagamentosPagos.length} pagos</span>
                          </div>
                          {pagamentosPendentes.length > 0 && (
                            <div className="flex items-center gap-2">
                              <AlertCircle className="h-3 w-3 text-orange-600" />
                              <span className="text-sm">{pagamentosPendentes.length} pendentes</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">R$ {receitaTotal.toFixed(2)}</div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 