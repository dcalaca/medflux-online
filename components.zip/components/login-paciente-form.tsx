"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export function LoginPacienteForm() {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    cpf: "",
    nascimento: "",
  })

  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Buscar paciente pelo CPF e data de nascimento
      const { data: paciente, error } = await supabase
        .from("pacientes")
        .select("*")
        .eq("cpf", formData.cpf.replace(/\D/g, ""))
        .eq("nascimento", formData.nascimento)
        .single()

      if (error || !paciente) {
        toast.error("CPF ou data de nascimento incorretos")
        return
      }

      // Gerar token de acesso se não existir
      let tokenAcesso = paciente.token_acesso
      if (!tokenAcesso) {
        tokenAcesso = crypto.randomUUID()

        const { error: updateError } = await supabase
          .from("pacientes")
          .update({ token_acesso: tokenAcesso })
          .eq("id", paciente.id)

        if (updateError) {
          throw updateError
        }
      }

      // Fazer login com o token
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: `${tokenAcesso}@paciente.local`,
        password: tokenAcesso,
      })

      if (signInError) {
        // Se não conseguir fazer login, criar usuário temporário
        const { error: signUpError } = await supabase.auth.signUp({
          email: `${tokenAcesso}@paciente.local`,
          password: tokenAcesso,
        })

        if (signUpError) {
          throw signUpError
        }
      }

      toast.success("Login realizado com sucesso!")
      router.push("/paciente")
    } catch (error) {
      console.error("Erro no login:", error)
      toast.error("Erro ao fazer login")
    } finally {
      setLoading(false)
    }
  }

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCPF(e.target.value)
    setFormData((prev) => ({ ...prev, cpf: formatted }))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Acesso do Paciente</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="cpf">CPF</Label>
            <Input
              id="cpf"
              type="text"
              placeholder="000.000.000-00"
              value={formData.cpf}
              onChange={handleCPFChange}
              maxLength={14}
              required
            />
          </div>

          <div>
            <Label htmlFor="nascimento">Data de Nascimento</Label>
            <Input
              id="nascimento"
              type="date"
              value={formData.nascimento}
              onChange={(e) => setFormData((prev) => ({ ...prev, nascimento: e.target.value }))}
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Entrando..." : "Entrar"}
          </Button>
        </form>

        <div className="mt-4 text-center text-sm text-gray-600">
          <p>Para acessar sua área, informe seu CPF e data de nascimento cadastrados na clínica.</p>
        </div>
      </CardContent>
    </Card>
  )
}
