"use client"

import React from "react"
import { cn } from "@/lib/utils"

interface ResponsiveTableProps {
  children: React.ReactNode
  className?: string
}

export function ResponsiveTable({ children, className }: ResponsiveTableProps) {
  return (
    <div className={cn("table-responsive overflow-x-auto", className)}>
      <div className="min-w-full inline-block align-middle">
        <div className="overflow-hidden">
          {children}
        </div>
      </div>
    </div>
  )
}

interface ResponsiveTableHeaderProps {
  children: React.ReactNode
  className?: string
}

export function ResponsiveTableHeader({ children, className }: ResponsiveTableHeaderProps) {
  return (
    <div className={cn("bg-gray-50 border-b border-gray-200", className)}>
      {children}
    </div>
  )
}

interface ResponsiveTableRowProps {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export function ResponsiveTableRow({ children, className, onClick }: ResponsiveTableRowProps) {
  return (
    <div 
      className={cn(
        "border-b border-gray-200 hover:bg-gray-50 transition-colors",
        onClick && "cursor-pointer",
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

interface ResponsiveTableCellProps {
  children: React.ReactNode
  className?: string
  mobileLabel?: string
}

export function ResponsiveTableCell({ children, className, mobileLabel }: ResponsiveTableCellProps) {
  return (
    <div className={cn("px-6 py-4 whitespace-nowrap", className)}>
      {mobileLabel && (
        <div className="lg:hidden text-sm font-medium text-gray-500 mb-1">
          {mobileLabel}
        </div>
      )}
      <div className="text-sm text-gray-900">
        {children}
      </div>
    </div>
  )
} 
