"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { 
  Building, 
  Users, 
  UserCheck, 
  UserX, 
  DollarSign,
  Calendar,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Edit,
  Trash2,
  Check,
  ChevronsUpDown,
  MapPin,
  Phone,
  Mail
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { VisualizarClinicaDialog } from "./visualizar-clinica-dialog"
import { EditarClinicaDialog } from "./editar-clinica-dialog"
import { DeletarClinicaDialog } from "./deletar-clinica-dialog"

interface Clinica {
  id: string
  nome: string
  cnpj?: string
  endereco?: string
  telefone?: string
  email?: string
  created_at: string
  usuarios?: Usuario[]
  pacientes?: Paciente[]
  pagamentos?: Pagamento[]
}

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  status_conta: string
  created_at: string
}

interface Paciente {
  id: string
  nome: string
  email?: string
  telefone?: string
  created_at: string
}

interface Pagamento {
  id: string
  valor: number
  status: string
  created_at: string
}

export default function GestaoClinicasView() {
  const [clinicas, setClinicas] = useState<Clinica[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [openStatus, setOpenStatus] = useState(false)
  const [statusFilter, setStatusFilter] = useState("todos")
  const [stats, setStats] = useState({
    totalClinicas: 0,
    clinicasAtivas: 0,
    totalUsuarios: 0,
    totalPacientes: 0,
    receitaTotal: 0
  })

  const supabase = createClient()

  useEffect(() => {
    carregarClinicas()
  }, [])

  const carregarClinicas = async () => {
    try {
      setLoading(true)

      // Buscar clínicas primeiro sem relacionamentos
      const { data: clinicasData, error } = await supabase
        .from("clinicas")
        .select("*")
        .order("nome")

      if (error) {
        console.error("Erro ao buscar clínicas:", error)
        return
      }

      setClinicas(clinicasData || [])

      // Calcular estatísticas básicas
      setStats({
        totalClinicas: clinicasData?.length || 0,
        clinicasAtivas: 0, // Será calculado depois
        totalUsuarios: 0, // Será calculado depois
        totalPacientes: 0, // Será calculado depois
        receitaTotal: 0 // Será calculado depois
      })

    } catch (error) {
      console.error("Erro ao carregar clínicas:", error)
    } finally {
      setLoading(false)
    }
  }

  const filtrarClinicas = () => {
    let filtradas = clinicas

    // Filtro por busca
    if (searchTerm) {
      filtradas = filtradas.filter(clinica =>
        clinica.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        clinica.cnpj?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        clinica.email?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filtro por status (por enquanto mostra todas)
    if (statusFilter !== "todos") {
      // Por enquanto não filtra por status até implementar a lógica correta
    }

    return filtradas
  }

  const exportarRelatorio = () => {
    const dados = filtrarClinicas()
    const csvContent = [
      ["Nome", "CNPJ", "Email", "Telefone", "Usuários", "Pacientes", "Receita Total", "Status"],
      ...dados.map(clinica => {
        return [
          clinica.nome,
          clinica.cnpj || "",
          clinica.email || "",
          clinica.telefone || "",
          "0", // Usuários - será implementado depois
          "0", // Pacientes - será implementado depois
          "0.00", // Receita - será implementado depois
          "Ativa" // Status - será implementado depois
        ]
      })
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `relatorio-clinicas-${format(new Date(), "dd-MM-yyyy")}.csv`
    a.click()
  }

  const getStatusLabel = (clinica: Clinica) => {
    return "Ativa" // Por enquanto todas são ativas
  }

  const getStatusColor = (clinica: Clinica) => {
    return "bg-green-100 text-green-800" // Por enquanto todas são verdes
  }

  const statuses = [
    { value: "todos", label: "Todos os status" },
    { value: "ativa", label: "Ativa" },
    { value: "inativa", label: "Inativa" }
  ]

  const clinicasFiltradas = filtrarClinicas()

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando clínicas...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Gestão de Clínicas</h1>
        <p className="text-gray-600 mt-2">Controle completo de todas as clínicas do sistema</p>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Clínicas</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalClinicas}</div>
            <p className="text-xs text-muted-foreground">Clínicas cadastradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clínicas Ativas</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.clinicasAtivas}</div>
            <p className="text-xs text-muted-foreground">Com assinaturas ativas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.totalUsuarios}</div>
            <p className="text-xs text-muted-foreground">Médicos e funcionários</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Pacientes</CardTitle>
            <Users className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.totalPacientes}</div>
            <p className="text-xs text-muted-foreground">Pacientes cadastrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ {stats.receitaTotal.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Pagamentos realizados</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros e Ações</CardTitle>
          <CardDescription>Filtre e gerencie clínicas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por nome, CNPJ ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            {/* Filtro por Status */}
            <div className="w-full md:w-48">
              <Popover open={openStatus} onOpenChange={setOpenStatus}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openStatus}
                    className="w-full justify-between"
                  >
                    {statuses.find(status => status.value === statusFilter)?.label || "Selecione status..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-48 p-0">
                  <Command>
                    <CommandInput placeholder="Buscar status..." />
                    <CommandList>
                      <CommandEmpty>Nenhum status encontrado.</CommandEmpty>
                      <CommandGroup>
                        {statuses.map((status) => (
                          <CommandItem
                            key={status.value}
                            value={status.label}
                            onSelect={() => {
                              setStatusFilter(status.value)
                              setOpenStatus(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                statusFilter === status.value ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {status.label}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            <Button onClick={exportarRelatorio} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Exportar CSV
            </Button>
            <Button onClick={carregarClinicas} variant="outline" className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Atualizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Clínicas */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Clínicas</CardTitle>
          <CardDescription>
            {clinicasFiltradas.length} clínica(s) encontrada(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Clínica</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Usuários</TableHead>
                  <TableHead>Pacientes</TableHead>
                  <TableHead>Receita</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Cadastro</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clinicasFiltradas.map((clinica) => {
                  const usuariosAtivos = clinica.usuarios?.filter(u => u.status_conta === "assinante").length || 0
                  const receitaTotal = clinica.pagamentos?.filter(p => p.status === "pago").reduce((sum, p) => sum + p.valor, 0) || 0
                  
                  return (
                    <TableRow key={clinica.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{clinica.nome}</div>
                          {clinica.cnpj && (
                            <div className="text-sm text-gray-500">{clinica.cnpj}</div>
                          )}
                          {clinica.endereco && (
                            <div className="text-sm text-gray-500 flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {clinica.endereco}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          {clinica.email && (
                            <div className="text-sm flex items-center gap-1">
                              <Mail className="h-3 w-3" />
                              {clinica.email}
                            </div>
                          )}
                          {clinica.telefone && (
                            <div className="text-sm flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {clinica.telefone}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center">
                          <div className="font-medium">{clinica.usuarios?.length || 0}</div>
                          <div className="text-xs text-gray-500">
                            {usuariosAtivos} ativos
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center">
                          <div className="font-medium">{clinica.pacientes?.length || 0}</div>
                          <div className="text-xs text-gray-500">pacientes</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center">
                          <div className="font-medium text-green-600">
                            R$ {receitaTotal.toFixed(2)}
                          </div>
                          <div className="text-xs text-gray-500">
                            {clinica.pagamentos?.filter(p => p.status === "pago").length || 0} pagamentos
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(clinica)}>
                          {getStatusLabel(clinica)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3 text-gray-400" />
                          {format(new Date(clinica.created_at), "dd/MM/yyyy", { locale: ptBR })}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <VisualizarClinicaDialog clinica={clinica} />
                          <EditarClinicaDialog clinica={clinica} onUpdate={carregarClinicas} />
                          <DeletarClinicaDialog clinica={clinica} onDelete={carregarClinicas} />
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 