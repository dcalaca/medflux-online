"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Edit, Trash2 } from "lucide-react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface TipoConsulta {
  id: string
  nome: string
  valor_padrao: number | null
  duracao: number
  cor: string
  created_at: string
}

interface TiposConsultaTableProps {
  tiposConsulta: TipoConsulta[]
}

export function TiposConsultaTable({ tiposConsulta }: TiposConsultaTableProps) {
  const [loading, setLoading] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()
  const supabase = createClient()

  const handleDelete = async (id: string, nome: string) => {
    if (!confirm(`Tem certeza que deseja excluir o tipo "${nome}"?`)) {
      return
    }

    setLoading(id)
    try {
      const { error } = await supabase.from("tipos_consulta").delete().eq("id", id)

      if (error) throw error

      toast({
        title: "Tipo excluído!",
        description: "O tipo de consulta foi removido com sucesso.",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir o tipo de consulta.",
        variant: "destructive",
      })
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="overflow-x-auto w-full max-w-full px-2 sm:px-0">
      <Table className="min-w-[600px]">
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Valor Padrão</TableHead>
            <TableHead>Duração</TableHead>
            <TableHead>Cor</TableHead>
            <TableHead>Criado em</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tiposConsulta.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8">
                <div className="text-muted-foreground">Nenhum tipo de consulta cadastrado</div>
              </TableCell>
            </TableRow>
          ) : (
            tiposConsulta.map((tipo) => (
              <TableRow key={tipo.id}>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: tipo.cor }} />
                    <span className="font-medium">{tipo.nome}</span>
                  </div>
                </TableCell>
                <TableCell>
                  {tipo.valor_padrao
                    ? new Intl.NumberFormat("pt-BR", {
                        style: "currency",
                        currency: "BRL",
                      }).format(tipo.valor_padrao)
                    : "-"}
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{tipo.duracao} min</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 rounded border" style={{ backgroundColor: tipo.cor }} />
                    <span className="text-sm text-muted-foreground">{tipo.cor}</span>
                  </div>
                </TableCell>
                <TableCell>{new Date(tipo.created_at).toLocaleDateString("pt-BR")}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end space-x-2">
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/tipos-consulta/${tipo.id}/editar`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(tipo.id, tipo.nome)}
                      disabled={loading === tipo.id}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}
