"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Trash2, Building } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Clinica {
  id: string
  nome: string
  cnpj?: string
  usuarios?: any[]
  pacientes?: any[]
}

interface DeletarClinicaDialogProps {
  clinica: Clinica
  onDelete: () => void
}

export function DeletarClinicaDialog({ clinica, onDelete }: DeletarClinicaDialogProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  const { toast } = useToast()
  const supabase = createClient()

  const handleDelete = async () => {
    setLoading(true)
    try {
      // Verificar se há usuários ou pacientes associados
      const { data: usuarios } = await supabase
        .from("usuarios")
        .select("id")
        .eq("clinica_id", clinica.id)

      const { data: pacientes } = await supabase
        .from("pacientes")
        .select("id")
        .eq("clinica_id", clinica.id)

      if ((usuarios && usuarios.length > 0) || (pacientes && pacientes.length > 0)) {
        toast({
          title: "Não é possível excluir",
          description: "Esta clínica possui usuários ou pacientes associados. Remova as associações primeiro.",
          variant: "destructive",
        })
        return
      }

      // Deletar a clínica
      const { error } = await supabase
        .from("clinicas")
        .delete()
        .eq("id", clinica.id)

      if (error) {
        throw error
      }

      toast({
        title: "Clínica deletada",
        description: `${clinica.nome} foi removida do sistema.`,
      })

      onDelete()
      setOpen(false)
    } catch (error) {
      console.error("Erro ao deletar clínica:", error)
      toast({
        title: "Erro",
        description: "Não foi possível deletar a clínica.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
          <Trash2 className="h-3 w-3" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Confirmar Exclusão</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 bg-red-50 rounded-lg">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <div>
              <h4 className="font-medium text-red-900">Atenção!</h4>
              <p className="text-sm text-red-700">
                Esta ação não pode ser desfeita. Todos os dados da clínica serão perdidos.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">Clínica a ser excluída:</h4>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-gray-500" />
                <span className="font-medium">{clinica.nome}</span>
              </div>
              {clinica.cnpj && (
                <p className="text-sm text-gray-500 mt-1">CNPJ: {clinica.cnpj}</p>
              )}
            </div>
          </div>

          <div className="text-sm text-gray-600">
            <p>• Usuários associados: {clinica.usuarios?.length || 0}</p>
            <p>• Pacientes associados: {clinica.pacientes?.length || 0}</p>
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              onClick={handleDelete}
              disabled={loading}
              variant="destructive"
              className="flex-1"
            >
              {loading ? "Excluindo..." : "Confirmar Exclusão"}
            </Button>
            <Button
              onClick={() => setOpen(false)}
              variant="outline"
              className="flex-1"
            >
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
} 