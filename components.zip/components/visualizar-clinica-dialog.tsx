"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { 
  Eye, 
  Building, 
  Users, 
  UserCheck, 
  UserX,
  DollarSign,
  Calendar,
  MapPin,
  Phone,
  Mail,
  CreditCard,
  CheckCircle,
  AlertCircle
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  status_conta: string
  created_at: string
}

interface Paciente {
  id: string
  nome: string
  email?: string
  telefone?: string
  created_at: string
}

interface Pagamento {
  id: string
  valor: number
  status: string
  created_at: string
}

interface Clinica {
  id: string
  nome: string
  cnpj?: string
  endereco?: string
  telefone?: string
  email?: string
  created_at: string
  usuarios?: Usuario[]
  pacientes?: Paciente[]
  pagamentos?: Pagamento[]
}

interface VisualizarClinicaDialogProps {
  clinica: Clinica
}

export function VisualizarClinicaDialog({ clinica }: VisualizarClinicaDialogProps) {
  const [open, setOpen] = useState(false)

  const getStatusColor = (clinica: Clinica) => {
    const usuariosAtivos = clinica.usuarios?.filter(u => u.status_conta === "assinante").length || 0
    return usuariosAtivos > 0 ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
  }

  const getStatusLabel = (clinica: Clinica) => {
    const usuariosAtivos = clinica.usuarios?.filter(u => u.status_conta === "assinante").length || 0
    return usuariosAtivos > 0 ? "Ativa" : "Inativa"
  }

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "admin": return <AlertCircle className="h-4 w-4" />
      case "medico": return <UserCheck className="h-4 w-4" />
      case "recepcionista": return <Users className="h-4 w-4" />
      default: return <Users className="h-4 w-4" />
    }
  }

  const getTipoLabel = (tipo: string) => {
    switch (tipo) {
      case "admin": return "Administrador"
      case "medico": return "Médico"
      case "recepcionista": return "Recepcionista"
      default: return tipo
    }
  }

  const receitaTotal = clinica.pagamentos?.filter(p => p.status === "pago").reduce((sum, p) => sum + p.valor, 0) || 0
  const pagamentosPendentes = clinica.pagamentos?.filter(p => p.status === "pendente").length || 0
  const usuariosAtivos = clinica.usuarios?.filter(u => u.status_conta === "assinante").length || 0

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Eye className="h-3 w-3" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Detalhes da Clínica</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Informações Principais */}
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <Building className="h-8 w-8 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold">{clinica.nome}</h3>
              {clinica.cnpj && (
                <p className="text-gray-600">CNPJ: {clinica.cnpj}</p>
              )}
              <div className="flex items-center gap-2 mt-2">
                <Badge className={getStatusColor(clinica)}>
                  {getStatusLabel(clinica)}
                </Badge>
              </div>
            </div>
          </div>

          {/* Informações de Contato */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {clinica.email && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="h-4 w-4" />
                  <span>Email</span>
                </div>
                <p className="font-medium">{clinica.email}</p>
              </div>
            )}
            
            {clinica.telefone && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="h-4 w-4" />
                  <span>Telefone</span>
                </div>
                <p className="font-medium">{clinica.telefone}</p>
              </div>
            )}

            {clinica.endereco && (
              <div className="space-y-2 md:col-span-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="h-4 w-4" />
                  <span>Endereço</span>
                </div>
                <p className="font-medium">{clinica.endereco}</p>
              </div>
            )}
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Users className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium text-gray-700">Usuários</span>
              </div>
              <p className="text-2xl font-bold text-blue-600">{clinica.usuarios?.length || 0}</p>
              <p className="text-xs text-gray-500">{usuariosAtivos} ativos</p>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Users className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium text-gray-700">Pacientes</span>
              </div>
              <p className="text-2xl font-bold text-purple-600">{clinica.pacientes?.length || 0}</p>
              <p className="text-xs text-gray-500">cadastrados</p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium text-gray-700">Receita</span>
              </div>
              <p className="text-2xl font-bold text-green-600">R$ {receitaTotal.toFixed(2)}</p>
              <p className="text-xs text-gray-500">total</p>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <CreditCard className="h-5 w-5 text-orange-600" />
                <span className="text-sm font-medium text-gray-700">Pagamentos</span>
              </div>
              <p className="text-2xl font-bold text-orange-600">{clinica.pagamentos?.length || 0}</p>
              <p className="text-xs text-gray-500">{pagamentosPendentes} pendentes</p>
            </div>
          </div>

          {/* Lista de Usuários */}
          {clinica.usuarios && clinica.usuarios.length > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3">Usuários da Clínica</h4>
              <div className="space-y-2">
                {clinica.usuarios.map((usuario) => (
                  <div key={usuario.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                    <div className="flex items-center gap-3">
                      {getTipoIcon(usuario.tipo)}
                      <div>
                        <p className="font-medium">{usuario.nome}</p>
                        <p className="text-sm text-gray-500">{usuario.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {getTipoLabel(usuario.tipo)}
                      </Badge>
                      <Badge
                        variant={usuario.status_conta === "assinante" ? "default" : "secondary"}
                      >
                        {usuario.status_conta === "assinante" ? "✅ Ativo" : "⏳ Em Teste"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Lista de Pacientes */}
          {clinica.pacientes && clinica.pacientes.length > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3">Pacientes da Clínica</h4>
              <div className="space-y-2">
                {clinica.pacientes.slice(0, 5).map((paciente) => (
                  <div key={paciente.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                    <div>
                      <p className="font-medium">{paciente.nome}</p>
                      {paciente.email && (
                        <p className="text-sm text-gray-500">{paciente.email}</p>
                      )}
                    </div>
                    <div className="text-sm text-gray-500">
                      {format(new Date(paciente.created_at), "dd/MM/yyyy", { locale: ptBR })}
                    </div>
                  </div>
                ))}
                {clinica.pacientes.length > 5 && (
                  <p className="text-sm text-gray-500 text-center">
                    +{clinica.pacientes.length - 5} pacientes adicionais
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Informações do Sistema */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>Data de Cadastro</span>
              </div>
              <p className="font-medium">{format(new Date(clinica.created_at), "dd/MM/yyyy", { locale: ptBR })}</p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Building className="h-4 w-4" />
                <span>ID da Clínica</span>
              </div>
              <p className="font-mono text-sm">{clinica.id}</p>
            </div>
          </div>

          {/* Botões de Ação */}
          <div className="flex gap-2 pt-4">
            <Button onClick={() => setOpen(false)} className="flex-1">
              Fechar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
} 