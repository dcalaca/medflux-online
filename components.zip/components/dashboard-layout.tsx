"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  UserPlus, 
  FileText, 
  Settings, 
  LogOut,
  DollarSign,
  BarChart3,
  Building,
  Shield,
  Bell
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useRouter } from "next/navigation"
import { useIsMobile } from "@/hooks/use-mobile"
import { BottomNavBar } from "@/components/BottomNavBar"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [user, setUser] = useState<any>(null)
  const [usuario, setUsuario] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const isMobile = useIsMobile()

  const supabase = createClient()

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      setUser(user)
      
      if (user) {
        // Buscar dados do usuário no banco
        const { data: usuarioData } = await supabase
          .from("usuarios")
          .select("*")
          .eq("id", user.id)
          .single()
        
        setUsuario(usuarioData)
      }
      
      setLoading(false)
    }
    getUser()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    router.push("/login")
    return null
  }

  const medicoSection = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/agenda", label: "Agenda", icon: Calendar },
    { href: "/pacientes", label: "Pacientes", icon: Users },
    { href: "/usuarios", label: "Usuários", icon: Users },
    { href: "/tipos-consulta", label: "Tipos de Consulta", icon: FileText },
    { href: "/convenios", label: "Convênios", icon: FileText },
    { href: "/especialidades", label: "Especialidades", icon: FileText },
    { href: "/relatorios", label: "Relatórios", icon: BarChart3 },
    { href: "/financeiro", label: "Financeiro", icon: DollarSign },
    { href: "/meus-dados", label: "Meus Dados", icon: Settings },
  ]

  const recepcionistaSection = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/agenda", label: "Agenda", icon: Calendar },
    { href: "/pacientes", label: "Pacientes", icon: Users },
    { href: "/pacientes/novo", label: "Novo Paciente", icon: UserPlus },
    { href: "/meus-dados", label: "Meus Dados", icon: Settings },
  ]

  const adminSection = [
    { href: "/admin", label: "Administração", icon: Shield },
    { href: "/admin/relatorios", label: "Relatórios", icon: BarChart3 },
    { href: "/admin/gestao-financeira", label: "Gestão Financeira", icon: DollarSign },
    { href: "/admin/gestao-usuarios", label: "Gestão de Usuários", icon: Users },
    { href: "/admin/gestao-clinicas", label: "Gestão de Clínicas", icon: Building },
  ]

  const getCurrentUserType = () => {
    // Usar os dados reais do usuário do banco de dados
    if (usuario?.tipo) {
      return usuario.tipo
    }
    // Fallback: se estiver na rota /admin, assumir que é admin
    if (pathname.startsWith("/admin")) {
      return "admin"
    }
    return "medico" // fallback padrão
  }

  const currentUserType = getCurrentUserType()
  const navigationItems = currentUserType === "admin" ? adminSection : 
                         currentUserType === "recepcionista" ? recepcionistaSection : 
                         medicoSection

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/login")
  }

  return (
    <div className="flex min-h-screen bg-gray-100 overflow-hidden">
      {/* Sidebar - só desktop */}
      {!isMobile && (
      <div className="w-64 bg-white shadow-lg flex-shrink-0">
        <div className="flex items-center justify-center">
          {/* Desktop: logo completa */}
          <img src="/logo.png" alt="Logo MedFlux" className="logo-medflux hidden md:block" />
          {/* Mobile: só o ícone */}
          <img src="/logo-icon.png" alt="Ícone MedFlux" className="logo-medflux md:hidden" />
        </div>
        <nav className="px-4">
          {currentUserType === "admin" && (
            <div className="mb-6">
              <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
                ADMINISTRAÇÃO
              </h2>
            </div>
          )}
          <ul className="space-y-2">
            {navigationItems.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <li key={item.href}>
                  <Link href={item.href}>
                    <Button
                      variant={isActive ? "default" : "ghost"}
                      className={`w-full justify-start ${
                        isActive ? "bg-blue-600 text-white" : "text-gray-700 hover:bg-gray-100"
                      }`}
                    >
                      <Icon className="h-4 w-4 mr-3" />
                      {item.label}
                    </Button>
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
      </div>
      )}
      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-gray-900">
                {pathname === "/dashboard" ? "Dashboard" : 
                 pathname === "/agenda" ? "Agenda" :
                 pathname === "/pacientes" ? "Pacientes" :
                 pathname === "/admin" ? "Administração" :
                 "MedFlux"}
              </h2>
            </div>
            <div className="flex items-center space-x-4">
              {/* Notificações */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5 text-gray-500" />
                <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full"></span>
              </Button>
              {/* Perfil do usuário */}
              <DropdownMenu open={profileMenuOpen} onOpenChange={setProfileMenuOpen}>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-3 p-2">
                    <div className="text-sm text-gray-700 text-right">
                      <div className="font-medium">{usuario?.nome || user?.email}</div>
                      <div className="text-xs text-gray-500">{usuario?.tipo || "Usuário"}</div>
                    </div>
                    <div className="h-8 w-8 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">
                        {usuario?.nome?.charAt(0) || user?.email?.charAt(0) || "U"}
                      </span>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-3 py-2">
                    <div className="text-sm font-medium">{usuario?.nome || user?.email}</div>
                    <div className="text-xs text-gray-500">{usuario?.email || user?.email}</div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => router.push("/meus-dados")}> <Settings className="h-4 w-4 mr-2" /> Meus Dados </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600"> <LogOut className="h-4 w-4 mr-2" /> Sair </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        {/* Content */}
        <main className="flex-1 overflow-auto p-4 md:p-8 pb-24"> {/* padding reduzido no mobile */}
          <div className="w-full max-w-full"> {/* container simples para evitar overflow */}
          {children}
          </div>
        </main>
        {/* BottomNavBar só no mobile */}
        {isMobile && <BottomNavBar userType={currentUserType} />}
      </div>
    </div>
  )
}
