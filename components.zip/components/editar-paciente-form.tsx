"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import type { Paciente, Usuario } from "@/types/database.types"

interface EditarPacienteFormProps {
  paciente: Paciente
  usuario: Usuario
}

export function EditarPacienteForm({ paciente, usuario }: EditarPacienteFormProps) {
  const [formData, setFormData] = useState({
    nome: paciente.nome,
    nascimento: paciente.nascimento || "",
    genero: paciente.genero || "",
    cpf: paciente.cpf || "",
    telefone: paciente.telefone || "",
    email: paciente.email || "",
    endereco: {
      cep: paciente.endereco?.cep || "",
      logradouro: paciente.endereco?.logradouro || "",
      numero: paciente.endereco?.numero || "",
      complemento: paciente.endereco?.complemento || "",
      bairro: paciente.endereco?.bairro || "",
      cidade: paciente.endereco?.cidade || "",
      estado: paciente.endereco?.estado || "",
    },
    convenio: paciente.convenio || "",
    numero_convenio: paciente.numero_convenio || "",
    observacoes: paciente.observacoes || "",
  })
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const { error } = await supabase
        .from("pacientes")
        .update({
          nome: formData.nome,
          nascimento: formData.nascimento || null,
          genero: (formData.genero as "masculino" | "feminino" | "outro") || null,
          cpf: formData.cpf || null,
          telefone: formData.telefone || null,
          email: formData.email || null,
          endereco: formData.endereco,
          convenio: formData.convenio || null,
          numero_convenio: formData.numero_convenio || null,
          observacoes: formData.observacoes || null,
        })
        .eq("id", paciente.id)

      if (error) {
        toast({
          title: "Erro ao atualizar paciente",
          description: error.message,
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Paciente atualizado com sucesso!",
        description: "Os dados do paciente foram atualizados.",
      })

      router.push(`/pacientes/${paciente.id}`)
    } catch (error) {
      toast({
        title: "Erro ao atualizar paciente",
        description: "Ocorreu um erro inesperado. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target

    if (name.startsWith("endereco.")) {
      const field = name.split(".")[1]
      setFormData({
        ...formData,
        endereco: {
          ...formData.endereco,
          [field]: value,
        },
      })
    } else {
      setFormData({
        ...formData,
        [name]: value,
      })
    }
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild>
          <Link href={`/pacientes/${paciente.id}`}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Detalhes
          </Link>
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Dados Pessoais</CardTitle>
            <CardDescription>Informações básicas do paciente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nome">Nome completo *</Label>
                <Input id="nome" name="nome" value={formData.nome} onChange={handleInputChange} required />
              </div>

              <div>
                <Label htmlFor="nascimento">Data de nascimento</Label>
                <Input
                  id="nascimento"
                  name="nascimento"
                  type="date"
                  value={formData.nascimento}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Label htmlFor="genero">Gênero</Label>
                <Select value={formData.genero} onValueChange={(value) => handleSelectChange("genero", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o gênero" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="masculino">Masculino</SelectItem>
                    <SelectItem value="feminino">Feminino</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="cpf">CPF</Label>
                <Input
                  id="cpf"
                  name="cpf"
                  value={formData.cpf}
                  onChange={handleInputChange}
                  placeholder="000.000.000-00"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contato</CardTitle>
            <CardDescription>Informações de contato do paciente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="telefone">Telefone</Label>
                <Input
                  id="telefone"
                  name="telefone"
                  value={formData.telefone}
                  onChange={handleInputChange}
                  placeholder="(11) 99999-9999"
                />
              </div>

              <div>
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="joao@exemplo.com"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Endereço</CardTitle>
            <CardDescription>Endereço residencial do paciente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="endereco.cep">CEP</Label>
                <Input
                  id="endereco.cep"
                  name="endereco.cep"
                  value={formData.endereco.cep}
                  onChange={handleInputChange}
                  placeholder="00000-000"
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="endereco.logradouro">Logradouro</Label>
                <Input
                  id="endereco.logradouro"
                  name="endereco.logradouro"
                  value={formData.endereco.logradouro}
                  onChange={handleInputChange}
                  placeholder="Rua das Flores"
                />
              </div>

              <div>
                <Label htmlFor="endereco.numero">Número</Label>
                <Input
                  id="endereco.numero"
                  name="endereco.numero"
                  value={formData.endereco.numero}
                  onChange={handleInputChange}
                  placeholder="123"
                />
              </div>

              <div>
                <Label htmlFor="endereco.complemento">Complemento</Label>
                <Input
                  id="endereco.complemento"
                  name="endereco.complemento"
                  value={formData.endereco.complemento}
                  onChange={handleInputChange}
                  placeholder="Apto 45"
                />
              </div>

              <div>
                <Label htmlFor="endereco.bairro">Bairro</Label>
                <Input
                  id="endereco.bairro"
                  name="endereco.bairro"
                  value={formData.endereco.bairro}
                  onChange={handleInputChange}
                  placeholder="Centro"
                />
              </div>

              <div>
                <Label htmlFor="endereco.cidade">Cidade</Label>
                <Input
                  id="endereco.cidade"
                  name="endereco.cidade"
                  value={formData.endereco.cidade}
                  onChange={handleInputChange}
                  placeholder="São Paulo"
                />
              </div>

              <div>
                <Label htmlFor="endereco.estado">Estado</Label>
                <Input
                  id="endereco.estado"
                  name="endereco.estado"
                  value={formData.endereco.estado}
                  onChange={handleInputChange}
                  placeholder="SP"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Convênio</CardTitle>
            <CardDescription>Informações do plano de saúde</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="convenio">Nome do convênio</Label>
                <Input
                  id="convenio"
                  name="convenio"
                  value={formData.convenio}
                  onChange={handleInputChange}
                  placeholder="Unimed, Bradesco Saúde, etc."
                />
              </div>

              <div>
                <Label htmlFor="numero_convenio">Número da carteirinha</Label>
                <Input
                  id="numero_convenio"
                  name="numero_convenio"
                  value={formData.numero_convenio}
                  onChange={handleInputChange}
                  placeholder="123456789"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Observações</CardTitle>
            <CardDescription>Informações adicionais sobre o paciente</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              id="observacoes"
              name="observacoes"
              value={formData.observacoes}
              onChange={handleInputChange}
              placeholder="Observações gerais, alergias, medicamentos em uso, etc."
              rows={4}
            />
          </CardContent>
        </Card>

        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" asChild>
            <Link href={`/pacientes/${paciente.id}`}>Cancelar</Link>
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </div>
      </form>
    </div>
  )
}
