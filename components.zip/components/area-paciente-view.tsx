"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClient } from "@/lib/supabase/client"
import { Calendar, FileText, Pill, Download, User } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface AreaPacienteViewProps {
  paciente: any
}

export function AreaPacienteView({ paciente }: AreaPacienteViewProps) {
  const [consultas, setConsultas] = useState([])
  const [prontuarios, setProntuarios] = useState([])
  const [prescricoes, setPrescricoes] = useState([])
  const [loading, setLoading] = useState(true)

  const supabase = createClient()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      // Carregar consultas
      const { data: consultasData } = await supabase
        .from("consultas")
        .select(`
          *,
          tipos_consulta(nome),
          usuarios(nome)
        `)
        .eq("paciente_id", paciente.id)
        .order("data_hora", { ascending: false })

      // Carregar prontuários liberados
      const { data: prontuariosData } = await supabase
        .from("prontuarios")
        .select(`
          *,
          usuarios(nome)
        `)
        .eq("paciente_id", paciente.id)
        .eq("liberado_paciente", true)
        .order("data_consulta", { ascending: false })

      // Carregar prescrições
      const { data: prescricoesData } = await supabase
        .from("prescricoes")
        .select(`
          *,
          usuarios(nome)
        `)
        .eq("paciente_id", paciente.id)
        .order("data_prescricao", { ascending: false })

      setConsultas(consultasData || [])
      setProntuarios(prontuariosData || [])
      setPrescricoes(prescricoesData || [])
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "agendado":
        return "bg-blue-100 text-blue-800"
      case "confirmado":
        return "bg-green-100 text-green-800"
      case "realizado":
        return "bg-gray-100 text-gray-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Olá, {paciente.nome}!</h1>
        <p className="text-gray-600 mt-2">
          Bem-vindo à sua área do paciente. Aqui você pode acompanhar suas consultas, visualizar prontuários e baixar
          prescrições.
        </p>
      </div>

      {/* Informações do Paciente */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Meus Dados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-600">Nome</p>
              <p className="font-medium">{paciente.nome}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="font-medium">{paciente.email || "Não informado"}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Telefone</p>
              <p className="font-medium">{paciente.telefone || "Não informado"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="consultas" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="consultas" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Consultas
          </TabsTrigger>
          <TabsTrigger value="prontuarios" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Prontuários
          </TabsTrigger>
          <TabsTrigger value="prescricoes" className="flex items-center gap-2">
            <Pill className="h-4 w-4" />
            Prescrições
          </TabsTrigger>
        </TabsList>

        <TabsContent value="consultas" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Minhas Consultas</CardTitle>
            </CardHeader>
            <CardContent>
              {consultas.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Nenhuma consulta encontrada.</p>
              ) : (
                <div className="space-y-4">
                  {consultas.map((consulta: any) => (
                    <div key={consulta.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-medium">{consulta.tipos_consulta?.nome || "Consulta"}</h3>
                          <p className="text-sm text-gray-600">Dr(a). {consulta.usuarios?.nome}</p>
                        </div>
                        <Badge className={getStatusColor(consulta.status)}>{consulta.status}</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>{format(new Date(consulta.data_hora), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
                        {consulta.valor && <span>R$ {consulta.valor.toFixed(2)}</span>}
                      </div>
                      {consulta.observacoes && <p className="text-sm text-gray-600 mt-2">{consulta.observacoes}</p>}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="prontuarios" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Meus Prontuários</CardTitle>
            </CardHeader>
            <CardContent>
              {prontuarios.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Nenhum prontuário liberado encontrado.</p>
              ) : (
                <div className="space-y-4">
                  {prontuarios.map((prontuario: any) => (
                    <div key={prontuario.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-medium">
                            Consulta de {format(new Date(prontuario.data_consulta), "dd/MM/yyyy", { locale: ptBR })}
                          </h3>
                          <p className="text-sm text-gray-600">Dr(a). {prontuario.usuarios?.nome}</p>
                        </div>
                        <Button size="sm" variant="outline">
                          <Download className="h-4 w-4 mr-2" />
                          Baixar
                        </Button>
                      </div>
                      {prontuario.queixa_principal && (
                        <div className="mt-3">
                          <p className="text-sm font-medium text-gray-700">Queixa Principal:</p>
                          <p className="text-sm text-gray-600">{prontuario.queixa_principal}</p>
                        </div>
                      )}
                      {prontuario.hipotese_diagnostica && (
                        <div className="mt-2">
                          <p className="text-sm font-medium text-gray-700">Diagnóstico:</p>
                          <p className="text-sm text-gray-600">{prontuario.hipotese_diagnostica}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="prescricoes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Minhas Prescrições</CardTitle>
            </CardHeader>
            <CardContent>
              {prescricoes.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Nenhuma prescrição encontrada.</p>
              ) : (
                <div className="space-y-4">
                  {prescricoes.map((prescricao: any) => (
                    <div key={prescricao.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-medium">
                            Prescrição de {format(new Date(prescricao.data_prescricao), "dd/MM/yyyy", { locale: ptBR })}
                          </h3>
                          <p className="text-sm text-gray-600">Dr(a). {prescricao.usuarios?.nome}</p>
                        </div>
                        <Button size="sm" variant="outline">
                          <Download className="h-4 w-4 mr-2" />
                          Baixar PDF
                        </Button>
                      </div>
                      <div className="mt-3">
                        <p className="text-sm font-medium text-gray-700">Medicamentos:</p>
                        <div className="text-sm text-gray-600 whitespace-pre-line">{prescricao.medicamentos}</div>
                      </div>
                      {prescricao.observacoes && (
                        <div className="mt-2">
                          <p className="text-sm font-medium text-gray-700">Observações:</p>
                          <p className="text-sm text-gray-600">{prescricao.observacoes}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
