"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, DollarSign, TrendingUp, TrendingDown, Download } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { toast } from "@/hooks/use-toast"

interface MetricasFinanceiras {
  receitaTotal: number
  receitaMes: number
  consultasRealizadas: number
  consultasAgendadas: number
  ticketMedio: number
  crescimentoMensal: number
}

interface ConsultaFinanceira {
  id: string
  data_consulta: string
  valor: number
  status: string
  forma_pagamento: string
  paciente: {
    nome: string
  }
  tipo_consulta: {
    nome: string
  }
}

export function RelatoriosFinanceiros() {
  const supabase = createClient()
  
  const [metricas, setMetricas] = useState<MetricasFinanceiras>({
    receitaTotal: 0,
    receitaMes: 0,
    consultasRealizadas: 0,
    consultasAgendadas: 0,
    ticketMedio: 0,
    crescimentoMensal: 0,
  })

  const [consultas, setConsultas] = useState<ConsultaFinanceira[]>([])
  const [loading, setLoading] = useState(true)
  const [periodo, setPeriodo] = useState("mes") // mes, trimestre, ano

  useEffect(() => {
    carregarDados()
  }, [periodo])

  const carregarDados = async () => {
    try {
      setLoading(true)

      // Calcular datas baseado no período
      const hoje = new Date()
      const dataInicio = new Date()

      switch (periodo) {
        case "mes":
          dataInicio.setMonth(hoje.getMonth() - 1)
          break
        case "trimestre":
          dataInicio.setMonth(hoje.getMonth() - 3)
          break
        case "ano":
          dataInicio.setFullYear(hoje.getFullYear() - 1)
          break
      }

      // Buscar consultas do período
      const { data: consultasData, error: consultasError } = await supabase
        .from("consultas")
        .select("*")
        .gte("data_hora", dataInicio.toISOString())
        .lte("data_hora", hoje.toISOString())
        .order("data_hora", { ascending: false })

      if (consultasError) {
        console.error("Erro ao carregar consultas:", consultasError)
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados financeiros",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      const consultasFormatadas: ConsultaFinanceira[] = (consultasData || []).map((consulta: any) => ({
        id: consulta.id,
        data_consulta: consulta.data_hora,
        valor: consulta.valor || 0,
        status: consulta.status || 'agendada',
        forma_pagamento: consulta.forma_pagamento || 'Não informado',
        paciente: {
          nome: `Paciente ${consulta.paciente_id || 'N/A'}`
        },
        tipo_consulta: {
          nome: `Tipo ${consulta.tipo_consulta_id || 'N/A'}`
        },
      }))

      setConsultas(consultasFormatadas)

      // Calcular métricas
      const consultasRealizadas = consultasFormatadas.filter((c) => c.status === "realizada")
      const consultasAgendadas = consultasFormatadas.filter((c) => c.status === "agendada")

      const receitaTotal = consultasRealizadas.reduce((sum, c) => sum + (c.valor || 0), 0)

      // Receita do mês atual
      const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1)
      const receitaMes = consultasRealizadas
        .filter((c) => new Date(c.data_consulta) >= inicioMes)
        .reduce((sum, c) => sum + (c.valor || 0), 0)

      // Ticket médio
      const ticketMedio = consultasRealizadas.length > 0 ? receitaTotal / consultasRealizadas.length : 0

      // Crescimento mensal (simulado)
      const crescimentoMensal = Math.random() * 20 - 10 // -10% a +10%

      setMetricas({
        receitaTotal,
        receitaMes,
        consultasRealizadas: consultasRealizadas.length,
        consultasAgendadas: consultasAgendadas.length,
        ticketMedio,
        crescimentoMensal,
      })
    } catch (error) {
      console.error("Erro:", error)
      toast({
        title: "Erro",
        description: "Erro inesperado ao carregar dados",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const exportarCSV = () => {
    const headers = ["Data", "Paciente", "Tipo", "Valor", "Status", "Pagamento"]
    const csvContent = [
      headers.join(","),
      ...consultas.map((c) =>
        [
          new Date(c.data_consulta).toLocaleDateString("pt-BR"),
          c.paciente.nome,
          c.tipo_consulta.nome,
          `R$ ${(c.valor || 0).toFixed(2)}`,
          c.status,
          c.forma_pagamento || "Não informado",
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `relatorio-financeiro-${periodo}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Sucesso",
      description: "Relatório exportado com sucesso!",
    })
  }

  const formatarMoeda = (valor: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(valor)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "realizada":
        return "bg-green-100 text-green-800"
      case "agendada":
        return "bg-blue-100 text-blue-800"
      case "cancelada":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando relatórios...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Relatórios Financeiros</h1>
          <p className="text-gray-600">Acompanhe o desempenho financeiro da clínica</p>
        </div>
        <div className="flex gap-2">
          <select value={periodo} onChange={(e) => setPeriodo(e.target.value)} className="px-3 py-2 border rounded-md">
            <option value="mes">Último mês</option>
            <option value="trimestre">Último trimestre</option>
            <option value="ano">Último ano</option>
          </select>
          <Button onClick={exportarCSV} variant="outline" className="flex items-center gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
        </div>
      </div>

      {/* Métricas principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Receita Total</p>
                <p className="text-2xl font-bold text-gray-900">{formatarMoeda(metricas.receitaTotal)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Receita do Mês</p>
                <p className="text-2xl font-bold text-gray-900">{formatarMoeda(metricas.receitaMes)}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Consultas Realizadas</p>
                <p className="text-2xl font-bold text-gray-900">{metricas.consultasRealizadas}</p>
              </div>
              <div className="text-green-600">
                <TrendingUp className="h-8 w-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ticket Médio</p>
                <p className="text-2xl font-bold text-gray-900">{formatarMoeda(metricas.ticketMedio)}</p>
              </div>
              <div className={metricas.crescimentoMensal >= 0 ? "text-green-600" : "text-red-600"}>
                {metricas.crescimentoMensal >= 0 ? (
                  <TrendingUp className="h-8 w-8" />
                ) : (
                  <TrendingDown className="h-8 w-8" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Resumo por status */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo por Status</CardTitle>
          <CardDescription>Distribuição das consultas por status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{metricas.consultasRealizadas}</p>
              <p className="text-sm text-green-800">Realizadas</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-600">{metricas.consultasAgendadas}</p>
              <p className="text-sm text-blue-800">Agendadas</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-gray-600">
                {consultas.filter((c) => c.status === "cancelada").length}
              </p>
              <p className="text-sm text-gray-800">Canceladas</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista detalhada */}
      <Card>
        <CardHeader>
          <CardTitle>Consultas Detalhadas</CardTitle>
          <CardDescription>Lista completa das consultas no período selecionado</CardDescription>
        </CardHeader>
        <CardContent>
          {consultas.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-600">Nenhuma consulta encontrada no período selecionado</p>
            </div>
          ) : (
            <div className="space-y-2">
              {consultas.map((consulta) => (
                <div key={consulta.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{consulta.paciente.nome}</span>
                      <Badge className={getStatusColor(consulta.status)}>{consulta.status}</Badge>
                    </div>
                    <div className="text-sm text-gray-600">
                      <span>{consulta.tipo_consulta.nome}</span>
                      <span className="mx-2">•</span>
                      <span>{new Date(consulta.data_consulta).toLocaleDateString("pt-BR")}</span>
                      {consulta.forma_pagamento && (
                        <>
                          <span className="mx-2">•</span>
                          <span>{consulta.forma_pagamento}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">{formatarMoeda(consulta.valor || 0)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// Export nomeado e padrão
export default RelatoriosFinanceiros
