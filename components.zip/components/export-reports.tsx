"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Download, 
  FileText, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  FileSpreadsheet,
  FileImage,
  Share2,
  Printer
} from "lucide-react"
import * as XLSX from "xlsx"

interface Consulta {
  id: string
  data_hora: string
  valor: number | null
  status: string
  status_pagamento: string
  forma_pagamento: string | null
  pacientes: {
    nome: string
  } | null
  tipos_consulta: {
    nome: string
    cor: string
  } | null
}

interface ExportReportsProps {
  consultas: Consulta[]
  filtroMes: string
  filtroAno: string
  totalFaturamento: number
  totalPendente: number
  totalConsultas: number
  consultasPagas: number
}

export function ExportReports({
  consultas,
  filtroMes,
  filtroAno,
  totalFaturamento,
  totalPendente,
  totalConsultas,
  consultasPagas,
}: ExportReportsProps) {
  const [loading, setLoading] = useState<string | null>(null)
  
  const meses = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ]

  const nomeMes = meses[parseInt(filtroMes)]
  const taxaRecebimento = totalConsultas > 0 ? Math.round((consultasPagas / totalConsultas) * 100) : 0

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pago":
        return "Pago"
      case "pendente":
        return "Pendente"
      case "cancelado":
        return "Cancelado"
      default:
        return "Desconhecido"
    }
  }

  // Exportar para Excel
  const exportToExcel = async () => {
    setLoading("excel")
    try {
      // Dados do resumo
      const resumoData = [
        ["RESUMO FINANCEIRO", ""],
        ["Período", `${nomeMes} ${filtroAno}`],
        ["Faturamento Total", formatCurrency(totalFaturamento)],
        ["Pendente", formatCurrency(totalPendente)],
        ["Total de Consultas", totalConsultas],
        ["Consultas Pagas", consultasPagas],
        ["Taxa de Recebimento", `${taxaRecebimento}%`],
        ["", ""],
        ["DETALHAMENTO DE CONSULTAS", ""],
        ["Data", "Paciente", "Tipo", "Valor", "Status", "Forma Pagamento"]
      ]

      // Dados das consultas
      const consultasData = consultas.map(consulta => [
        formatDate(consulta.data_hora),
        consulta.pacientes?.nome || "N/A",
        consulta.tipos_consulta?.nome || "N/A",
        formatCurrency(consulta.valor || 0),
        getStatusText(consulta.status_pagamento),
        consulta.forma_pagamento || "N/A"
      ])

      // Combinar dados
      const allData = [...resumoData, ...consultasData]

      // Criar workbook
      const wb = XLSX.utils.book_new()
      const ws = XLSX.utils.aoa_to_sheet(allData)

      // Estilizar cabeçalhos
      ws["!cols"] = [
        { width: 15 }, // Data
        { width: 30 }, // Paciente
        { width: 20 }, // Tipo
        { width: 15 }, // Valor
        { width: 15 }, // Status
        { width: 20 }, // Forma Pagamento
      ]

      XLSX.utils.book_append_sheet(wb, ws, "Relatório Financeiro")

      // Salvar arquivo
      const fileName = `relatorio-financeiro-${nomeMes.toLowerCase()}-${filtroAno}.xlsx`
      XLSX.writeFile(wb, fileName)
    } catch (error) {
      console.error("Erro ao exportar Excel:", error)
    } finally {
      setLoading(null)
    }
  }

  // Exportar para HTML
  const exportToHTML = () => {
    setLoading("html")
    try {
      const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Financeiro - ${nomeMes} ${filtroAno}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; color: #1e40af; margin-bottom: 30px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .card { border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; background: #f9fafb; }
        .card h3 { margin: 0 0 10px 0; color: #374151; }
        .card .value { font-size: 24px; font-weight: bold; color: #1e40af; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #d1d5db; padding: 12px; text-align: left; }
        th { background: #1e40af; color: white; }
        tr:nth-child(even) { background: #f9fafb; }
        .footer { margin-top: 30px; text-align: center; color: #6b7280; font-size: 12px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Relatório Financeiro</h1>
        <h2>${nomeMes} ${filtroAno}</h2>
    </div>
    
    <div class="summary">
        <div class="card">
            <h3>Faturamento Total</h3>
            <div class="value">${formatCurrency(totalFaturamento)}</div>
        </div>
        <div class="card">
            <h3>Pendente</h3>
            <div class="value">${formatCurrency(totalPendente)}</div>
        </div>
        <div class="card">
            <h3>Total de Consultas</h3>
            <div class="value">${totalConsultas}</div>
        </div>
        <div class="card">
            <h3>Taxa de Recebimento</h3>
            <div class="value">${taxaRecebimento}%</div>
        </div>
    </div>
    
    <h3>Detalhamento de Consultas</h3>
    <table>
        <thead>
            <tr>
                <th>Data</th>
                <th>Paciente</th>
                <th>Tipo</th>
                <th>Valor</th>
                <th>Status</th>
                <th>Forma Pagamento</th>
            </tr>
        </thead>
        <tbody>
            ${consultas.map(consulta => `
                <tr>
                    <td>${formatDate(consulta.data_hora)}</td>
                    <td>${consulta.pacientes?.nome || "N/A"}</td>
                    <td>${consulta.tipos_consulta?.nome || "N/A"}</td>
                    <td>${formatCurrency(consulta.valor || 0)}</td>
                    <td>${getStatusText(consulta.status_pagamento)}</td>
                    <td>${consulta.forma_pagamento || "N/A"}</td>
                </tr>
            `).join("")}
        </tbody>
    </table>
    
    <div class="footer">
        <p>Gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}</p>
    </div>
</body>
</html>`

      // Criar blob e download
      const blob = new Blob([htmlContent], { type: "text/html" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `relatorio-financeiro-${nomeMes.toLowerCase()}-${filtroAno}.html`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Erro ao exportar HTML:", error)
    } finally {
      setLoading(null)
    }
  }

  // Compartilhar via email
  const shareViaEmail = () => {
    setLoading("email")
    try {
      const subject = `Relatório Financeiro - ${nomeMes} ${filtroAno}`
      const body = `
Olá,

Segue o relatório financeiro de ${nomeMes} ${filtroAno}:

📊 RESUMO:
• Faturamento Total: ${formatCurrency(totalFaturamento)}
• Pendente: ${formatCurrency(totalPendente)}
• Total de Consultas: ${totalConsultas}
• Taxa de Recebimento: ${taxaRecebimento}%

📋 DETALHAMENTO:
${consultas.map(consulta => 
  `• ${formatDate(consulta.data_hora)} - ${consulta.pacientes?.nome || "N/A"} - ${formatCurrency(consulta.valor || 0)} - ${getStatusText(consulta.status_pagamento)}`
).join("\n")}

Atenciosamente,
Sistema MedFlux
      `.trim()

      const mailtoLink = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
      window.open(mailtoLink)
    } catch (error) {
      console.error("Erro ao compartilhar:", error)
    } finally {
      setLoading(null)
    }
  }

  // Exportar para CSV
  const exportToCSV = () => {
    setLoading("csv")
    try {
      // Cabeçalho
      const header = [
        "Data",
        "Paciente",
        "Tipo",
        "Valor",
        "Status",
        "Forma Pagamento"
      ]
      // Dados
      const rows = consultas.map(consulta => [
        formatDate(consulta.data_hora),
        consulta.pacientes?.nome || "N/A",
        consulta.tipos_consulta?.nome || "N/A",
        (consulta.valor || 0).toString().replace('.', ','),
        getStatusText(consulta.status_pagamento),
        consulta.forma_pagamento || "N/A"
      ])
      // Montar CSV
      const csvContent = [header, ...rows].map(e => e.join(';')).join('\n')
      // Download
      const blob = new Blob([csvContent], { type: 'text/csv' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `relatorio-financeiro-${nomeMes.toLowerCase()}-${filtroAno}.csv`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Erro ao exportar CSV:", error)
    } finally {
      setLoading(null)
    }
  }

  // Função para imprimir o HTML
  const printHTML = () => {
    const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Financeiro - ${nomeMes} ${filtroAno}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; color: #1e40af; margin-bottom: 30px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .card { border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; background: #f9fafb; }
        .card h3 { margin: 0 0 10px 0; color: #374151; }
        .card .value { font-size: 24px; font-weight: bold; color: #1e40af; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 12px; }
        th, td { border: 1px solid #d1d5db; padding: 6px 8px; text-align: left; }
        th { background: #1e40af; color: white; }
        tr:nth-child(even) { background: #f9fafb; }
        .footer { margin-top: 30px; text-align: center; color: #6b7280; font-size: 12px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Relatório Financeiro</h1>
        <h2>${nomeMes} ${filtroAno}</h2>
    </div>
    
    <div class="summary">
        <div class="card">
            <h3>Faturamento Total</h3>
            <div class="value">${formatCurrency(totalFaturamento)}</div>
        </div>
        <div class="card">
            <h3>Pendente</h3>
            <div class="value">${formatCurrency(totalPendente)}</div>
        </div>
        <div class="card">
            <h3>Total de Consultas</h3>
            <div class="value">${totalConsultas}</div>
        </div>
        <div class="card">
            <h3>Taxa de Recebimento</h3>
            <div class="value">${taxaRecebimento}%</div>
        </div>
    </div>
    
    <h3>Detalhamento de Consultas</h3>
    <table>
        <thead>
            <tr>
                <th>Data</th>
                <th>Paciente</th>
                <th>Tipo</th>
                <th>Valor</th>
                <th>Status</th>
                <th>Forma Pagamento</th>
            </tr>
        </thead>
        <tbody>
            ${consultas.map(consulta => `
                <tr>
                    <td>${formatDate(consulta.data_hora)}</td>
                    <td>${consulta.pacientes?.nome || "N/A"}</td>
                    <td>${consulta.tipos_consulta?.nome || "N/A"}</td>
                    <td>${formatCurrency(consulta.valor || 0)}</td>
                    <td>${getStatusText(consulta.status_pagamento)}</td>
                    <td>${consulta.forma_pagamento || "N/A"}</td>
                </tr>
            `).join("")}
        </tbody>
    </table>
    
    <div class="footer">
        <p>Gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}</p>
    </div>
    <script>window.onload = function() { window.print(); }<\/script>
</body>
</html>`;
    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.focus();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Exportar Relatórios</h3>
          <p className="text-sm text-muted-foreground">
            Escolha o formato que melhor atende suas necessidades
          </p>
        </div>
      </div>

      {/* Cards de métricas */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="p-4 border rounded-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-600">Faturamento</p>
              <p className="text-2xl font-bold text-blue-700">
                {formatCurrency(totalFaturamento)}
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-blue-500" />
          </div>
        </div>

        <div className="p-4 border rounded-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-600">Pendente</p>
              <p className="text-2xl font-bold text-yellow-700">
                {formatCurrency(totalPendente)}
              </p>
            </div>
            <Calendar className="h-8 w-8 text-yellow-500" />
          </div>
        </div>

        <div className="p-4 border rounded-lg bg-gradient-to-br from-green-50 to-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-600">Consultas</p>
              <p className="text-2xl font-bold text-green-700">{totalConsultas}</p>
            </div>
            <FileText className="h-8 w-8 text-green-500" />
          </div>
        </div>

        <div className="p-4 border rounded-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-600">Taxa Recebimento</p>
              <p className="text-2xl font-bold text-purple-700">{taxaRecebimento}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Botões de exportação */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-green-600" />
              <CardTitle className="text-base">Excel</CardTitle>
            </div>
            <CardDescription>Planilha editável</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={exportToExcel} 
              disabled={loading !== null}
              className="w-full"
              variant="outline"
            >
              <Download className="h-4 w-4 mr-2" />
              {loading === "excel" ? "Exportando..." : "Exportar Excel"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Printer className="h-5 w-5 text-red-600" />
              <CardTitle className="text-base">Imprimir</CardTitle>
            </div>
            <CardDescription>Salvar em PDF ou papel</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={printHTML} 
              disabled={loading !== null}
              className="w-full"
              variant="outline"
            >
              <Printer className="h-4 w-4 mr-2" />
              Imprimir (PDF)
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <FileImage className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-base">HTML</CardTitle>
            </div>
            <CardDescription>Página web</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={exportToHTML} 
              disabled={loading !== null}
              className="w-full"
              variant="outline"
            >
              <Download className="h-4 w-4 mr-2" />
              {loading === "html" ? "Exportando..." : "Exportar HTML"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Share2 className="h-5 w-5 text-purple-600" />
              <CardTitle className="text-base">Email</CardTitle>
            </div>
            <CardDescription>Compartilhar</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={shareViaEmail} 
              disabled={loading !== null}
              className="w-full"
              variant="outline"
            >
              <Share2 className="h-4 w-4 mr-2" />
              {loading === "email" ? "Abrindo..." : "Compartilhar"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-base">CSV</CardTitle>
            </div>
            <CardDescription>Compatível com qualquer sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={exportToCSV} 
              disabled={loading !== null}
              className="w-full"
              variant="outline"
            >
              <Download className="h-4 w-4 mr-2" />
              {loading === "csv" ? "Exportando..." : "Exportar CSV"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Informações */}
      <div className="p-4 border rounded-lg bg-gray-50">
        <h4 className="font-semibold mb-2">Sobre os formatos:</h4>
        <div className="grid gap-2 text-sm text-gray-600 md:grid-cols-2">
          <div>
            <p><strong>Excel:</strong> Ideal para análises e edição</p>
            <p><strong>PDF:</strong> Perfeito para impressão e arquivo</p>
          </div>
          <div>
            <p><strong>HTML:</strong> Visualização em navegador</p>
            <p><strong>Email:</strong> Compartilhamento rápido</p>
          </div>
        </div>
      </div>
    </div>
  )
} 
