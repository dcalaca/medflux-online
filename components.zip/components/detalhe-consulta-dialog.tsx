"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import { Calendar, Clock, DollarSign, FileText, User, CreditCard } from "lucide-react"
import type { Paciente } from "@/types/database.types"
import { ProntuarioDialog } from "@/components/prontuario-dialog"

interface Consulta {
  id: string
  data_hora: string
  data_fim: string | null
  valor: number | null
  status: string
  status_pagamento: string
  observacoes: string | null
  tipos_consulta: {
    nome: string
    cor: string
    valor_padrao: number | null
  } | null
}

interface DetalheConsultaDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  consulta: Consulta
  paciente: Paciente
}

export function DetalheConsultaDialog({ open, onOpenChange, consulta, paciente }: DetalheConsultaDialogProps) {
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()
  const [showProntuario, setShowProntuario] = useState(false)

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString("pt-BR")
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmado":
        return "bg-green-100 text-green-800"
      case "agendado":
        return "bg-blue-100 text-blue-800"
      case "realizado":
        return "bg-gray-100 text-gray-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "pago":
        return "bg-green-100 text-green-800"
      case "pendente":
        return "bg-yellow-100 text-yellow-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleMarcarComoPago = async () => {
    setLoading(true)
    try {
      const supabase = createClient()

      const { error } = await supabase.from("consultas").update({ status_pagamento: "pago" }).eq("id", consulta.id)

      if (error) throw error

      toast({
        title: "Pagamento confirmado!",
        description: "O status do pagamento foi atualizado para 'pago'.",
      })

      // Atualizar o objeto consulta localmente
      consulta.status_pagamento = "pago"
    } catch (error) {
      console.error("Erro ao atualizar pagamento:", error)
      toast({
        title: "Erro ao atualizar pagamento",
        description: "Ocorreu um erro ao atualizar o status do pagamento.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleMarcarComoRealizado = async () => {
    setLoading(true)
    try {
      const supabase = createClient()

      const { error } = await supabase.from("consultas").update({ status: "realizado" }).eq("id", consulta.id)

      if (error) throw error

      toast({
        title: "Consulta marcada como realizada!",
        description: "O status da consulta foi atualizado.",
      })

      // Atualizar o objeto consulta localmente
      consulta.status = "realizado"
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      toast({
        title: "Erro ao atualizar status",
        description: "Ocorreu um erro ao atualizar o status da consulta.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>Detalhes da Consulta</span>
            </DialogTitle>
            <DialogDescription>
              Consulta de {paciente.nome} - {formatDate(consulta.data_hora)}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Informações básicas */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Informações da Consulta</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Data e Hora</label>
                    <p className="text-sm font-medium">{formatDateTime(consulta.data_hora)}</p>
                  </div>
                  {consulta.data_fim && (
                    <div>
                      <label className="text-sm font-medium text-gray-500">Término</label>
                      <p className="text-sm">{formatTime(consulta.data_fim)}</p>
                    </div>
                  )}
                </div>

                {consulta.tipos_consulta && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Tipo de Consulta</label>
                    <div className="mt-1">
                      <Badge
                        style={{
                          backgroundColor: consulta.tipos_consulta.cor + "20",
                          color: consulta.tipos_consulta.cor,
                          borderColor: consulta.tipos_consulta.cor,
                        }}
                        variant="outline"
                      >
                        {consulta.tipos_consulta.nome}
                      </Badge>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Status da Consulta</label>
                    <div className="mt-1">
                      <Badge className={getStatusColor(consulta.status)}>{consulta.status}</Badge>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Status do Pagamento</label>
                    <div className="mt-1">
                      <Badge className={getPaymentStatusColor(consulta.status_pagamento)}>
                        {consulta.status_pagamento}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações financeiras */}
            {consulta.valor && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center space-x-2">
                    <DollarSign className="w-4 h-4" />
                    <span>Informações Financeiras</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Valor da Consulta</label>
                    <p className="text-lg font-bold text-green-600">
                      {new Intl.NumberFormat("pt-BR", {
                        style: "currency",
                        currency: "BRL",
                      }).format(consulta.valor)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Informações do paciente */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>Paciente</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Nome</label>
                    <p className="text-sm font-medium">{paciente.nome}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Convênio</label>
                    <p className="text-sm">
                      {paciente.convenio ? (
                        <Badge variant="secondary">{paciente.convenio}</Badge>
                      ) : (
                        <Badge variant="outline">Particular</Badge>
                      )}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Observações */}
            {consulta.observacoes && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center space-x-2">
                    <FileText className="w-4 h-4" />
                    <span>Observações</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm whitespace-pre-wrap">{consulta.observacoes}</p>
                </CardContent>
              </Card>
            )}
          </div>

          <Separator />

          <DialogFooter className="flex justify-between">
            <div className="flex space-x-2">
              {consulta.status === "realizado" && (
                <Button onClick={() => setShowProntuario(true)} variant="outline" size="sm">
                  <FileText className="w-4 h-4 mr-2" />
                  Criar Prontuário
                </Button>
              )}
              {consulta.status_pagamento === "pendente" && (
                <Button onClick={handleMarcarComoPago} disabled={loading} variant="outline" size="sm">
                  <CreditCard className="w-4 h-4 mr-2" />
                  {loading ? "Atualizando..." : "Marcar como Pago"}
                </Button>
              )}
              {consulta.status === "agendado" && (
                <Button onClick={handleMarcarComoRealizado} disabled={loading} variant="outline" size="sm">
                  <Clock className="w-4 h-4 mr-2" />
                  {loading ? "Atualizando..." : "Marcar como Realizado"}
                </Button>
              )}
            </div>
            <Button onClick={() => onOpenChange(false)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ProntuarioDialog
        open={showProntuario}
        onOpenChange={setShowProntuario}
        consultaId={consulta.id}
        pacienteId={paciente.id}
        medicoId={paciente.medico_id}
        clinicaId={paciente.clinica_id}
        onProntuarioSalvo={() => {
          setShowProntuario(false)
          toast({
            title: "Prontuário criado!",
            description: "O prontuário da consulta foi salvo com sucesso.",
          })
        }}
      />
    </>
  )
}
