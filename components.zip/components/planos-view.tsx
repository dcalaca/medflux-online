"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Star, Users, Calendar, FileText, DollarSign, BarChart3, Mail, Shield, Smartphone } from "lucide-react"

export function PlanosView() {
  const recursos = [
    {
      icon: Calendar,
      titulo: "Agenda Completa",
      descricao: "Sistema de agendamento com lembretes automáticos e sincronização",
    },
    {
      icon: FileText,
      titulo: "Prontuário Eletrônico",
      descricao: "Prontuários digitais seguros e organizados conforme CFM",
    },
    {
      icon: DollarSign,
      titulo: "Controle Financeiro",
      descricao: "Gestão completa de pagamentos, faturamento e relatórios",
    },
    {
      icon: BarChart3,
      titulo: "Relatórios Avançados",
      descricao: "Análises detalhadas para otimizar sua clínica",
    },
    {
      icon: Users,
      titulo: "Gestão de Pacientes",
      descricao: "Cadastro completo com histórico e documentos",
    },
    {
      icon: Shield,
      titulo: "Segurança LGPD",
      descricao: "Proteção total dos dados conforme legislação",
    },
    {
      icon: Smartphone,
      titulo: "Acesso Mobile",
      descricao: "Use em qualquer dispositivo, a qualquer hora",
    },
    {
      icon: Mail,
      titulo: "Suporte Especializado",
      descricao: "Equipe técnica dedicada para ajudar você",
    },
  ]

  const beneficios = [
    "Pacientes ilimitados",
    "Usuários ilimitados",
    "Armazenamento ilimitado",
    "Backup automático diário",
    "Atualizações automáticas",
    "Suporte por email",
    "Treinamento incluído",
    "Sem taxa de setup",
    "Sem fidelidade",
    "Cancele quando quiser",
  ]

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <Badge className="bg-blue-100 text-blue-800 px-4 py-2 text-sm font-medium">
          ✨ Plano Único - Tudo Incluído
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900">
          Transforme sua clínica com o<span className="text-blue-600"> MedFlux</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Um sistema completo de gestão médica com todos os recursos que você precisa por um preço justo e transparente.
        </p>
      </div>

      {/* Card do Plano Principal */}
      <div className="max-w-4xl mx-auto">
        <Card className="relative overflow-hidden border-2 border-blue-200 shadow-2xl">
          <div className="absolute top-0 right-0 bg-gradient-to-l from-blue-600 to-blue-700 text-white px-6 py-2 text-sm font-semibold">
            <Star className="inline h-4 w-4 mr-1" />
            MAIS POPULAR
          </div>

          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-8 md:p-12">
            <div className="text-center space-y-4">
              <CardTitle className="text-3xl md:text-4xl font-bold">Plano MedFlux</CardTitle>
              <CardDescription className="text-blue-100 text-lg">
                Tudo que sua clínica precisa em um só lugar
              </CardDescription>

              <div className="space-y-2">
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-6xl md:text-7xl font-bold">R$ 149</span>
                  <span className="text-blue-100 text-xl">/mês</span>
                </div>
                <p className="text-blue-100 text-lg">Preço fixo • Sem surpresas</p>
              </div>

              <div className="flex items-center justify-center gap-2 text-blue-100">
                <Users className="h-5 w-5" />
                <span className="text-lg font-medium">Pacientes e usuários ilimitados</span>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-8 md:p-12">
            {/* Benefícios Principais */}
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">✅ Tudo incluído:</h3>
                <div className="space-y-4">
                  {beneficios.slice(0, 5).map((beneficio, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700 font-medium">{beneficio}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">🎯 Vantagens:</h3>
                <div className="space-y-4">
                  {beneficios.slice(5).map((beneficio, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700 font-medium">{beneficio}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Botão de Ação */}
            <div className="text-center space-y-4">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-4 text-xl font-semibold">
                Começar Agora - R$ 149/mês
              </Button>
              <p className="text-sm text-gray-500">
                ✅ Teste grátis por 30 dias • ✅ Sem cartão de crédito • ✅ Cancele quando quiser
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recursos Detalhados */}
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Recursos Completos Inclusos</h2>
          <p className="text-lg text-gray-600">
            Tudo que você precisa para gerenciar sua clínica de forma profissional
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {recursos.map((recurso, index) => (
            <div
              key={index}
              className="text-center space-y-4 p-6 bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
            >
              <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                <recurso.icon className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">{recurso.titulo}</h3>
              <p className="text-gray-600 text-sm">{recurso.descricao}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Seção de Garantia */}
      <div className="bg-green-50 rounded-2xl p-8 md:p-12 text-center max-w-4xl mx-auto border border-green-200">
        <div className="space-y-6">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <Shield className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Garantia de 30 Dias</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Experimente o MedFlux por 30 dias completamente grátis. Se não ficar satisfeito, cancele sem custos. Simples
            assim!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-3">
              Teste Grátis por 30 Dias
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="px-8 py-3 bg-transparent border-green-600 text-green-600 hover:bg-green-50"
            >
              Falar com Especialista
            </Button>
          </div>
        </div>
      </div>

      {/* FAQ Rápido */}
      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Perguntas Frequentes</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">💳 Como funciona o pagamento?</h3>
              <p className="text-gray-600 text-sm">
                Cobrança mensal de R$ 149,00 via cartão de crédito ou boleto. Sem taxa de setup ou fidelidade.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">📱 Funciona no celular?</h3>
              <p className="text-gray-600 text-sm">
                Sim! O sistema é totalmente responsivo e funciona perfeitamente em celulares, tablets e computadores.
              </p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">🔒 Os dados são seguros?</h3>
              <p className="text-gray-600 text-sm">
                Totalmente! Seguimos todas as normas da LGPD com criptografia e backup automático diário.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">🎓 Tem treinamento?</h3>
              <p className="text-gray-600 text-sm">
                Sim! Oferecemos treinamento completo e suporte técnico especializado por email.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
