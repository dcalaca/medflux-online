"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { 
  Eye, 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  Shield, 
  Stethoscope,
  Clock,
  DollarSign,
  CreditCard,
  Building
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  status_conta: string
  dias_teste_restantes?: number
  data_inicio_teste?: string
  created_at: string
  telefone?: string
  clinica_id?: string
  clinica?: {
    id: string
    nome: string
    cnpj?: string
  }
}

interface VisualizarUsuarioDialogProps {
  usuario: Usuario
}

export function VisualizarUsuarioDialog({ usuario }: VisualizarUsuarioDialogProps) {
  const [open, setOpen] = useState(false)

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "admin": return <Shield className="h-5 w-5" />
      case "medico": return <Stethoscope className="h-5 w-5" />
      case "recepcionista": return <User className="h-5 w-5" />
      default: return <User className="h-5 w-5" />
    }
  }

  const getTipoLabel = (tipo: string) => {
    switch (tipo) {
      case "admin": return "Administrador"
      case "medico": return "Médico"
      case "recepcionista": return "Recepcionista"
      default: return tipo
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "assinante": return "bg-green-100 text-green-800"
      case "teste": return "bg-blue-100 text-blue-800"
      case "expirado": return "bg-red-100 text-red-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "assinante": return "✅"
      case "teste": return "⏳"
      case "expirado": return "🔒"
      default: return "❓"
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Eye className="h-3 w-3" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Detalhes do Usuário</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Informações Principais */}
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              {getTipoIcon(usuario.tipo)}
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold">{usuario.nome}</h3>
              <p className="text-gray-600">{usuario.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline">
                  {getTipoLabel(usuario.tipo)}
                </Badge>
                <Badge className={getStatusColor(usuario.status_conta)}>
                  {getStatusIcon(usuario.status_conta)} {usuario.status_conta}
                </Badge>
              </div>
            </div>
          </div>

          {/* Informações de Contato */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="h-4 w-4" />
                <span>Email</span>
              </div>
              <p className="font-medium">{usuario.email}</p>
            </div>
            
            {usuario.telefone && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="h-4 w-4" />
                  <span>Telefone</span>
                </div>
                <p className="font-medium">{usuario.telefone}</p>
              </div>
            )}
          </div>

          {/* Informações da Clínica */}
          {usuario.clinica && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2 flex items-center gap-2">
                <Building className="h-4 w-4" />
                Clínica
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-blue-700">Nome:</span>
                  <p className="font-medium">{usuario.clinica.nome}</p>
                </div>
                {usuario.clinica.cnpj && (
                  <div>
                    <span className="text-blue-700">CNPJ:</span>
                    <p className="font-medium">{usuario.clinica.cnpj}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Informações do Sistema */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>Data de Cadastro</span>
              </div>
              <p className="font-medium">{format(new Date(usuario.created_at), "dd/MM/yyyy", { locale: ptBR })}</p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>ID do Usuário</span>
              </div>
              <p className="font-mono text-sm">{usuario.id}</p>
            </div>
            
            {usuario.dias_teste_restantes !== null && usuario.dias_teste_restantes !== undefined && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4" />
                  <span>Dias Restantes</span>
                </div>
                <p className="font-medium">{usuario.dias_teste_restantes} dias</p>
              </div>
            )}
          </div>

          {/* Informações de Teste (apenas para médicos) */}
          {usuario.tipo === "medico" && usuario.data_inicio_teste && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Período de Teste</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-blue-700">Início do teste:</span>
                  <p className="font-medium">{format(new Date(usuario.data_inicio_teste), "dd/MM/yyyy", { locale: ptBR })}</p>
                </div>
                <div>
                  <span className="text-blue-700">Dias restantes:</span>
                  <p className="font-medium">{usuario.dias_teste_restantes} dias</p>
                </div>
              </div>
            </div>
          )}

          {/* Estatísticas (se disponível) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium text-gray-700">Receita Gerada</span>
              </div>
              <p className="text-2xl font-bold text-green-600">R$ 0,00</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <CreditCard className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium text-gray-700">Pagamentos</span>
              </div>
              <p className="text-2xl font-bold text-blue-600">0</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <User className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium text-gray-700">Pacientes</span>
              </div>
              <p className="text-2xl font-bold text-purple-600">0</p>
            </div>
          </div>

          {/* Botões de Ação */}
          <div className="flex gap-2 pt-4">
            <Button onClick={() => setOpen(false)} className="flex-1">
              Fechar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
} 