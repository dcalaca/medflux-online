"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { 
  Users, 
  UserPlus, 
  UserCheck, 
  UserX, 
  Mail,
  Calendar,
  Shield,
  Stethoscope,
  User,
  Search,
  Filter,
  Download,
  RefreshCw,
  Edit,
  Trash2,
  Eye,
  Building,
  Check,
  ChevronsUpDown
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { EditarUsuarioDialog } from "./editar-usuario-dialog"
import { VisualizarUsuarioDialog } from "./visualizar-usuario-dialog"
import { DeletarUsuarioDialog } from "./deletar-usuario-dialog"

interface Clinica {
  id: string
  nome: string
  cnpj?: string
}

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  status_conta: string
  dias_teste_restantes?: number
  data_inicio_teste?: string
  created_at: string
  telefone?: string
  clinica_id?: string
  clinica?: Clinica
}

export default function GestaoUsuariosView() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [clinicas, setClinicas] = useState<Clinica[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [tipoFilter, setTipoFilter] = useState("todos")
  const [statusFilter, setStatusFilter] = useState("todos")
  const [clinicaFilter, setClinicaFilter] = useState("todos")
  const [openTipo, setOpenTipo] = useState(false)
  const [openStatus, setOpenStatus] = useState(false)
  const [openClinica, setOpenClinica] = useState(false)
  const [stats, setStats] = useState({
    totalUsuarios: 0,
    medicos: 0,
    recepcionistas: 0,
    admins: 0,
    usuariosAtivos: 0
  })

  const supabase = createClient()

  useEffect(() => {
    carregarUsuarios()
    carregarClinicas()
  }, [])

  const carregarClinicas = async () => {
    try {
      const { data: clinicasData, error } = await supabase
        .from("clinicas")
        .select("id, nome, cnpj")
        .order("nome")

      if (error) {
        console.error("Erro ao carregar clínicas:", error)
        return
      }

      setClinicas(clinicasData || [])
    } catch (error) {
      console.error("Erro ao carregar clínicas:", error)
    }
  }

  const carregarUsuarios = async () => {
    try {
      setLoading(true)

      const { data: usuariosData, error } = await supabase
        .from("usuarios")
        .select(`
          *,
          clinica:clinicas(id, nome, cnpj)
        `)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Erro ao buscar usuários:", error)
        return
      }

      setUsuarios(usuariosData || [])

      // Calcular estatísticas
      const medicos = usuariosData?.filter(u => u.tipo === "medico") || []
      const recepcionistas = usuariosData?.filter(u => u.tipo === "recepcionista") || []
      const admins = usuariosData?.filter(u => u.tipo === "admin") || []
      const ativos = usuariosData?.filter(u => u.status_conta === "assinante") || []

      setStats({
        totalUsuarios: usuariosData?.length || 0,
        medicos: medicos.length,
        recepcionistas: recepcionistas.length,
        admins: admins.length,
        usuariosAtivos: ativos.length
      })

    } catch (error) {
      console.error("Erro ao carregar usuários:", error)
    } finally {
      setLoading(false)
    }
  }

  const filtrarUsuarios = () => {
    let filtrados = usuarios

    // Filtro por busca
    if (searchTerm) {
      filtrados = filtrados.filter(usuario =>
        usuario.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        usuario.email?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filtro por tipo
    if (tipoFilter !== "todos") {
      filtrados = filtrados.filter(usuario => usuario.tipo === tipoFilter)
    }

    // Filtro por status
    if (statusFilter !== "todos") {
      filtrados = filtrados.filter(usuario => usuario.status_conta === statusFilter)
    }

    // Filtro por clínica
    if (clinicaFilter !== "todos") {
      if (clinicaFilter === "sem-clinica") {
        filtrados = filtrados.filter(usuario => !usuario.clinica_id || usuario.clinica_id === "")
      } else {
        filtrados = filtrados.filter(usuario => usuario.clinica_id === clinicaFilter)
      }
    }

    return filtrados
  }

  const exportarRelatorio = () => {
    const dados = filtrarUsuarios()
    const csvContent = [
      ["Nome", "Email", "Tipo", "Status", "Clínica", "Dias Restantes", "Data Cadastro", "Telefone"],
      ...dados.map(usuario => [
        usuario.nome,
        usuario.email,
        usuario.tipo,
        usuario.status_conta,
        usuario.clinica?.nome || "Sem clínica",
        usuario.dias_teste_restantes?.toString() || "",
        format(new Date(usuario.created_at), "dd/MM/yyyy", { locale: ptBR }),
        usuario.telefone || ""
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `relatorio-usuarios-${format(new Date(), "dd-MM-yyyy")}.csv`
    a.click()
  }

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "admin": return <Shield className="h-4 w-4" />
      case "medico": return <Stethoscope className="h-4 w-4" />
      case "recepcionista": return <User className="h-4 w-4" />
      default: return <User className="h-4 w-4" />
    }
  }

  const getTipoLabel = (tipo: string) => {
    switch (tipo) {
      case "admin": return "Administrador"
      case "medico": return "Médico"
      case "recepcionista": return "Recepcionista"
      default: return tipo
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "teste": return "Em Teste"
      case "assinante": return "Assinante"
      case "expirado": return "Expirado"
      default: return status
    }
  }

  const tipos = [
    { value: "todos", label: "Todos os tipos", description: undefined },
    { value: "medico", label: "Médicos", icon: <Stethoscope className="h-4 w-4" />, description: undefined },
    { value: "recepcionista", label: "Recepcionistas", icon: <User className="h-4 w-4" />, description: undefined },
    { value: "admin", label: "Administradores", icon: <Shield className="h-4 w-4" />, description: undefined }
  ]

  const statuses = [
    { value: "todos", label: "Todos os status", description: undefined },
    { value: "teste", label: "Em Teste", description: undefined },
    { value: "assinante", label: "Assinante", description: undefined },
    { value: "expirado", label: "Expirado", description: undefined }
  ]

  const clinicasOptions = [
    { value: "todos", label: "Todas as clínicas", description: undefined },
    { value: "sem-clinica", label: "Sem clínica", icon: <Building className="h-4 w-4" />, description: undefined },
    ...clinicas.map(clinica => ({
      value: clinica.id,
      label: clinica.nome,
      description: clinica.cnpj,
      icon: <Building className="h-4 w-4" />
    }))
  ]

  const usuariosFiltrados = filtrarUsuarios()

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando usuários...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Gestão de Usuários</h1>
        <p className="text-gray-600 mt-2">Controle completo de todos os usuários do sistema</p>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsuarios}</div>
            <p className="text-xs text-muted-foreground">Todos os usuários</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Médicos</CardTitle>
            <Stethoscope className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.medicos}</div>
            <p className="text-xs text-muted-foreground">Clientes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recepcionistas</CardTitle>
            <User className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.recepcionistas}</div>
            <p className="text-xs text-muted-foreground">Funcionários</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Administradores</CardTitle>
            <Shield className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.admins}</div>
            <p className="text-xs text-muted-foreground">Admins</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários Ativos</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.usuariosAtivos}</div>
            <p className="text-xs text-muted-foreground">Assinantes</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros e Ações</CardTitle>
          <CardDescription>Filtre e gerencie usuários</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por nome ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            {/* Filtro por Tipo */}
            <div className="w-full md:w-48">
              <Popover open={openTipo} onOpenChange={setOpenTipo}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openTipo}
                    className="w-full justify-between"
                  >
                    {tipos.find(tipo => tipo.value === tipoFilter)?.label || "Selecione tipo..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-48 p-0">
                  <Command>
                    <CommandInput placeholder="Buscar tipo..." />
                    <CommandList>
                      <CommandEmpty>Nenhum tipo encontrado.</CommandEmpty>
                      <CommandGroup>
                        {tipos.map((tipo) => (
                          <CommandItem
                            key={tipo.value}
                            value={tipo.label}
                            onSelect={() => {
                              setTipoFilter(tipo.value)
                              setOpenTipo(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                tipoFilter === tipo.value ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {tipo.icon && <span className="mr-2">{tipo.icon}</span>}
                            {tipo.label}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            {/* Filtro por Status */}
            <div className="w-full md:w-48">
              <Popover open={openStatus} onOpenChange={setOpenStatus}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openStatus}
                    className="w-full justify-between"
                  >
                    {statuses.find(status => status.value === statusFilter)?.label || "Selecione status..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-48 p-0">
                  <Command>
                    <CommandInput placeholder="Buscar status..." />
                    <CommandList>
                      <CommandEmpty>Nenhum status encontrado.</CommandEmpty>
                      <CommandGroup>
                        {statuses.map((status) => (
                          <CommandItem
                            key={status.value}
                            value={status.label}
                            onSelect={() => {
                              setStatusFilter(status.value)
                              setOpenStatus(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                statusFilter === status.value ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {status.label}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            {/* Filtro por Clínica */}
            <div className="w-full md:w-48">
              <Popover open={openClinica} onOpenChange={setOpenClinica}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openClinica}
                    className="w-full justify-between"
                  >
                    {clinicasOptions.find(clinica => clinica.value === clinicaFilter)?.label || "Selecione clínica..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-64 p-0">
                  <Command>
                    <CommandInput placeholder="Buscar clínica..." />
                    <CommandList>
                      <CommandEmpty>Nenhuma clínica encontrada.</CommandEmpty>
                      <CommandGroup>
                        {clinicasOptions.map((clinica) => (
                          <CommandItem
                            key={clinica.value}
                            value={clinica.label}
                            onSelect={() => {
                              setClinicaFilter(clinica.value)
                              setOpenClinica(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                clinicaFilter === clinica.value ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {clinica.icon && <span className="mr-2">{clinica.icon}</span>}
                            <div className="flex flex-col">
                              <span>{clinica.label}</span>
                              {clinica.description && (
                                <span className="text-xs text-gray-500">{clinica.description}</span>
                              )}
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            <Button onClick={exportarRelatorio} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Exportar CSV
            </Button>
            <Button onClick={carregarUsuarios} variant="outline" className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Atualizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Usuários */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Usuários</CardTitle>
          <CardDescription>
            {usuariosFiltrados.length} usuário(s) encontrado(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Clínica</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Dias Restantes</TableHead>
                  <TableHead>Data Cadastro</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {usuariosFiltrados.map((usuario) => (
                  <TableRow key={usuario.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{usuario.nome}</div>
                        <div className="text-sm text-gray-500 flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {usuario.email}
                        </div>
                        {usuario.telefone && (
                          <div className="text-sm text-gray-500">{usuario.telefone}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {usuario.clinica ? (
                        <div>
                          <div className="font-medium text-blue-600">{usuario.clinica.nome}</div>
                          {usuario.clinica.cnpj && (
                            <div className="text-xs text-gray-500">{usuario.clinica.cnpj}</div>
                          )}
                        </div>
                      ) : (
                        <div className="text-gray-400 text-sm">Sem clínica</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getTipoIcon(usuario.tipo)}
                        <Badge variant="outline">
                          {getTipoLabel(usuario.tipo)}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          usuario.status_conta === "assinante"
                            ? "default"
                            : usuario.status_conta === "teste"
                            ? "secondary"
                            : "destructive"
                        }
                      >
                        {usuario.status_conta === "assinante" && "✅ Assinante"}
                        {usuario.status_conta === "teste" && "⏳ Em Teste"}
                        {usuario.status_conta === "expirado" && "🔒 Expirado"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {usuario.dias_teste_restantes !== null && usuario.dias_teste_restantes !== undefined ? (
                        <span className="font-medium">{usuario.dias_teste_restantes} dias</span>
                      ) : (
                        <span className="text-gray-500">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-gray-400" />
                        {format(new Date(usuario.created_at), "dd/MM/yyyy", { locale: ptBR })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <VisualizarUsuarioDialog usuario={usuario} />
                        <EditarUsuarioDialog usuario={usuario} onUpdate={carregarUsuarios} />
                        <DeletarUsuarioDialog usuario={usuario} onDelete={carregarUsuarios} />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 