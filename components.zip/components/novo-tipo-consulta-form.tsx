"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import type { Usuario } from "@/types/database.types"

interface NovoTipoConsultaFormProps {
  usuario: Usuario
}

const cores = [
  "#3B82F6", // Azul
  "#10B981", // Verde
  "#F59E0B", // Amarelo
  "#EF4444", // Vermelho
  "#8B5CF6", // Roxo
  "#F97316", // Laranja
  "#06B6D4", // Ciano
  "#84CC16", // Lima
  "#EC4899", // Rosa
  "#6B7280", // Cinza
]

export function NovoTipoConsultaForm({ usuario }: NovoTipoConsultaFormProps) {
  const [formData, setFormData] = useState({
    nome: "",
    valor_padrao: "",
    duracao: "30",
    cor: "#3B82F6",
  })
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const { error } = await supabase.from("tipos_consulta").insert({
        medico_id: usuario.id,
        clinica_id: usuario.clinica_id!,
        nome: formData.nome,
        valor_padrao: formData.valor_padrao ? Number.parseFloat(formData.valor_padrao) : null,
        duracao: Number.parseInt(formData.duracao),
        cor: formData.cor,
      })

      if (error) throw error

      toast({
        title: "Tipo criado com sucesso!",
        description: "O novo tipo de consulta foi adicionado.",
      })

      router.push("/tipos-consulta")
    } catch (error) {
      toast({
        title: "Erro ao criar tipo",
        description: "Ocorreu um erro ao criar o tipo de consulta.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild>
          <Link href="/tipos-consulta">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Tipos de Consulta
          </Link>
        </Button>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Informações do Tipo</CardTitle>
            <CardDescription>Configure o novo tipo de consulta</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome do Tipo *</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Ex: Consulta Geral, Retorno, Exame..."
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="valor_padrao">Valor Padrão (R$)</Label>
                <Input
                  id="valor_padrao"
                  type="number"
                  step="0.01"
                  value={formData.valor_padrao}
                  onChange={(e) => setFormData({ ...formData, valor_padrao: e.target.value })}
                  placeholder="150.00"
                />
              </div>

              <div>
                <Label htmlFor="duracao">Duração (minutos) *</Label>
                <Input
                  id="duracao"
                  type="number"
                  value={formData.duracao}
                  onChange={(e) => setFormData({ ...formData, duracao: e.target.value })}
                  required
                />
              </div>
            </div>

            <div>
              <Label>Cor do Tipo</Label>
              <div className="grid grid-cols-5 gap-2 mt-2">
                {cores.map((cor) => (
                  <button
                    key={cor}
                    type="button"
                    className={`w-12 h-12 rounded-lg border-2 ${
                      formData.cor === cor ? "border-gray-900" : "border-gray-200"
                    }`}
                    style={{ backgroundColor: cor }}
                    onClick={() => setFormData({ ...formData, cor })}
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground mt-1">Cor selecionada: {formData.cor}</p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end space-x-4 mt-6">
          <Button type="button" variant="outline" asChild>
            <Link href="/tipos-consulta">Cancelar</Link>
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Salvando..." : "Salvar Tipo"}
          </Button>
        </div>
      </form>
    </div>
  )
}
