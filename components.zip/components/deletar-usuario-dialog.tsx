"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Trash2, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
}

interface DeletarUsuarioDialogProps {
  usuario: Usuario
  onDelete: () => void
}

export function DeletarUsuarioDialog({ usuario, onDelete }: DeletarUsuarioDialogProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  const { toast } = useToast()
  const supabase = createClient()

  const handleDelete = async () => {
    setLoading(true)

    try {
      // Primeiro deletar da tabela de usuários
      const { error: usuariosError } = await supabase
        .from("usuarios")
        .delete()
        .eq("id", usuario.id)

      if (usuariosError) {
        throw usuariosError
      }

      // Depois deletar da auth (se necessário)
      // const { error: authError } = await supabase.auth.admin.deleteUser(usuario.id)
      // if (authError) {
      //   console.warn("Erro ao deletar usuário da auth:", authError)
      // }

      toast({
        title: "Usuário deletado",
        description: `${usuario.nome} foi removido do sistema.`,
      })

      onDelete()
      setOpen(false)
    } catch (error) {
      console.error("Erro ao deletar usuário:", error)
      toast({
        title: "Erro",
        description: "Não foi possível deletar o usuário.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
          <Trash2 className="h-3 w-3" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Confirmar Exclusão</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 bg-red-50 rounded-lg">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <div>
              <h4 className="font-medium text-red-900">Atenção!</h4>
              <p className="text-sm text-red-700">
                Esta ação não pode ser desfeita.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm text-gray-600">
              Você está prestes a deletar o usuário:
            </p>
            <div className="bg-gray-50 p-3 rounded-lg">
              <p className="font-medium">{usuario.nome}</p>
              <p className="text-sm text-gray-600">{usuario.email}</p>
              <p className="text-sm text-gray-600 capitalize">{usuario.tipo}</p>
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button 
              onClick={handleDelete} 
              disabled={loading} 
              variant="destructive" 
              className="flex-1"
            >
              {loading ? "Deletando..." : "Sim, Deletar"}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setOpen(false)}
            >
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
} 