"use client"

import { useEffect, useState } from "react"

export default function CadastroUsuariosWrapper() {
  const [Component, setComponent] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    import("./cadastro-usuarios-view").then((module) => {
      setComponent(() => module.CadastroUsuariosView)
      setLoading(false)
    }).catch((error) => {
      console.error("Erro ao carregar componente:", error)
      setLoading(false)
    })
  }, [])

  if (loading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Cadastro de Usuários</h1>
            <p className="text-gray-600 mt-2">Gerencie os recepcionistas da sua clínica</p>
          </div>
        </div>
        
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-500 mt-4">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!Component) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Cadastro de Usuários</h1>
            <p className="text-gray-600 mt-2">Gerencie os recepcionistas da sua clínica</p>
          </div>
        </div>
        
        <div className="text-center py-8">
          <p className="text-red-500">Erro ao carregar componente</p>
        </div>
      </div>
    )
  }

  return <Component />
} 
