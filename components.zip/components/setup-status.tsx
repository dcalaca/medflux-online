"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, Clock } from "lucide-react"

export function SetupStatus() {
  const [status, setStatus] = useState({
    database: "checking",
    clinic: "checking",
    user: "checking",
    ready: false,
  })

  const supabase = createClient()

  useEffect(() => {
    checkSetupStatus()
  }, [])

  const checkSetupStatus = async () => {
    try {
      // Check database tables
      const { data: tables, error: tablesError } = await supabase.from("clinicas").select("id").limit(1)

      // Check clinic exists
      const { data: clinic, error: clinicError } = await supabase
        .from("clinicas")
        .select("*")
        .eq("id", "f47ac10b-58cc-4372-a567-0e02b2c3d479")
        .single()

      // Check user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      let userStatus = "error"
      if (user) {
        const { data: userData } = await supabase.from("usuarios").select("*").eq("id", user.id).single()
        userStatus = userData ? "success" : "error"
      }

      setStatus({
        database: tablesError ? "error" : "success",
        clinic: clinicError ? "error" : "success",
        user: userStatus,
        ready: !tablesError && !clinicError && userStatus === "success",
      })
    } catch (error) {
      console.error("Erro ao verificar status:", error)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "error":
        return <XCircle className="w-5 h-5 text-red-500" />
      default:
        return <Clock className="w-5 h-5 text-yellow-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "success":
        return <Badge className="bg-green-100 text-green-800">Configurado</Badge>
      case "error":
        return <Badge className="bg-red-100 text-red-800">Erro</Badge>
      default:
        return <Badge className="bg-yellow-100 text-yellow-800">Verificando</Badge>
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Status da Configuração</CardTitle>
        <CardDescription>Verificação do sistema MedFlux</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon(status.database)}
            <span>Banco de Dados</span>
          </div>
          {getStatusBadge(status.database)}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon(status.clinic)}
            <span>Clínica</span>
          </div>
          {getStatusBadge(status.clinic)}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon(status.user)}
            <span>Usuário</span>
          </div>
          {getStatusBadge(status.user)}
        </div>

        {status.ready && (
          <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-green-800 font-medium">Sistema pronto para uso!</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
