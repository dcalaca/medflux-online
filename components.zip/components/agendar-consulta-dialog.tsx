"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import type { Paciente, Usuario } from "@/types/database.types"

interface TipoConsulta {
  id: string
  nome: string
  valor_padrao: number | null
  duracao: number
  cor: string
}

interface AgendarConsultaDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  paciente: Paciente
  tiposConsulta: TipoConsulta[]
  usuario: Usuario
  onConsultaAgendada: () => void
}

export function AgendarConsultaDialog({
  open,
  onOpenChange,
  paciente,
  tiposConsulta,
  usuario,
  onConsultaAgendada,
}: AgendarConsultaDialogProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    data: "",
    hora: "",
    tipo_consulta_id: "",
    valor: "",
    observacoes: "",
  })
  const { toast } = useToast()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const supabase = createClient()

      // Validar dados obrigatórios
      if (!usuario.clinica_id) {
        throw new Error("Usuário não está associado a uma clínica")
      }

      if (!formData.tipo_consulta_id) {
        throw new Error("Tipo de consulta é obrigatório")
      }

      if (!formData.data || !formData.hora) {
        throw new Error("Data e hora são obrigatórios")
      }

      // Combinar data e hora
      const dataHora = new Date(`${formData.data}T${formData.hora}:00`)

      // Buscar duração do tipo de consulta
      const tipoSelecionado = tiposConsulta.find((t) => t.id === formData.tipo_consulta_id)
      const duracaoMinutos = tipoSelecionado?.duracao || 60

      // Log para debug
      console.log("Dados da consulta:", {
        medico_id: usuario.id,
        paciente_id: paciente.id,
        clinica_id: usuario.clinica_id,
        tipo_consulta_id: formData.tipo_consulta_id,
        data_hora: dataHora.toISOString(),
        valor: formData.valor ? Number.parseFloat(formData.valor) : null,
        status: "agendado",
        status_pagamento: "pendente",
        observacoes: formData.observacoes || null,
      })

      // Log do usuário atual
      console.log("Usuário atual:", {
        id: usuario.id,
        nome: usuario.nome,
        tipo: usuario.tipo,
        clinica_id: usuario.clinica_id
      })

      const insertData = {
        medico_id: usuario.id,
        paciente_id: paciente.id,
        clinica_id: usuario.clinica_id,
        tipo_consulta_id: formData.tipo_consulta_id,
        data_hora: dataHora.toISOString(),
        valor: formData.valor ? Number.parseFloat(formData.valor) : null,
        status: "agendado",
        status_pagamento: "pendente",
        observacoes: formData.observacoes || null,
      }

      console.log("Tentando inserir consulta com dados:", insertData)

      const { error } = await supabase.from("consultas").insert(insertData)

      if (error) {
        console.error("Erro do Supabase:", error)
        console.error("Detalhes do erro:", {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        })
        throw error
      }

      toast({
        title: "Consulta agendada!",
        description: "A consulta foi agendada com sucesso.",
      })

      setFormData({
        data: "",
        hora: "",
        tipo_consulta_id: "",
        valor: "",
        observacoes: "",
      })

      onConsultaAgendada()
    } catch (error) {
      console.error("Erro ao agendar consulta:", error)
      
      let errorMessage = "Ocorreu um erro ao agendar a consulta. Tente novamente."
      
      if (error instanceof Error) {
        errorMessage = error.message
      } else if (typeof error === 'object' && error !== null && 'message' in error) {
        errorMessage = String(error.message)
      }
      
      toast({
        title: "Erro ao agendar consulta",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleTipoConsultaChange = (tipoId: string) => {
    setFormData((prev) => ({ ...prev, tipo_consulta_id: tipoId }))

    // Preencher valor padrão se disponível
    const tipo = tiposConsulta.find((t) => t.id === tipoId)
    if (tipo?.valor_padrao) {
      setFormData((prev) => ({ ...prev, valor: tipo.valor_padrao!.toString() }))
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Agendar Consulta</DialogTitle>
          <DialogDescription>Agendar nova consulta para {paciente.nome}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data">Data</Label>
                <Input
                  id="data"
                  type="date"
                  value={formData.data}
                  onChange={(e) => setFormData((prev) => ({ ...prev, data: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hora">Hora</Label>
                <Input
                  id="hora"
                  type="time"
                  value={formData.hora}
                  onChange={(e) => setFormData((prev) => ({ ...prev, hora: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo">Tipo de Consulta</Label>
              <Select value={formData.tipo_consulta_id} onValueChange={handleTipoConsultaChange} required>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo de consulta" />
                </SelectTrigger>
                <SelectContent>
                  {tiposConsulta.map((tipo) => (
                    <SelectItem key={tipo.id} value={tipo.id}>
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: tipo.cor }} />
                        <span>{tipo.nome}</span>
                        {tipo.valor_padrao && (
                          <span className="text-sm text-gray-500">
                            -{" "}
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(tipo.valor_padrao)}
                          </span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="valor">Valor (R$)</Label>
              <Input
                id="valor"
                type="number"
                step="0.01"
                placeholder="0,00"
                value={formData.valor}
                onChange={(e) => setFormData((prev) => ({ ...prev, valor: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                placeholder="Observações sobre a consulta..."
                value={formData.observacoes}
                onChange={(e) => setFormData((prev) => ({ ...prev, observacoes: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Agendando..." : "Agendar Consulta"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
