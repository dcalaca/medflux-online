"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { toast } from "sonner"
import { Eye, EyeOff, Loader2, User, Building, Stethoscope } from "lucide-react"

interface Especialidade {
  id: string
  nome: string
  tipo: "medica" | "odontologica" | "outras"
  ativo: boolean
}

export function RegistroForm() {
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [especialidades, setEspecialidades] = useState<Especialidade[]>([])
  const [loadingEspecialidades, setLoadingEspecialidades] = useState(true)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    nome: "",
    crm: "",
    especialidade: "",
    telefone: "",
    clinica_nome: "",
    clinica_endereco: "",
    clinica_telefone: "",
    clinica_email: "",
  })

  const router = useRouter()
  const supabase = createClientComponentClient()

  useEffect(() => {
    carregarEspecialidades()
  }, [])

  const carregarEspecialidades = async () => {
    try {
      const { data, error } = await supabase
        .from("especialidades")
        .select("*")
        .eq("ativo", true)
        .order("tipo", { ascending: true })
        .order("nome", { ascending: true })

      if (error) throw error
      setEspecialidades(data || [])
    } catch (error) {
      console.error("Erro ao carregar especialidades:", error)
      toast.error("Erro ao carregar especialidades")
    } finally {
      setLoadingEspecialidades(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validações obrigatórias
    if (!formData.nome || formData.nome.trim() === "") {
      toast.error("Nome completo é obrigatório")
      return
    }

    if (!formData.email || formData.email.trim() === "") {
      toast.error("Email é obrigatório")
      return
    }

    if (!formData.password || formData.password.trim() === "") {
      toast.error("Senha é obrigatória")
      return
    }

    if (!formData.confirmPassword || formData.confirmPassword.trim() === "") {
      toast.error("Confirmação de senha é obrigatória")
      return
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error("As senhas não coincidem")
      return
    }

    if (formData.password.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres")
      return
    }

    if (!formData.crm || formData.crm.trim() === "") {
      toast.error("CRM/CRO é obrigatório")
      return
    }

    if (!formData.especialidade || formData.especialidade.trim() === "") {
      toast.error("Especialidade é obrigatória")
      return
    }

    if (!formData.clinica_nome || formData.clinica_nome.trim() === "") {
      toast.error("Nome da clínica é obrigatório")
      return
    }

    setLoading(true)

    try {
      // 1. Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            nome: formData.nome,
            crm: formData.crm,
            especialidade: formData.especialidade,
            telefone: formData.telefone,
          },
        },
      })

      if (authError) throw authError

      if (authData.user) {
        // 2. Criar clínica
        const { data: clinicaData, error: clinicaError } = await supabase
          .from("clinicas")
          .insert({
            nome: formData.clinica_nome,
            endereco: formData.clinica_endereco,
            telefone: formData.clinica_telefone,
            email: formData.clinica_email,
            ativo: true,
          })
          .select()
          .single()

        if (clinicaError) throw clinicaError

        // 3. Criar usuário na tabela usuarios
        const { error: usuarioError } = await supabase.from("usuarios").insert({
          id: authData.user.id,
          email: formData.email,
          nome: formData.nome,
          crm: formData.crm,
          especialidade: formData.especialidade,
          telefone: formData.telefone,
          clinica_id: clinicaData.id,
          tipo: "medico",
          ativo: true,
        })

        if (usuarioError) throw usuarioError

        toast.success("Cadastro realizado com sucesso!")
        router.push("/login?message=Cadastro realizado com sucesso! Faça login para continuar.")
      }
    } catch (error: any) {
      if (error && typeof error === "object") {
        console.error("Erro no cadastro:", JSON.stringify(error, null, 2))
      } else {
        console.error("Erro no cadastro:", error)
      }
      toast.error(error.message || "Erro ao realizar cadastro")
    } finally {
      setLoading(false)
    }
  }

  const especialidadesPorTipo = especialidades.reduce(
    (acc, esp) => {
      if (!acc[esp.tipo]) acc[esp.tipo] = []
      acc[esp.tipo].push(esp)
      return acc
    },
    {} as Record<string, Especialidade[]>,
  )

  const getTipoLabel = (tipo: string) => {
    switch (tipo) {
      case "medica":
        return "Médicas"
      case "odontologica":
        return "Odontológicas"
      case "outras":
        return "Outras"
      default:
        return tipo
    }
  }

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "medica":
        return <Stethoscope className="h-4 w-4" />
      case "odontologica":
        return <User className="h-4 w-4" />
      case "outras":
        return <Building className="h-4 w-4" />
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-gray-900">Cadastro MedFlux</CardTitle>
          <CardDescription className="text-lg text-gray-600">Crie sua conta e comece a usar o sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <Tabs defaultValue="pessoal" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="pessoal">Dados Pessoais</TabsTrigger>
                <TabsTrigger value="profissional">Dados Profissionais</TabsTrigger>
                <TabsTrigger value="clinica">Dados da Clínica</TabsTrigger>
              </TabsList>

              <TabsContent value="pessoal" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome Completo *</Label>
                    <Input
                      id="nome"
                      type="text"
                      value={formData.nome}
                      onChange={(e) => handleInputChange("nome", e.target.value)}
                      required
                      placeholder="Seu nome completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      required
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha *</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={formData.password}
                        onChange={(e) => handleInputChange("password", e.target.value)}
                        required
                        placeholder="Mínimo 6 caracteres"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        value={formData.confirmPassword}
                        onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                        required
                        placeholder="Confirme sua senha"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone (Opcional)</Label>
                  <Input
                    id="telefone"
                    type="tel"
                    value={formData.telefone}
                    onChange={(e) => handleInputChange("telefone", e.target.value)}
                    placeholder="(11) 99999-9999"
                  />
                </div>
              </TabsContent>

              <TabsContent value="profissional" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="crm">CRM/CRO *</Label>
                    <Input
                      id="crm"
                      type="text"
                      value={formData.crm}
                      onChange={(e) => handleInputChange("crm", e.target.value)}
                      required
                      placeholder="Ex: CRM 123456"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="especialidade">Especialidade *</Label>
                    {loadingEspecialidades ? (
                      <div className="flex items-center justify-center p-4">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span className="ml-2">Carregando especialidades...</span>
                      </div>
                    ) : (
                      <Select
                        value={formData.especialidade}
                        onValueChange={(value) => handleInputChange("especialidade", value)}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione sua especialidade" />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(especialidadesPorTipo).map(([tipo, especialidadesList]) => (
                            <div key={tipo}>
                              <div className="flex items-center gap-2 px-2 py-1 text-sm font-medium text-gray-500">
                                {getTipoIcon(tipo)}
                                {getTipoLabel(tipo)}
                              </div>
                              {especialidadesList.map((especialidade) => (
                                <SelectItem key={especialidade.id} value={especialidade.nome}>
                                  <div className="flex items-center gap-2">
                                    <span>{especialidade.nome}</span>
                                    <Badge variant="outline" className="text-xs">
                                      {getTipoLabel(especialidade.tipo)}
                                    </Badge>
                                  </div>
                                </SelectItem>
                              ))}
                            </div>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="clinica" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="clinica_nome">Nome da Clínica *</Label>
                  <Input
                    id="clinica_nome"
                    type="text"
                    value={formData.clinica_nome}
                    onChange={(e) => handleInputChange("clinica_nome", e.target.value)}
                    required
                    placeholder="Nome da sua clínica"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="clinica_endereco">Endereço da Clínica (Opcional)</Label>
                  <Input
                    id="clinica_endereco"
                    type="text"
                    value={formData.clinica_endereco}
                    onChange={(e) => handleInputChange("clinica_endereco", e.target.value)}
                    placeholder="Endereço completo"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="clinica_telefone">Telefone da Clínica (Opcional)</Label>
                    <Input
                      id="clinica_telefone"
                      type="tel"
                      value={formData.clinica_telefone}
                      onChange={(e) => handleInputChange("clinica_telefone", e.target.value)}
                      placeholder="(11) 3333-3333"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="clinica_email">Email da Clínica (Opcional)</Label>
                    <Input
                      id="clinica_email"
                      type="email"
                      value={formData.clinica_email}
                      onChange={(e) => handleInputChange("clinica_email", e.target.value)}
                      placeholder="contato@clinica.com"
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <Button type="submit" className="w-full" size="lg" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Criando conta...
                </>
              ) : (
                "Criar Conta"
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Já tem uma conta?{" "}
              <Button variant="link" className="p-0 h-auto font-semibold" onClick={() => router.push("/login")}>
                Fazer login
              </Button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
