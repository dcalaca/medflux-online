"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Plus, Search, Bell, CheckCircle, AlertCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { toast } from "@/hooks/use-toast"

interface Lembrete {
  id: string
  titulo: string
  descricao: string
  data_lembrete: string
  tipo: "consulta" | "medicamento" | "exame" | "geral"
  status: "ativo" | "concluido"
  paciente_id?: string
  paciente?: {
    nome: string
  }
  created_at: string
}

export function LembretesView() {
  const supabase = createClient()
  
  const [lembretes, setLembretes] = useState<Lembrete[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterTipo, setFilterTipo] = useState<string>("todos")
  const [filterStatus, setFilterStatus] = useState<string>("todos")

  // Form state
  const [formData, setFormData] = useState({
    titulo: "",
    descricao: "",
    data_lembrete: "",
    tipo: "geral" as const,
    paciente_id: "",
  })

  useEffect(() => {
    carregarLembretes()
  }, [])

  const carregarLembretes = async () => {
    try {
      setLoading(true)

      const { data, error } = await supabase
        .from("lembretes")
        .select(`
          *,
          paciente:pacientes(nome)
        `)
        .order("data_lembrete", { ascending: true })

      if (error) {
        console.error("Erro ao carregar lembretes:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar os lembretes",
          variant: "destructive",
        })
        return
      }

      setLembretes(data || [])
    } catch (error) {
      console.error("Erro:", error)
      toast({
        title: "Erro",
        description: "Erro inesperado ao carregar lembretes",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const criarLembrete = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const { error } = await supabase.from("lembretes").insert([
        {
          ...formData,
          status: "ativo",
        },
      ])

      if (error) {
        console.error("Erro ao criar lembrete:", error)
        toast({
          title: "Erro",
          description: "Não foi possível criar o lembrete",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Sucesso",
        description: "Lembrete criado com sucesso!",
      })

      setFormData({
        titulo: "",
        descricao: "",
        data_lembrete: "",
        tipo: "geral",
        paciente_id: "",
      })
      setShowForm(false)
      carregarLembretes()
    } catch (error) {
      console.error("Erro:", error)
      toast({
        title: "Erro",
        description: "Erro inesperado ao criar lembrete",
        variant: "destructive",
      })
    }
  }

  const marcarConcluido = async (id: string) => {
    try {
      const { error } = await supabase.from("lembretes").update({ status: "concluido" }).eq("id", id)

      if (error) {
        console.error("Erro ao atualizar lembrete:", error)
        toast({
          title: "Erro",
          description: "Não foi possível atualizar o lembrete",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Sucesso",
        description: "Lembrete marcado como concluído!",
      })

      carregarLembretes()
    } catch (error) {
      console.error("Erro:", error)
      toast({
        title: "Erro",
        description: "Erro inesperado ao atualizar lembrete",
        variant: "destructive",
      })
    }
  }

  const lembretesFiltrados = lembretes.filter((lembrete) => {
    const matchSearch =
      lembrete.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lembrete.descricao.toLowerCase().includes(searchTerm.toLowerCase())
    const matchTipo = filterTipo === "todos" || lembrete.tipo === filterTipo
    const matchStatus = filterStatus === "todos" || lembrete.status === filterStatus

    return matchSearch && matchTipo && matchStatus
  })

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "consulta":
        return "bg-blue-100 text-blue-800"
      case "medicamento":
        return "bg-green-100 text-green-800"
      case "exame":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    return status === "concluido" ? (
      <CheckCircle className="h-4 w-4 text-green-600" />
    ) : (
      <AlertCircle className="h-4 w-4 text-orange-600" />
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Carregando lembretes...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Lembretes</h1>
          <p className="text-gray-600">Gerencie seus lembretes e notificações</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Novo Lembrete
        </Button>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-64">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar lembretes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filterTipo}
                onChange={(e) => setFilterTipo(e.target.value)}
                className="px-3 py-2 border rounded-md"
              >
                <option value="todos">Todos os tipos</option>
                <option value="consulta">Consulta</option>
                <option value="medicamento">Medicamento</option>
                <option value="exame">Exame</option>
                <option value="geral">Geral</option>
              </select>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border rounded-md"
              >
                <option value="todos">Todos os status</option>
                <option value="ativo">Ativo</option>
                <option value="concluido">Concluído</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Form de novo lembrete */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Novo Lembrete</CardTitle>
            <CardDescription>Crie um novo lembrete ou notificação</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={criarLembrete} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="titulo">Título</Label>
                  <Input
                    id="titulo"
                    value={formData.titulo}
                    onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="tipo">Tipo</Label>
                  <select
                    id="tipo"
                    value={formData.tipo}
                    onChange={(e) => setFormData({ ...formData, tipo: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="geral">Geral</option>
                    <option value="consulta">Consulta</option>
                    <option value="medicamento">Medicamento</option>
                    <option value="exame">Exame</option>
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="data_lembrete">Data do Lembrete</Label>
                <Input
                  id="data_lembrete"
                  type="datetime-local"
                  value={formData.data_lembrete}
                  onChange={(e) => setFormData({ ...formData, data_lembrete: e.target.value })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit">Criar Lembrete</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Lista de lembretes */}
      <div className="grid gap-4">
        {lembretesFiltrados.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum lembrete encontrado</h3>
              <p className="text-gray-600">
                {searchTerm || filterTipo !== "todos" || filterStatus !== "todos"
                  ? "Tente ajustar os filtros de busca"
                  : "Crie seu primeiro lembrete clicando no botão acima"}
              </p>
            </CardContent>
          </Card>
        ) : (
          lembretesFiltrados.map((lembrete) => (
            <Card key={lembrete.id} className={lembrete.status === "concluido" ? "opacity-75" : ""}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getStatusIcon(lembrete.status)}
                      <h3 className="font-medium text-gray-900">{lembrete.titulo}</h3>
                      <Badge className={getTipoColor(lembrete.tipo)}>{lembrete.tipo}</Badge>
                      {lembrete.status === "concluido" && (
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Concluído
                        </Badge>
                      )}
                    </div>

                    {lembrete.descricao && <p className="text-gray-600 mb-2">{lembrete.descricao}</p>}

                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(lembrete.data_lembrete).toLocaleDateString("pt-BR")}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {new Date(lembrete.data_lembrete).toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>
                      {lembrete.paciente && <span>Paciente: {lembrete.paciente.nome}</span>}
                    </div>
                  </div>

                  {lembrete.status === "ativo" && (
                    <Button size="sm" variant="outline" onClick={() => marcarConcluido(lembrete.id)} className="ml-4">
                      Marcar como concluído
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

// Export nomeado e padrão
export default LembretesView
