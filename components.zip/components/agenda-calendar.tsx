"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, Clock, User, Phone, CheckCircle, XCircle, Calendar, DollarSign, FileText } from "lucide-react"

interface Consulta {
  id: string
  data_hora: string
  data_fim: string | null
  status: string
  status_pagamento: string
  valor: number | null
  observacoes: string | null
  paciente_id: string
  medico_id: string
  clinica_id: string
  pacientes: {
    nome: string
    telefone: string | null
  } | null
  tipos_consulta: {
    nome: string
    cor: string
  } | null
}

interface AgendaCalendarProps {
  consultas: Consulta[]
}

export function AgendaCalendar({ consultas }: AgendaCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null)
  const [selectedDay, setSelectedDay] = useState<Date | null>(null)
  const [isDayModalOpen, setIsDayModalOpen] = useState(false)
  const [selectedConsulta, setSelectedConsulta] = useState<Consulta | null>(null)
  const [isConsultaModalOpen, setIsConsultaModalOpen] = useState(false)
  
  // Debug: log das consultas recebidas
  console.log('AgendaCalendar Debug:', {
    totalConsultas: consultas.length,
    consultas: consultas,
    dataHoje: new Date().toDateString()
  })

  const updateConsultaStatus = async (consultaId: string, newStatus: string) => {
    setUpdatingStatus(consultaId)
    try {
      const response = await fetch('/api/consultas/update-status', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          consultaId,
          status: newStatus
        }),
      })
      
      if (response.ok) {
        // Recarregar a página para atualizar os dados
        window.location.reload()
      } else {
        console.error('Erro ao atualizar status')
      }
    } catch (error) {
      console.error('Erro ao atualizar status:', error)
    } finally {
      setUpdatingStatus(null)
    }
  }

  const openDayModal = (dia: Date) => {
    setSelectedDay(dia)
    setIsDayModalOpen(true)
  }

  const closeDayModal = () => {
    setIsDayModalOpen(false)
    setSelectedDay(null)
  }

  const openConsultaModal = (consulta: Consulta) => {
    setSelectedConsulta(consulta)
    setIsConsultaModalOpen(true)
  }

  const closeConsultaModal = () => {
    setIsConsultaModalOpen(false)
    setSelectedConsulta(null)
  }

  const updatePaymentStatus = async (consultaId: string, newStatus: string) => {
    setUpdatingStatus(consultaId)
    try {
      const response = await fetch('/api/consultas/update-payment-status', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          consultaId,
          status_pagamento: newStatus
        }),
      })
      
      if (response.ok) {
        // Recarregar a página para atualizar os dados
        window.location.reload()
      } else {
        console.error('Erro ao atualizar status de pagamento')
      }
    } catch (error) {
      console.error('Erro ao atualizar status de pagamento:', error)
    } finally {
      setUpdatingStatus(null)
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("pt-BR", {
      month: "long",
      year: "numeric",
    })
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmado":
        return "bg-green-100 text-green-800"
      case "agendado":
        return "bg-blue-100 text-blue-800"
      case "realizado":
        return "bg-gray-100 text-gray-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "pago":
        return "bg-green-100 text-green-800"
      case "pendente":
        return "bg-yellow-100 text-yellow-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }

  // Agrupar consultas por dia
  const consultasPorDia = consultas.reduce(
    (acc, consulta) => {
      const dia = new Date(consulta.data_hora).toDateString()
      if (!acc[dia]) {
        acc[dia] = []
      }
      acc[dia].push(consulta)
      return acc
    },
    {} as Record<string, Consulta[]>,
  )

  // Obter dias do mês atual
  const diasDoMes = []
  const primeiroDia = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
  const ultimoDia = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

  for (let dia = 1; dia <= ultimoDia.getDate(); dia++) {
    diasDoMes.push(new Date(currentDate.getFullYear(), currentDate.getMonth(), dia))
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="capitalize">{formatDate(currentDate)}</CardTitle>
              <CardDescription>Visualização mensal da agenda</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={previousMonth}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={nextMonth}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((dia) => (
              <div key={dia} className="p-2 text-center font-medium text-sm text-muted-foreground">
                {dia}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {/* Dias vazios no início do mês */}
            {Array.from({ length: primeiroDia.getDay() }).map((_, index) => (
              <div key={index} className="p-2 h-24"></div>
            ))}

            {/* Dias do mês */}
            {diasDoMes.map((dia) => {
              const consultasDoDia = consultasPorDia[dia.toDateString()] || []
              const isToday = dia.toDateString() === new Date().toDateString()

              return (
                <div
                  key={dia.toDateString()}
                  className={`p-2 h-24 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors ${
                    isToday ? "bg-blue-50 border-blue-200" : "bg-white border-gray-200"
                  }`}
                  onClick={() => openDayModal(dia)}
                >
                  <div className={`text-sm font-medium ${isToday ? "text-blue-600" : "text-gray-900"}`}>
                    {dia.getDate()}
                  </div>
                  <div className="space-y-1 mt-1">
                    {consultasDoDia.slice(0, 2).map((consulta) => (
                      <div
                        key={consulta.id}
                        className="text-xs p-1 rounded truncate"
                        style={{
                          backgroundColor: consulta.tipos_consulta?.cor + "20" || "#3B82F620",
                          borderLeft: `3px solid ${consulta.tipos_consulta?.cor || "#3B82F6"}`,
                        }}
                      >
                        {formatTime(consulta.data_hora)} - {consulta.pacientes?.nome}
                      </div>
                    ))}
                    {consultasDoDia.length > 2 && (
                      <div className="text-xs text-muted-foreground">+{consultasDoDia.length - 2} mais</div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Lista de consultas do dia atual */}
      <Card>
        <CardHeader>
          <CardTitle>Consultas de Hoje</CardTitle>
          <CardDescription>
            {new Date().toLocaleDateString("pt-BR", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {consultasPorDia[new Date().toDateString()]?.length > 0 ? (
            <div className="space-y-4">
              {consultasPorDia[new Date().toDateString()].map((consulta) => (
                <div key={consulta.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{formatTime(consulta.data_hora)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span>{consulta.pacientes?.nome}</span>
                    </div>
                    {consulta.pacientes?.telefone && (
                      <div className="flex items-center space-x-2">
                        <Phone className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{consulta.pacientes.telefone}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStatusColor(consulta.status)}>{consulta.status}</Badge>
                    <Badge className={getPaymentStatusColor(consulta.status_pagamento)}>
                      {consulta.status_pagamento}
                    </Badge>
                    {consulta.valor && (
                      <span className="text-sm font-medium">
                        {new Intl.NumberFormat("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        }).format(consulta.valor)}
                      </span>
                    )}
                    
                    {/* Botões de ação para consultas agendadas */}
                    {consulta.status === "agendado" && (
                      <div className="flex items-center space-x-1 ml-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 text-green-600 hover:text-green-700"
                          onClick={() => updateConsultaStatus(consulta.id, "concluido")}
                          disabled={updatingStatus === consulta.id}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                          onClick={() => updateConsultaStatus(consulta.id, "cancelado")}
                          disabled={updatingStatus === consulta.id}
                        >
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">Nenhuma consulta agendada para hoje</p>
          )}
        </CardContent>
      </Card>

      {/* Modal de zoom do dia */}
      <Dialog open={isDayModalOpen} onOpenChange={setIsDayModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>
                Consultas de {selectedDay?.toLocaleDateString("pt-BR", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </DialogTitle>
          </DialogHeader>
          
          {selectedDay && (
            <div className="space-y-4">
              {consultasPorDia[selectedDay.toDateString()]?.length > 0 ? (
                consultasPorDia[selectedDay.toDateString()].map((consulta) => (
                  <div 
                    key={consulta.id} 
                    className="flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => openConsultaModal(consulta)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{formatTime(consulta.data_hora)}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span>{consulta.pacientes?.nome}</span>
                      </div>
                      {consulta.pacientes?.telefone && (
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">{consulta.pacientes.telefone}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(consulta.status)}>{consulta.status}</Badge>
                      <Badge className={getPaymentStatusColor(consulta.status_pagamento)}>
                        {consulta.status_pagamento}
                      </Badge>
                      {consulta.valor && (
                        <span className="text-sm font-medium">
                          {new Intl.NumberFormat("pt-BR", {
                            style: "currency",
                            currency: "BRL",
                          }).format(consulta.valor)}
                        </span>
                      )}
                      
                      {/* Botões de ação para consultas agendadas */}
                      {consulta.status === "agendado" && (
                        <div className="flex items-center space-x-1 ml-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 w-8 p-0 text-green-600 hover:text-green-700"
                            onClick={() => updateConsultaStatus(consulta.id, "concluido")}
                            disabled={updatingStatus === consulta.id}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                            onClick={() => updateConsultaStatus(consulta.id, "cancelado")}
                            disabled={updatingStatus === consulta.id}
                          >
                            <XCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  Nenhuma consulta agendada para este dia
                </p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de detalhes da consulta */}
      <Dialog open={isConsultaModalOpen} onOpenChange={setIsConsultaModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5" />
              <span>Detalhes da Consulta</span>
            </DialogTitle>
          </DialogHeader>
          
          {selectedConsulta && (
            <div className="space-y-6">
              {/* Informações principais */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">Horário</span>
                  </div>
                  <p className="text-lg font-semibold">{formatTime(selectedConsulta.data_hora)}</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">Paciente</span>
                  </div>
                  <p className="text-lg font-semibold">{selectedConsulta.pacientes?.nome}</p>
                </div>
              </div>

              {/* Status da consulta */}
              <div className="space-y-2">
                <span className="font-medium">Status da Consulta</span>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(selectedConsulta.status)}>
                    {selectedConsulta.status}
                  </Badge>
                  
                  {/* Botões de ação para status */}
                  {selectedConsulta.status === "agendado" && (
                    <div className="flex items-center space-x-1 ml-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 px-3 text-green-600 hover:text-green-700"
                        onClick={() => updateConsultaStatus(selectedConsulta.id, "concluido")}
                        disabled={updatingStatus === selectedConsulta.id}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Concluído
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 px-3 text-red-600 hover:text-red-700"
                        onClick={() => updateConsultaStatus(selectedConsulta.id, "cancelado")}
                        disabled={updatingStatus === selectedConsulta.id}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Cancelar
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Status de pagamento */}
              <div className="space-y-2">
                <span className="font-medium">Status de Pagamento</span>
                <div className="flex items-center space-x-2">
                  <Badge className={getPaymentStatusColor(selectedConsulta.status_pagamento)}>
                    {selectedConsulta.status_pagamento}
                  </Badge>
                  
                  {/* Botões de ação para pagamento */}
                  {selectedConsulta.status_pagamento === "pendente" && (
                    <div className="flex items-center space-x-1 ml-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 px-3 text-green-600 hover:text-green-700"
                        onClick={() => updatePaymentStatus(selectedConsulta.id, "pago")}
                        disabled={updatingStatus === selectedConsulta.id}
                      >
                        <DollarSign className="h-4 w-4 mr-1" />
                        Marcar como Pago
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Valor */}
              {selectedConsulta.valor && (
                <div className="space-y-2">
                  <span className="font-medium">Valor</span>
                  <p className="text-2xl font-bold text-green-600">
                    {new Intl.NumberFormat("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    }).format(selectedConsulta.valor)}
                  </p>
                </div>
              )}

              {/* Observações */}
              {selectedConsulta.observacoes && (
                <div className="space-y-2">
                  <span className="font-medium">Observações</span>
                  <p className="text-sm text-muted-foreground bg-gray-50 p-3 rounded">
                    {selectedConsulta.observacoes}
                  </p>
                </div>
              )}

              {/* Telefone do paciente */}
              {selectedConsulta.pacientes?.telefone && (
                <div className="space-y-2">
                  <span className="font-medium">Telefone</span>
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span>{selectedConsulta.pacientes.telefone}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
