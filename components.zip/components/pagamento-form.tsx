"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, CreditCard, Shield, Star } from "lucide-react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { useRouter } from "next/navigation"

export function PagamentoForm() {
  const [loading, setLoading] = useState(false)
  const supabase = createClientComponentClient()
  const router = useRouter()

  const handlePayment = async () => {
    try {
      setLoading(true)

      // Verificar se usuário está logado
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/login")
        return
      }

      // Criar pagamento
      const response = await fetch("/api/create-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId: user.id }),
      })

      const data = await response.json()

      if (data.initPoint) {
        // Redirecionar para o Mercado Pago
        window.location.href = data.initPoint
      } else {
        alert("Erro ao processar pagamento. Tente novamente.")
      }
    } catch (error) {
      console.error("Erro:", error)
      alert("Erro ao processar pagamento. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  const beneficios = [
    "Pacientes ilimitados",
    "Usuários ilimitados",
    "Armazenamento ilimitado",
    "Backup automático diário",
    "Atualizações automáticas",
    "Suporte por email",
    "Treinamento incluído",
    "Sem taxa de setup",
  ]

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="border-2 border-blue-200 shadow-xl">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white text-center p-8">
          <div className="flex justify-center mb-4">
            <Badge className="bg-yellow-500 text-yellow-900 px-3 py-1">
              <Star className="w-4 h-4 mr-1" />
              OFERTA ESPECIAL
            </Badge>
          </div>

          <CardTitle className="text-3xl font-bold mb-2">Plano MedFlux</CardTitle>
          <CardDescription className="text-blue-100 text-lg mb-6">Sistema completo de gestão médica</CardDescription>

          <div className="space-y-2">
            <div className="flex items-baseline justify-center gap-2">
              <span className="text-5xl font-bold">R$ 99</span>
              <span className="text-blue-100 text-xl">/mês</span>
            </div>
            <p className="text-blue-100">Sem fidelidade • Cancele quando quiser</p>
          </div>
        </CardHeader>

        <CardContent className="p-8">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">✅ Tudo incluído:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {beneficios.map((beneficio, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700 text-sm">{beneficio}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <div className="flex items-center gap-2 text-green-800 mb-2">
                <Shield className="h-5 w-5" />
                <span className="font-semibold">Pagamento 100% Seguro</span>
              </div>
              <p className="text-green-700 text-sm">
                Processado pelo Mercado Pago com criptografia SSL. Seus dados estão protegidos.
              </p>
            </div>

            <Button
              onClick={handlePayment}
              disabled={loading}
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 text-lg font-semibold"
            >
              <CreditCard className="w-5 h-5 mr-2" />
              {loading ? "Processando..." : "Pagar R$ 99,00/mês"}
            </Button>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-500">
                ✅ Teste grátis por 30 dias • ✅ Sem cartão de crédito inicialmente
              </p>
              <p className="text-xs text-gray-400">
                Ao continuar, você concorda com nossos Termos de Uso e Política de Privacidade
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
