"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import { Plus, Trash2, FileText, Download } from "lucide-react"

interface Medicamento {
  nome: string
  dosagem: string
  frequencia: string
  duracao: string
  observacoes?: string
}

interface ModeloPrescricao {
  id: string
  nome: string
  medicamentos: Medicamento[]
  orientacoes: string
}

interface PrescricaoDigitalProps {
  prontuarioId: string
  pacienteId: string
  medicoId: string
  clinicaId: string
  onSave?: () => void
}

export function PrescricaoDigital({ prontuarioId, pacienteId, medicoId, clinicaId, onSave }: PrescricaoDigitalProps) {
  const [medicamentos, setMedicamentos] = useState<Medicamento[]>([
    { nome: "", dosagem: "", frequencia: "", duracao: "", observacoes: "" },
  ])
  const [orientacoes, setOrientacoes] = useState("")
  const [validadeDias, setValidadeDias] = useState(30)
  const [modelos, setModelos] = useState<ModeloPrescricao[]>([])
  const [loading, setLoading] = useState(false)
  const [showModelos, setShowModelos] = useState(false)

  const { toast } = useToast()
  const supabase = createClient()

  useEffect(() => {
    carregarModelos()
  }, [])

  const carregarModelos = async () => {
    try {
      const { data, error } = await supabase
        .from("modelos_prescricao")
        .select("*")
        .eq("medico_id", medicoId)
        .eq("ativo", true)
        .order("nome")

      if (error) throw error
      setModelos(data || [])
    } catch (error) {
      console.error("Erro ao carregar modelos:", error)
    }
  }

  const adicionarMedicamento = () => {
    setMedicamentos([...medicamentos, { nome: "", dosagem: "", frequencia: "", duracao: "", observacoes: "" }])
  }

  const removerMedicamento = (index: number) => {
    setMedicamentos(medicamentos.filter((_, i) => i !== index))
  }

  const atualizarMedicamento = (index: number, campo: keyof Medicamento, valor: string) => {
    const novosMedicamentos = [...medicamentos]
    novosMedicamentos[index] = { ...novosMedicamentos[index], [campo]: valor }
    setMedicamentos(novosMedicamentos)
  }

  const aplicarModelo = (modelo: ModeloPrescricao) => {
    setMedicamentos(modelo.medicamentos)
    setOrientacoes(modelo.orientacoes)
    setShowModelos(false)
    toast({
      title: "Modelo aplicado!",
      description: `Modelo "${modelo.nome}" foi aplicado à prescrição.`,
    })
  }

  const salvarComoModelo = async () => {
    const nome = prompt("Nome do modelo:")
    if (!nome) return

    try {
      const { error } = await supabase.from("modelos_prescricao").insert({
        medico_id: medicoId,
        clinica_id: clinicaId,
        nome,
        medicamentos,
        orientacoes,
      })

      if (error) throw error

      toast({
        title: "Modelo salvo!",
        description: "O modelo de prescrição foi salvo com sucesso.",
      })

      carregarModelos()
    } catch (error) {
      console.error("Erro ao salvar modelo:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar o modelo.",
        variant: "destructive",
      })
    }
  }

  const salvarPrescricao = async () => {
    if (medicamentos.every((med) => !med.nome.trim())) {
      toast({
        title: "Erro",
        description: "Adicione pelo menos um medicamento.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const { error } = await supabase.from("prescricoes").insert({
        prontuario_id: prontuarioId,
        paciente_id: pacienteId,
        medico_id: medicoId,
        clinica_id: clinicaId,
        medicamentos: medicamentos.filter((med) => med.nome.trim()),
        orientacoes,
        validade_dias: validadeDias,
      })

      if (error) throw error

      toast({
        title: "Prescrição salva!",
        description: "A prescrição foi salva com sucesso.",
      })

      if (onSave) onSave()
    } catch (error) {
      console.error("Erro ao salvar prescrição:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar a prescrição.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const gerarPDF = () => {
    // Implementar geração de PDF
    toast({
      title: "Em desenvolvimento",
      description: "A geração de PDF será implementada em breve.",
    })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5" />
              <span>Prescrição Digital</span>
            </CardTitle>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={() => setShowModelos(!showModelos)}>
                Modelos
              </Button>
              <Button variant="outline" size="sm" onClick={salvarComoModelo}>
                Salvar como Modelo
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Modelos */}
          {showModelos && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Modelos Salvos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  {modelos.map((modelo) => (
                    <div key={modelo.id} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <h4 className="font-medium">{modelo.nome}</h4>
                        <p className="text-sm text-gray-500">{modelo.medicamentos.length} medicamento(s)</p>
                      </div>
                      <Button size="sm" onClick={() => aplicarModelo(modelo)}>
                        Aplicar
                      </Button>
                    </div>
                  ))}
                  {modelos.length === 0 && <p className="text-gray-500 text-center py-4">Nenhum modelo salvo</p>}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Medicamentos */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <Label className="text-lg font-medium">Medicamentos</Label>
              <Button size="sm" onClick={adicionarMedicamento}>
                <Plus className="w-4 h-4 mr-2" />
                Adicionar
              </Button>
            </div>

            <div className="space-y-4">
              {medicamentos.map((medicamento, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-4">
                      <h4 className="font-medium">Medicamento {index + 1}</h4>
                      {medicamentos.length > 1 && (
                        <Button variant="ghost" size="sm" onClick={() => removerMedicamento(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <Label htmlFor={`nome-${index}`}>Nome do Medicamento</Label>
                        <Input
                          id={`nome-${index}`}
                          value={medicamento.nome}
                          onChange={(e) => atualizarMedicamento(index, "nome", e.target.value)}
                          placeholder="Ex: Dipirona"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`dosagem-${index}`}>Dosagem</Label>
                        <Input
                          id={`dosagem-${index}`}
                          value={medicamento.dosagem}
                          onChange={(e) => atualizarMedicamento(index, "dosagem", e.target.value)}
                          placeholder="Ex: 500mg"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`frequencia-${index}`}>Frequência</Label>
                        <Input
                          id={`frequencia-${index}`}
                          value={medicamento.frequencia}
                          onChange={(e) => atualizarMedicamento(index, "frequencia", e.target.value)}
                          placeholder="Ex: 3x ao dia"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`duracao-${index}`}>Duração</Label>
                        <Input
                          id={`duracao-${index}`}
                          value={medicamento.duracao}
                          onChange={(e) => atualizarMedicamento(index, "duracao", e.target.value)}
                          placeholder="Ex: 7 dias"
                        />
                      </div>
                    </div>

                    <div className="mt-4">
                      <Label htmlFor={`observacoes-${index}`}>Observações</Label>
                      <Textarea
                        id={`observacoes-${index}`}
                        value={medicamento.observacoes}
                        onChange={(e) => atualizarMedicamento(index, "observacoes", e.target.value)}
                        placeholder="Observações específicas sobre este medicamento..."
                        rows={2}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Orientações Gerais */}
          <div>
            <Label htmlFor="orientacoes">Orientações Gerais</Label>
            <Textarea
              id="orientacoes"
              value={orientacoes}
              onChange={(e) => setOrientacoes(e.target.value)}
              placeholder="Orientações gerais para o paciente..."
              rows={4}
            />
          </div>

          {/* Validade */}
          <div>
            <Label htmlFor="validade">Validade da Prescrição (dias)</Label>
            <Select value={validadeDias.toString()} onValueChange={(value) => setValidadeDias(Number.parseInt(value))}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 dias</SelectItem>
                <SelectItem value="30">30 dias</SelectItem>
                <SelectItem value="60">60 dias</SelectItem>
                <SelectItem value="90">90 dias</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Ações */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={gerarPDF}>
              <Download className="w-4 h-4 mr-2" />
              Gerar PDF
            </Button>
            <Button onClick={salvarPrescricao} disabled={loading}>
              {loading ? "Salvando..." : "Salvar Prescrição"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
