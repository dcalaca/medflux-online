"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { 
  Users, 
  UserPlus, 
  UserCheck, 
  UserX, 
  Mail,
  Calendar,
  Shield,
  Stethoscope,
  User,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Building,
  Check,
  ChevronsUpDown,
  Phone,
  Edit,
  Trash2,
  MoreHorizontal
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog"

interface Clinica {
  id: string
  nome: string
}

interface Usuario {
  id: string
  nome: string
  email: string
  tipo: string
  status_conta?: string
  dias_teste_restantes?: number
  data_inicio_teste?: string
  created_at: string
  telefone?: string
  clinica_id?: string
  clinica?: Clinica
  especialidade?: string
  crm?: string
}

interface UsuariosViewProps {
  usuarios: Usuario[]
}

export function UsuariosView({ usuarios }: UsuariosViewProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [tipoFilter, setTipoFilter] = useState("todos")
  const [openTipo, setOpenTipo] = useState(false)
  const [loading, setLoading] = useState(false)
  const [usuariosList, setUsuariosList] = useState(usuarios)

  const filtrarUsuarios = () => {
    let filtrados = usuariosList

    // Filtro por busca
    if (searchTerm) {
      filtrados = filtrados.filter(usuario =>
        usuario.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        usuario.email?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filtro por tipo
    if (tipoFilter !== "todos") {
      filtrados = filtrados.filter(usuario => usuario.tipo === tipoFilter)
    }

    return filtrados
  }

  const exportarRelatorio = () => {
    const dados = filtrarUsuarios()
    const csvContent = [
      ["Nome", "Email", "Tipo", "Telefone", "Especialidade", "CRM", "Data Cadastro"],
      ...dados.map(usuario => [
        usuario.nome,
        usuario.email,
        usuario.tipo,
        usuario.telefone || "",
        usuario.especialidade || "",
        usuario.crm || "",
        format(new Date(usuario.created_at), "dd/MM/yyyy", { locale: ptBR })
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `usuarios-clinica-${format(new Date(), "dd-MM-yyyy")}.csv`
    a.click()
  }

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "admin": return <Shield className="h-4 w-4" />
      case "medico": return <Stethoscope className="h-4 w-4" />
      case "recepcionista": return <User className="h-4 w-4" />
      default: return <User className="h-4 w-4" />
    }
  }

  const getTipoLabel = (tipo: string) => {
    switch (tipo) {
      case "admin": return "Administrador"
      case "medico": return "Médico"
      case "recepcionista": return "Recepcionista"
      default: return tipo
    }
  }

  const handleEditarUsuario = (usuario: Usuario) => {
    // Por enquanto apenas um alerta, pode ser expandido para abrir um modal
    alert(`Editar usuário: ${usuario.nome}`)
  }

  const handleExcluirUsuario = async (usuario: Usuario) => {
    setLoading(true)
    try {
      const response = await fetch("/api/excluir-usuario", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: usuario.id }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao excluir usuário")
      }

      // Remover o usuário da lista local
      setUsuariosList(prev => prev.filter(u => u.id !== usuario.id))
      
      // Mostrar mensagem de sucesso
      alert(`Usuário ${usuario.nome} excluído com sucesso!`)
    } catch (error) {
      console.error("Erro ao excluir usuário:", error)
      alert(`Erro ao excluir usuário: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    } finally {
      setLoading(false)
    }
  }

  const tipos = [
    { value: "todos", label: "Todos os tipos", description: undefined },
    { value: "medico", label: "Médicos", icon: <Stethoscope className="h-4 w-4" />, description: undefined },
    { value: "recepcionista", label: "Recepcionistas", icon: <User className="h-4 w-4" />, description: undefined }
  ]

  const usuariosFiltrados = filtrarUsuarios()

  const stats = {
    totalUsuarios: usuariosList.length,
    medicos: usuariosList.filter(u => u.tipo === "medico").length,
    recepcionistas: usuariosList.filter(u => u.tipo === "recepcionista").length,
    usuariosAtivos: usuariosList.filter(u => u.status_conta === "assinante").length
  }

  return (
    <div className="space-y-8 px-2 sm:px-0">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Equipe da Clínica</h1>
        <p className="text-gray-600 mt-2">Gerencie os usuários da sua clínica</p>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-full">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsuarios}</div>
            <p className="text-xs text-muted-foreground">Equipe da clínica</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Médicos</CardTitle>
            <Stethoscope className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.medicos}</div>
            <p className="text-xs text-muted-foreground">Profissionais</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recepcionistas</CardTitle>
            <User className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.recepcionistas}</div>
            <p className="text-xs text-muted-foreground">Funcionários</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários Ativos</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.usuariosAtivos}</div>
            <p className="text-xs text-muted-foreground">Assinantes</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros e Ações</CardTitle>
          <CardDescription>Filtre e gerencie usuários da clínica</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por nome ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            {/* Filtro por Tipo */}
            <div className="w-full md:w-48">
              <Popover open={openTipo} onOpenChange={setOpenTipo}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openTipo}
                    className="w-full justify-between"
                  >
                    {tipos.find(tipo => tipo.value === tipoFilter)?.label || "Selecione tipo..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-48 p-0">
                  <Command>
                    <CommandInput placeholder="Buscar tipo..." />
                    <CommandList>
                      <CommandEmpty>Nenhum tipo encontrado.</CommandEmpty>
                      <CommandGroup>
                        {tipos.map((tipo) => (
                          <CommandItem
                            key={tipo.value}
                            value={tipo.label}
                            onSelect={() => {
                              setTipoFilter(tipo.value)
                              setOpenTipo(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                tipoFilter === tipo.value ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {tipo.icon && <span className="mr-2">{tipo.icon}</span>}
                            {tipo.label}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            <Button onClick={exportarRelatorio} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Exportar CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Usuários */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Usuários</CardTitle>
          <CardDescription>
            {usuariosFiltrados.length} usuário(s) encontrado(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto w-full max-w-full">
            <Table className="min-w-[600px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Especialidade</TableHead>
                  <TableHead>Data Cadastro</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {usuariosFiltrados.map((usuario) => (
                  <TableRow key={usuario.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{usuario.nome}</div>
                        <div className="text-sm text-gray-500 flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {usuario.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getTipoIcon(usuario.tipo)}
                        <Badge variant="outline">
                          {getTipoLabel(usuario.tipo)}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      {usuario.telefone ? (
                        <div className="flex items-center gap-1">
                          <Phone className="h-3 w-3 text-gray-400" />
                          {usuario.telefone}
                        </div>
                      ) : (
                        <span className="text-gray-400 text-sm">Não informado</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {usuario.especialidade ? (
                        <span className="text-sm">{usuario.especialidade}</span>
                      ) : (
                        <span className="text-gray-400 text-sm">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-gray-400" />
                        {format(new Date(usuario.created_at), "dd/MM/yyyy", { locale: ptBR })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEditarUsuario(usuario)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Excluir
                              </DropdownMenuItem>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Tem certeza que deseja excluir o usuário <strong>{usuario.nome}</strong>?
                                  Esta ação não pode ser desfeita.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => handleExcluirUsuario(usuario)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Excluir
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 