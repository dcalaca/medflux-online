import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Users, DollarSign, Clock, Plus } from "lucide-react"
import Link from "next/link"

export const dynamic = "force-dynamic"

export default async function DashboardPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*", { head: false }).eq("id", user.id as any).single()

  if (usuarioError || !usuario || ((usuario as any).tipo !== "admin" && (usuario as any).tipo !== "medico" && (usuario as any).tipo !== "recepcionista")) {
    redirect("/dashboard")
  }

  const usuarioData = usuario as any;

  // Calcular dias restantes do teste gratuito
  let diasRestantes = null
  let expirado = false
  if (usuarioData.data_inicio_teste) {
    const inicio = new Date(usuarioData.data_inicio_teste)
    const hoje = new Date()
    const diffMs = hoje.getTime() - inicio.getTime()
    const diffDias = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    diasRestantes = 30 - diffDias
    if (diasRestantes < 0) diasRestantes = 0
    expirado = diasRestantes === 0
  }

  // Data de hoje
  const hoje = new Date()
  const hojeString = hoje.toISOString().split("T")[0]

  // Início do mês atual
  const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString()

  // Buscar consultas futuras (apenas próximas consultas agendadas)
  const agora = new Date().toISOString()
  const { data: consultasHoje } = await supabase
    .from("consultas")
    .select("*")
    .eq("medico_id", user.id as any)
    .eq("clinica_id", usuarioData.clinica_id)
    .eq("status", "agendado" as any)
    .gte("data_hora", agora)
    .order("data_hora", { ascending: true })

  // Buscar total de pacientes
  const { data: totalPacientes } = await supabase.from("pacientes").select("id").eq("clinica_id", usuarioData.clinica_id)

  // Buscar pacientes novos este mês
  const { data: pacientesNovosMes } = await supabase
    .from("pacientes")
    .select("id")
    .eq("clinica_id", usuarioData.clinica_id)
    .gte("created_at", inicioMes)

  // Buscar faturamento do mês (consultas pagas)
  const { data: consultasPagas } = await supabase
    .from("consultas")
    .select("valor")
    .eq("medico_id", user.id as any) // ✅ Corrigido: usar medico_id
    .eq("clinica_id", usuarioData.clinica_id)
    .eq("status_pagamento", "pago" as any)
    .gte("data_hora", inicioMes)

  // Buscar pagamentos pendentes
  const { data: pagamentosPendentes } = await supabase
    .from("consultas")
    .select("id")
    .eq("medico_id", user.id as any) // ✅ Corrigido: usar medico_id
    .eq("clinica_id", usuarioData.clinica_id)
    .eq("status_pagamento", "pendente" as any)

  // Calcular valores
  const consultasHojeCount = consultasHoje?.length || 0
  
  // Debug: log das consultas encontradas
  console.log('Debug - Consultas hoje:', {
    total: consultasHojeCount,
    consultas: consultasHoje,
    dataHoje: hojeString,
    medicoId: user.id,
    clinicaId: usuarioData.clinica_id
  })
  const totalPacientesCount = totalPacientes?.length || 0
  const pacientesNovosMesCount = pacientesNovosMes?.length || 0
  const faturamentoMes = consultasPagas?.reduce((total, consulta) => total + ((consulta as any).valor || 0), 0) || 0
  const pagamentosPendentesCount = pagamentosPendentes?.length || 0

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Banner de teste gratuito */}
        {diasRestantes !== null && (
          <div className={`rounded-lg border border-blue-200 bg-blue-50 px-6 py-4 flex items-center justify-between ${expirado ? 'opacity-80' : ''}`}> 
            <div>
              <span className="inline-flex items-center gap-2 text-blue-900 font-medium">
                <span className="inline-block bg-blue-100 rounded-full p-2 mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="#2563eb" strokeWidth="2"/><path d="M12 8v4l2 2" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </span>
                {expirado ? (
                  <b>Período de teste expirado</b>
                ) : (
                  <>
                    Período de teste <b>{diasRestantes} {diasRestantes === 1 ? 'dia restante' : 'dias restantes'}</b>
                  </>
                )}
              </span>
              <div className="text-xs text-blue-900 mt-1">
                {expirado ? (
                  <>Seu teste gratuito terminou. Para continuar usando o MedFlux, escolha um plano abaixo.</>
                ) : (
                  <>Aproveite todos os recursos do MedFlux gratuitamente.</>
                )}
              </div>
            </div>
            <Button asChild className="ml-4" variant="outline" size="sm">
              <Link href="/planos">{expirado ? 'Assinar Plano' : 'Ver Planos'}</Link>
            </Button>
          </div>
        )}
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground text-sm sm:text-base">
              Bem-vindo de volta, Dr. {(usuario as any).nome} 
              <span className="text-xs sm:text-sm text-gray-500 ml-2">
                ({(usuario as any).email} - {(usuario as any).tipo})
              </span>
              {!(usuario as any).clinica_id && (
                <span className="text-xs sm:text-sm text-red-500 ml-2">
                  ⚠️ Sem clínica associada
                </span>
              )}
            </p>
          </div>
          <Button asChild className="w-full sm:w-auto">
            <Link href="/pacientes/novo">
              <Plus className="w-4 h-4 mr-2" />
              Novo Paciente
            </Link>
          </Button>
        </div>

        {/* Cards de estatísticas */}
        <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                          <CardTitle className="text-sm font-medium">Próximas Consultas</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{consultasHojeCount}</div>
            <p className="text-xs text-muted-foreground">
              {consultasHojeCount === 0 ? "Nenhuma consulta agendada" : `${consultasHojeCount} próximas consultas`}
            </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Pacientes</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalPacientesCount}</div>
              <p className="text-xs text-muted-foreground">{pacientesNovosMesCount} novos este mês</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Faturamento</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Intl.NumberFormat("pt-BR", {
                  style: "currency",
                  currency: "BRL",
                }).format(faturamentoMes)}
              </div>
              <p className="text-xs text-muted-foreground">Este mês</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pagamentosPendentesCount}</div>
              <p className="text-xs text-muted-foreground">Pagamentos pendentes</p>
            </CardContent>
          </Card>
        </div>

        {/* Cards de boas-vindas e próximos passos */}
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Bem-vindo ao MedFlux!</CardTitle>
              <p className="text-sm text-muted-foreground">Sistema de gestão clínica completo</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm">
                Seu sistema está configurado e pronto para uso. Comece cadastrando seus primeiros pacientes.
              </p>
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                <Button asChild className="w-full sm:w-auto">
                  <Link href="/pacientes/novo">Cadastrar Paciente</Link>
                </Button>
                <Button variant="outline" asChild className="w-full sm:w-auto">
                  <Link href="/agenda">Ver Agenda</Link>
                </Button>
                <Button variant="outline" asChild className="w-full sm:w-auto">
                  <Link href="/cadastrar-recepcionista">Cadastrar Recepcionista</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Próximos Passos</CardTitle>
              <p className="text-sm text-muted-foreground">Configure seu sistema</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm">Conta criada</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm">Login funcionando</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                <span className="text-sm">Cadastrar primeiro paciente</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                <span className="text-sm">Configurar agenda</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
