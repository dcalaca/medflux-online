import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { EspecialidadesView } from "@/components/especialidades-view"

export const dynamic = "force-dynamic"

export default async function EspecialidadesPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", String(user.id)).single()
  const usuarioData = usuario as any;
  if (!usuarioData || (usuarioData.tipo !== "admin" && usuarioData.tipo !== "medico")) {
    redirect("/dashboard")
  }

  // Buscar especialidades
  const { data: especialidades } = await supabase.from("especialidades").select("*").order("nome")

  return (
    <DashboardLayout>
      <EspecialidadesView especialidades={Array.isArray(especialidades) ? especialidades : []} />
    </DashboardLayout>
  )
}
