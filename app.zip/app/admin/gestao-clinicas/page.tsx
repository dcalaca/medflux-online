import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import GestaoClinicasView from "@/components/gestao-clinicas-view"

export default async function GestaoClinicasPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect("/login")
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", String(user.id)).single()
  if (usuarioError || !usuario || (usuario as any).tipo !== "admin") redirect("/dashboard")
  
  return (
    <DashboardLayout>
      <GestaoClinicasView />
    </DashboardLayout>
  )
} 