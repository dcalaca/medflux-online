import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import AdminView from "@/components/admin-view"

export default async function AdminPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect("/login")
  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", String(user.id)).single()
  if (!usuario || usuario.tipo !== "admin") redirect("/dashboard")
  return (
    <DashboardLayout>
      <AdminView />
    </DashboardLayout>
  )
}
