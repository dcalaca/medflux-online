import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import CadastroUsuariosWrapper from "@/components/cadastro-usuarios-wrapper"

export const dynamic = "force-dynamic"

export default async function CadastroUsuariosPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  return (
    <DashboardLayout>
      <CadastroUsuariosWrapper />
    </DashboardLayout>
  )
} 
