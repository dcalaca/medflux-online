import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { ConveniosView } from "@/components/convenios-view"

export default async function ConveniosPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect("/login")
  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", String(user.id)).single()
  if (!usuario || (usuario.tipo !== "admin" && usuario.tipo !== "medico")) redirect("/dashboard")
  // Buscar convênios
  const { data: convenios } = await supabase.from("convenios").select("*").order("nome")
  // Buscar estatísticas de uso (consultas por convênio)
  const { data: consultasConvenio } = await supabase
    .from("consultas")
    .select("convenio_id, convenios(nome)")
    .not("convenio_id", "is", null)
  return (
    <DashboardLayout>
      <ConveniosView convenios={convenios || []} consultasConvenio={consultasConvenio || []} />
    </DashboardLayout>
  )
}
