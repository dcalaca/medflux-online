import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { ConveniosView } from "@/components/convenios-view"

export default async function ConveniosPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (usuarioError || !usuario || (usuario as any).tipo !== "medico") {
    redirect("/dashboard")
  }

  // Buscar convênios
  const { data: convenios } = await supabase.from("convenios").select("*").order("nome")

  // Buscar consultas com convênios para estatísticas
  const { data: consultasConvenio } = await supabase
    .from("consultas")
    .select("convenio_id, convenios(nome)")
    .not("convenio_id", "is", null)

  return (
    <DashboardLayout>
      <ConveniosView convenios={(convenios as any) || []} consultasConvenio={(consultasConvenio as any) || []} />
    </DashboardLayout>
  )
} 