import { createServerClient } from "@/lib/supabase/server"
import { redirect, notFound } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { DetalhePacienteView } from "@/components/detalhe-paciente-view"

export const dynamic = "force-dynamic"

interface PageProps {
  params: Promise<{
    id: string
  }>
}

export default async function PacienteDetalhePage({ params }: PageProps) {
  const { id } = await params
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (usuarioError || !usuario) {
    redirect("/login")
  }

  // Buscar dados do paciente
  const { data: paciente, error: pacienteError } = await supabase
    .from("pacientes")
    .select("*")
    .eq("id", id)
    .eq("clinica_id", usuario.clinica_id) // ✅ usa a clínica do usuário
    .single()

  if (pacienteError || !paciente) {
    notFound()
  }

  // Buscar consultas do paciente
  const { data: consultas } = await supabase
    .from("consultas")
    .select(`
    *,
    tipos_consulta(nome, cor, valor_padrao)
  `)
    .eq("paciente_id", id)
    .eq("clinica_id", usuario.clinica_id) // ✅ mesma clínica
    .order("data_hora", { ascending: false })

  // Buscar tipos de consulta disponíveis
  const { data: tiposConsulta } = await supabase
    .from("tipos_consulta")
    .select("*")
    .eq("medico_id", user.id)
    .eq("clinica_id", usuario.clinica_id) // ✅ mesma clínica
    .order("nome")

  return (
    <DashboardLayout>
      <DetalhePacienteView
        paciente={paciente}
        consultas={consultas || []}
        tiposConsulta={tiposConsulta || []}
        usuario={usuario}
      />
    </DashboardLayout>
  )
}
