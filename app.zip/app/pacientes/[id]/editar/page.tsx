import { createServerClient } from "@/lib/supabase/server"
import { redirect, notFound } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { EditarPacienteForm } from "@/components/editar-paciente-form"

interface EditarPacientePageProps {
  params: {
    id: string
  }
}

export default async function EditarPacientePage({ params }: EditarPacientePageProps) {
  const supabase = createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (!usuario || (usuario.tipo !== "medico" && usuario.tipo !== "recepcionista")) {
    redirect("/dashboard")
  }

  // Buscar dados do paciente
  const { data: paciente, error } = await supabase
    .from("pacientes")
    .select("*")
    .eq("id", params.id)
    .eq("clinica_id", usuario.clinica_id)
    .single()

  if (error || !paciente) {
    notFound()
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Editar Paciente</h1>
          <p className="text-muted-foreground">Atualize os dados do paciente</p>
        </div>

        <EditarPacienteForm paciente={paciente} usuario={usuario} />
      </div>
    </DashboardLayout>
  )
}
