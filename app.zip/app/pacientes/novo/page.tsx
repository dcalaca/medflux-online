import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { NovoPacienteForm } from "@/components/novo-paciente-form"

export default async function NovoPacientePage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  const usuarioData = usuario as any;

  if (usuarioError || !usuarioData || (usuarioData.tipo !== "medico" && usuarioData.tipo !== "atendente" && usuarioData.tipo !== "admin")) {
    redirect("/dashboard")
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 pb-8 content-safe">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Novo Paciente</h1>
          <p className="text-muted-foreground">Cadastre um novo paciente no sistema</p>
        </div>

        <NovoPacienteForm usuario={usuarioData} />
      </div>
    </DashboardLayout>
  )
}
