import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { PacientesTable } from "@/components/pacientes-table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Search } from "lucide-react"
import Link from "next/link"

export default async function PacientesPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (!usuario || (usuario.tipo !== "admin" && usuario.tipo !== "medico" && usuario.tipo !== "recepcionista")) {
    redirect("/dashboard")
  }

  const { data: pacientes } = await supabase
    .from("pacientes")
    .select("*")
    .eq("clinica_id", usuario.clinica_id)
    .order("created_at", { ascending: false })

  return (
    <DashboardLayout>
      <div className="space-y-4 md:space-y-6">
        {/* Header - Responsivo */}
        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Pacientes</h1>
            <p className="text-sm md:text-base text-muted-foreground">Gerencie todos os pacientes da clínica</p>
          </div>
          <Button asChild className="w-full md:w-auto">
            <Link href="/pacientes/novo">
              <Plus className="w-4 h-4 mr-2" />
              Novo Paciente
            </Link>
          </Button>
        </div>

        {/* Search - Responsivo */}
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Buscar pacientes..." className="pl-10 h-10 md:h-9" />
          </div>
        </div>

        {/* Tabela */}
        <PacientesTable pacientes={pacientes || []} />
      </div>
    </DashboardLayout>
  )
}
