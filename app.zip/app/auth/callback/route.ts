import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    try {
      await supabase.auth.exchangeCodeForSession(code)

      // Redirecionar para login com sucesso
      return NextResponse.redirect(new URL("/login?confirmed=true", request.url))
    } catch (error) {
      console.error("Erro na confirmação:", error)
      return NextResponse.redirect(new URL("/login?error=confirmation_failed", request.url))
    }
  }

  // Redirecionar para login se não houver código
  return NextResponse.redirect(new URL("/login", request.url))
}
