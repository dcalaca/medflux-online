import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { UsuariosView } from "@/components/usuarios-view"

export default async function UsuariosPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (usuarioError || !usuario || (usuario as any).tipo !== "medico") {
    redirect("/dashboard")
  }

  const usuarioData = usuario as any

  // Buscar usuários da mesma clínica (recepcionistas e outros médicos)
  const { data: usuarios } = await supabase
    .from("usuarios")
    .select(`
      *,
      clinica:clinicas(id, nome)
    `)
    .eq("clinica_id", usuarioData.clinica_id)
    .neq("id", user.id) // Não mostrar o próprio usuário
    .order("created_at", { ascending: false })

  return (
    <DashboardLayout>
      <UsuariosView usuarios={usuarios || []} />
    </DashboardLayout>
  )
} 