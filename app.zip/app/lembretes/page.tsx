import { TrialGuard } from "@/components/trial-guard"
import DashboardLayout from "@/components/dashboard-layout"
import { LembretesView } from "@/components/lembretes-view"

export default function LembretesPage() {
  return (
    <TrialGuard>
      <DashboardLayout>
        <LembretesView />
      </DashboardLayout>
    </TrialGuard>
  )
}
