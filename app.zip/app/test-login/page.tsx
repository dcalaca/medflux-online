"use client"

export const dynamic = "force-dynamic"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestLoginPage() {
  const [email, setEmail] = useState("dcalaca@gmail.com")
  const [password, setPassword] = useState("")
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const testLogin = async () => {
    setLoading(true)
    setResult(null)
    const supabase = createClient()

    try {
      console.log("🧪 TESTE DE LOGIN INICIADO")

      // Teste 1: Verificar conexão com Supabase
      console.log("1️⃣ Testando conexão com Supabase...")
      const { data: testConnection } = await supabase.from("usuarios").select("count").limit(1)
      console.log("✅ Conexão OK:", testConnection)

      // Teste 2: Tentar login
      console.log("2️⃣ Tentando fazer login...")
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      console.log("📊 Resultado do auth:", { authData, authError })

      if (authError) {
        setResult({ error: authError.message, step: "auth" })
        return
      }

      // Teste 3: Buscar perfil
      console.log("3️⃣ Buscando perfil do usuário...")
      const { data: userData, error: userError } = await supabase
        .from("usuarios")
        .select("*")
        .eq("id", authData.user?.id)
        .single()

      console.log("👤 Dados do usuário:", { userData, userError })

      setResult({
        success: true,
        user: authData.user,
        profile: userData,
        userError,
      })
    } catch (error) {
      console.error("💥 Erro no teste:", error)
      setResult({ error: String(error), step: "catch" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>🧪 Teste de Login - MedFlux</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label>Email:</label>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" />
          </div>

          <div>
            <label>Senha:</label>
            <Input value={password} onChange={(e) => setPassword(e.target.value)} type="password" />
          </div>

          <Button onClick={testLogin} disabled={loading} className="w-full">
            {loading ? "Testando..." : "🧪 Testar Login"}
          </Button>

          {result && (
            <div className="mt-4 p-4 bg-gray-100 rounded-lg">
              <h3 className="font-bold mb-2">Resultado do Teste:</h3>
              <pre className="text-sm overflow-auto">{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}

          <div className="text-sm text-gray-600">
            <p>
              <strong>Instruções:</strong>
            </p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Digite sua senha</li>
              <li>Clique em "Testar Login"</li>
              <li>Abra o Console (F12) para ver logs detalhados</li>
              <li>Verifique o resultado abaixo</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
