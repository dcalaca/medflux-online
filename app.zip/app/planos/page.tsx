import DashboardLayout from "@/components/dashboard-layout"
import { PlanosView } from "@/components/planos-view"

export default function PlanosPage() {
  return (
    <DashboardLayout>
      <PlanosView />
    </DashboardLayout>
  )
}
