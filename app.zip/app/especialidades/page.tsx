import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { EspecialidadesView } from "@/components/especialidades-view"

export default async function EspecialidadesPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (usuarioError || !usuario || (usuario as any).tipo !== "medico") {
    redirect("/dashboard")
  }

  // Buscar especialidades
  const { data: especialidades } = await supabase.from("especialidades").select("*").order("nome")

  return (
    <DashboardLayout>
      <EspecialidadesView especialidades={(especialidades as any) || []} />
    </DashboardLayout>
  )
} 