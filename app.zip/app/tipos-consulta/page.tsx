import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { TiposConsultaTable } from "@/components/tipos-consulta-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function TiposConsultaPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (!usuario || (usuario.tipo !== "medico" && usuario.tipo !== "admin")) {
    redirect("/dashboard")
  }

  const { data: tiposConsulta } = await supabase
    .from("tipos_consulta")
    .select("*")
    .eq("medico_id", user.id)
    .eq("clinica_id", usuario.clinica_id)
    .order("nome", { ascending: true })

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Tipos de Consulta</h1>
            <p className="text-muted-foreground">Gerencie os tipos de consulta da sua especialidade</p>
          </div>
          <Button asChild>
            <Link href="/tipos-consulta/novo">
              <Plus className="w-4 h-4 mr-2" />
              Novo Tipo
            </Link>
          </Button>
        </div>

        <TiposConsultaTable tiposConsulta={tiposConsulta || []} />
      </div>
    </DashboardLayout>
  )
}
