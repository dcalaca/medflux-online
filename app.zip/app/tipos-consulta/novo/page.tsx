import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { NovoTipoConsultaForm } from "@/components/novo-tipo-consulta-form"

export default async function NovoTipoConsultaPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (!usuario || (usuario.tipo !== "medico" && usuario.tipo !== "admin")) {
    redirect("/dashboard")
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Novo Tipo de Consulta</h1>
          <p className="text-muted-foreground">Cadastre um novo tipo de consulta para sua especialidade</p>
        </div>

        <NovoTipoConsultaForm usuario={usuario} />
      </div>
    </DashboardLayout>
  )
}
