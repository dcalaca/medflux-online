import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { FinanceiroView } from "@/components/financeiro-view"

export const dynamic = "force-dynamic"

export default async function FinanceiroPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", String(user.id)).single()
  const usuarioData = usuario as any;
  if (!usuarioData || (usuarioData.tipo !== "admin" && usuarioData.tipo !== "medico" && usuarioData.tipo !== "recepcionista")) {
    redirect("/dashboard")
  }

  // Buscar consultas com informações financeiras
  const { data: consultas } = await supabase
    .from("consultas")
    .select(`
      *,
      pacientes(nome),
      tipos_consulta(nome, cor)
    `)
    .eq("medico_id", String(user.id))
    .eq("clinica_id", usuarioData.clinica_id)
    .order("data_hora", { ascending: false })

  return (
    <DashboardLayout>
      <FinanceiroView consultas={(consultas as any) || []} />
    </DashboardLayout>
  )
}
