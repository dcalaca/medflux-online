import { RegistroForm } from "@/components/registro-form"

export const dynamic = "force-dynamic"

export default function RegistroPage() {
  return <RegistroForm />
}
