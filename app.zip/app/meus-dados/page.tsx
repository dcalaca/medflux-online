import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { MeusDadosForm } from "@/components/meus-dados-form"

export default async function MeusDadosPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (!usuario) {
    redirect("/login")
  }

  // Buscar dados da clínica se o usuário tiver clínica associada
  let clinica = null
  if (usuario.clinica_id) {
    const { data: clinicaData } = await supabase
      .from("clinicas")
      .select("*")
      .eq("id", usuario.clinica_id)
      .single()
    clinica = clinicaData
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Meus Dados</h1>
          <p className="text-muted-foreground">Gerencie suas informações pessoais e da clínica</p>
        </div>

        <MeusDadosForm usuario={usuario} clinica={clinica} />
      </div>
    </DashboardLayout>
  )
} 
