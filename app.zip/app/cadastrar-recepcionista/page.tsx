import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import CadastrarRecepcionistaForm from "@/components/cadastrar-recepcionista-form"

export const dynamic = "force-dynamic"

export default async function CadastrarRecepcionistaPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  // Buscar dados do usuário
  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", user.id).single()

  if (usuarioError || !usuario) {
    redirect("/dashboard")
  }

  const usuarioData = usuario as any
  if (usuarioData.tipo !== "medico") {
    redirect("/dashboard")
  }

  if (!usuarioData.clinica_id) {
    redirect("/dashboard")
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 pb-16 content-safe">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Cadastrar Recepcionista</h1>
            <p className="text-muted-foreground text-sm sm:text-base">
              Adicione uma nova recepcionista à sua clínica
            </p>
          </div>
        </div>
        <CadastrarRecepcionistaForm clinicaId={usuarioData.clinica_id} medicoId={user.id} />
      </div>
    </DashboardLayout>
  )
} 