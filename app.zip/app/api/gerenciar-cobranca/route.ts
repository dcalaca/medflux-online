import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    console.log("💰 Buscando relatório de cobrança...")

    // 1. Buscar relatório de pagamentos
    const { data: relatorio, error: relatorioError } = await supabase
      .rpc('relatorio_pagamentos')

    if (relatorioError) {
      console.error("Erro ao buscar relatório:", relatorioError)
      return NextResponse.json({ 
        error: "Erro ao buscar relatório",
        details: relatorioError.message
      }, { status: 500 })
    }

    // 2. Buscar notificações de vencimento
    const { data: notificacoes, error: notificacoesError } = await supabase
      .rpc('notificar_usuarios_proximos_vencimento')

    if (notificacoesError) {
      console.error("Erro ao buscar notificações:", notificacoesError)
      return NextResponse.json({ 
        error: "Erro ao buscar notificações",
        details: notificacoesError.message
      }, { status: 500 })
    }

    // 3. Buscar usuários expirados
    const { data: usuariosExpirados, error: expiradosError } = await supabase
      .from("usuarios")
      .select("id, nome, email, dias_teste_restantes, status_conta, ativo")
      .not("data_inicio_teste", "is", null)
      .eq("dias_teste_restantes", 0)

    // 4. Buscar pagamentos pendentes
    const { data: pagamentosPendentes, error: pagamentosError } = await supabase
      .rpc('verificar_pagamentos_pendentes')

    if (pagamentosError) {
      console.error("Erro ao buscar pagamentos:", pagamentosError)
      return NextResponse.json({ 
        error: "Erro ao buscar pagamentos",
        details: pagamentosError.message
      }, { status: 500 })
    }

    if (expiradosError) {
      console.error("Erro ao buscar usuários expirados:", expiradosError)
      return NextResponse.json({ 
        error: "Erro ao buscar usuários expirados",
        details: expiradosError.message
      }, { status: 500 })
    }

    console.log("💰 Relatório de cobrança obtido com sucesso")

    return NextResponse.json({ 
      success: true,
      relatorio: relatorio?.[0] || {},
      notificacoes: notificacoes || [],
      usuarios_expirados: usuariosExpirados || [],
      pagamentos_pendentes: pagamentosPendentes || [],
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error("Erro na API de cobrança:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: String(error)
    }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const body = await request.json()
    const { action, usuario_id, plano_valor } = body
    
    console.log(`💰 Executando ação de cobrança: ${action}`)

    let resultado

    switch (action) {
      case 'bloquear_expirados':
        // Bloquear usuários expirados
        const { data: bloqueioResult, error: bloqueioError } = await supabase
          .rpc('bloquear_usuarios_expirados')

        if (bloqueioError) {
          console.error("Erro ao bloquear usuários:", bloqueioError)
          return NextResponse.json({ 
            error: "Erro ao bloquear usuários",
            details: bloqueioError.message
          }, { status: 500 })
        }

        resultado = bloqueioResult
        break

      case 'renovar_assinatura':
        // Renovar assinatura de um usuário
        if (!usuario_id) {
          return NextResponse.json({ 
            error: "ID do usuário é obrigatório para renovação"
          }, { status: 400 })
        }

        const { data: renovacaoResult, error: renovacaoError } = await supabase
          .rpc('renovar_assinatura', { 
            usuario_id: usuario_id, 
            plano_valor: plano_valor || 99.90 
          })

        if (renovacaoError) {
          console.error("Erro ao renovar assinatura:", renovacaoError)
          return NextResponse.json({ 
            error: "Erro ao renovar assinatura",
            details: renovacaoError.message
          }, { status: 500 })
        }

        resultado = renovacaoResult
        break

      case 'criar_pagamentos_automaticos':
        // Criar pagamentos automáticos para usuários expirados
        const { data: pagamentosResult, error: pagamentosError } = await supabase
          .rpc('criar_pagamentos_automaticos')

        if (pagamentosError) {
          console.error("Erro ao criar pagamentos:", pagamentosError)
          return NextResponse.json({ 
            error: "Erro ao criar pagamentos",
            details: pagamentosError.message
          }, { status: 500 })
        }

        resultado = pagamentosResult
        break

      case 'processar_pagamento':
        // Processar pagamento de uma cobrança
        const { cobranca_id, metodo_pagamento } = body
        
        if (!cobranca_id) {
          return NextResponse.json({ 
            error: "ID da cobrança é obrigatório"
          }, { status: 400 })
        }

        const { data: pagamentoResult, error: pagamentoError } = await supabase
          .rpc('processar_pagamento', { 
            cobranca_id: cobranca_id, 
            metodo_pagamento: metodo_pagamento || 'pix' 
          })

        if (pagamentoError) {
          console.error("Erro ao processar pagamento:", pagamentoError)
          return NextResponse.json({ 
            error: "Erro ao processar pagamento",
            details: pagamentoError.message
          }, { status: 500 })
        }

        resultado = pagamentoResult
        break

      default:
        return NextResponse.json({ 
          error: "Ação não reconhecida",
          details: "Ações válidas: bloquear_expirados, renovar_assinatura, criar_pagamentos_automaticos, processar_pagamento"
        }, { status: 400 })
    }

    console.log(`✅ Ação ${action} executada com sucesso`)

    return NextResponse.json({ 
      success: true,
      message: `Ação ${action} executada com sucesso`,
      resultado,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error("Erro na API de cobrança:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: String(error)
    }, { status: 500 })
  }
} 