import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== TESTE DE LOGIN DA TATIANA ===")

    // 1. Verificar se o usuário existe
    const { data: authUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()

    if (listError) {
      logs.push(`Erro ao listar usuários: ${listError.message}`)
      return NextResponse.json({ error: "Erro ao listar usuários" }, { status: 500 })
    }

    const tatiana = authUsers.users.find(u => u.email === 'tatianag.calaca@gmail.com')
    
    if (!tatiana) {
      logs.push("❌ Usuário Tatiana NÃO encontrado no Auth")
      return NextResponse.json({ 
        error: "Usuário não encontrado",
        logs: logs.join('\n')
      }, { status: 404 })
    }

    logs.push(`✅ Usuário encontrado: ${tatiana.id}`)
    logs.push(`📧 Email: ${tatiana.email}`)
    logs.push(`✅ Email confirmado: ${tatiana.email_confirmed_at ? 'SIM' : 'NÃO'}`)
    logs.push(`🔐 Tem senha: ${tatiana.encrypted_password ? 'SIM' : 'NÃO'}`)
    logs.push(`📏 Tamanho da senha: ${tatiana.encrypted_password ? tatiana.encrypted_password.length : 0}`)

    // 2. Tentar fazer login programaticamente
    logs.push("\n--- TESTANDO LOGIN PROGRAMÁTICO ---")
    
    const { data: signInData, error: signInError } = await supabaseAdmin.auth.admin.generateLink({
      type: 'magiclink',
      email: 'tatianag.calaca@gmail.com',
      options: {
        redirectTo: 'http://localhost:3000/login'
      }
    })

    if (signInError) {
      logs.push(`❌ Erro no magic link: ${signInError.message}`)
    } else {
      logs.push(`✅ Magic link gerado com sucesso`)
    }

    // 3. Verificar configurações do Supabase
    logs.push("\n--- VERIFICANDO CONFIGURAÇÕES ---")
    
    const { data: settings, error: settingsError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (settingsError) {
      logs.push(`❌ Erro ao verificar configurações: ${settingsError.message}`)
    } else {
      logs.push(`✅ Configurações verificadas`)
    }

    // 4. Tentar criar um novo cliente para teste
    logs.push("\n--- TESTANDO CLIENTE ALTERNATIVO ---")
    
    const testClient = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )

    const { data: testData, error: testError } = await testClient.auth.signInWithPassword({
      email: 'tatianag.calaca@gmail.com',
      password: '123456'
    })

    if (testError) {
      logs.push(`❌ Erro no teste de login: ${testError.message}`)
      logs.push(`🔍 Código do erro: ${testError.status}`)
    } else {
      logs.push(`✅ Login funcionou no teste programático!`)
      logs.push(`👤 User ID: ${testData.user?.id}`)
    }

    // 5. Verificar se há problemas de RLS
    logs.push("\n--- VERIFICANDO RLS ---")
    
    const { data: rlsTest, error: rlsError } = await supabaseAdmin
      .from('usuarios')
      .select('*')
      .eq('email', 'tatianag.calaca@gmail.com')
      .single()

    if (rlsError) {
      logs.push(`❌ Erro RLS: ${rlsError.message}`)
    } else {
      logs.push(`✅ RLS OK - Usuário encontrado na tabela`)
      logs.push(`🏥 Clínica ID: ${rlsTest.clinica_id}`)
      logs.push(`👤 Tipo: ${rlsTest.tipo}`)
    }

    return NextResponse.json({
      success: true,
      message: "Teste de login concluído",
      logs: logs.join('\n'),
      user: tatiana,
      testResult: testError ? { error: testError.message } : { success: true, user: testData.user }
    })

  } catch (error: any) {
    console.error("Erro na API:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: error.message
    }, { status: 500 })
  }
} 