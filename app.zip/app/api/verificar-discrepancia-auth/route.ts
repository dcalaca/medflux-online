import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== INVESTIGANDO DISCREPÂNCIA AUTH ===")

    // 1. Listar todos os usuários via API
    logs.push("\n--- LISTANDO USUÁRIOS VIA API ---")
    const { data: authUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()

    if (listError) {
      logs.push(`❌ Erro ao listar usuários: ${listError.message}`)
      return NextResponse.json({ error: "Erro ao listar usuários" }, { status: 500 })
    }

    logs.push(`📊 Total de usuários via API: ${authUsers.users.length}`)
    logs.push(`📧 Emails via API: ${authUsers.users.map(u => u.email).join(', ')}`)

    // 2. Verificar se Tatiana está na lista da API
    const tatianaAPI = authUsers.users.find(u => u.email === 'tatianag.calaca@gmail.com')
    
    if (tatianaAPI) {
      logs.push(`✅ Tatiana encontrada via API: ${tatianaAPI.id}`)
      logs.push(`📧 Email: ${tatianaAPI.email}`)
      logs.push(`✅ Email confirmado: ${tatianaAPI.email_confirmed_at ? 'SIM' : 'NÃO'}`)
      logs.push(`🔐 Tem senha: ${(tatianaAPI as any).encrypted_password ? 'SIM' : 'NÃO'}`)
      logs.push(`📏 Tamanho da senha: ${(tatianaAPI as any).encrypted_password ? (tatianaAPI as any).encrypted_password.length : 0}`)
    } else {
      logs.push(`❌ Tatiana NÃO encontrada via API`)
    }

    // 3. Verificar configurações do cliente
    logs.push("\n--- VERIFICANDO CONFIGURAÇÕES ---")
    logs.push(`🔗 URL: ${process.env.NEXT_PUBLIC_SUPABASE_URL}`)
    logs.push(`🔑 Service Role Key: ${process.env.SUPABASE_SERVICE_ROLE_KEY ? 'PRESENTE' : 'AUSENTE'}`)
    logs.push(`📏 Service Role Key Length: ${process.env.SUPABASE_SERVICE_ROLE_KEY?.length || 0}`)

    // 4. Tentar criar um novo cliente
    logs.push("\n--- TESTANDO NOVO CLIENTE ---")
    
    const newClient = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    const { data: newAuthUsers, error: newListError } = await newClient.auth.admin.listUsers()

    if (newListError) {
      logs.push(`❌ Erro com novo cliente: ${newListError.message}`)
    } else {
      logs.push(`📊 Total com novo cliente: ${newAuthUsers.users.length}`)
      logs.push(`📧 Emails com novo cliente: ${newAuthUsers.users.map(u => u.email).join(', ')}`)
      
      const tatianaNew = newAuthUsers.users.find(u => u.email === 'tatianag.calaca@gmail.com')
      if (tatianaNew) {
        logs.push(`✅ Tatiana encontrada com novo cliente: ${tatianaNew.id}`)
      } else {
        logs.push(`❌ Tatiana NÃO encontrada com novo cliente`)
      }
    }

    // 5. Verificar se há diferença entre os clientes
    const apiEmails = authUsers.users.map(u => u.email).sort()
    const newEmails = newAuthUsers.users.map(u => u.email).sort()
    
    logs.push("\n--- COMPARAÇÃO DE CLIENTES ---")
    logs.push(`🔍 Emails API: ${apiEmails.join(', ')}`)
    logs.push(`🔍 Emails Novo Cliente: ${newEmails.join(', ')}`)
    logs.push(`✅ Emails iguais: ${JSON.stringify(apiEmails) === JSON.stringify(newEmails)}`)

    return NextResponse.json({
      success: true,
      message: "Investigação concluída",
      logs: logs.join('\n'),
      apiUsers: authUsers.users.length,
      apiEmails: authUsers.users.map(u => u.email),
      newClientUsers: newAuthUsers.users.length,
      newClientEmails: newAuthUsers.users.map(u => u.email),
      tatianaFound: !!tatianaAPI,
      tatianaFoundNew: !!newAuthUsers.users.find(u => u.email === 'tatianag.calaca@gmail.com')
    })

  } catch (error: any) {
    console.error("Erro na API:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: error.message
    }, { status: 500 })
  }
} 