import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== DEFININDO SENHAS PARA USUÁRIOS EXISTENTES ===")
    
    // Buscar todos os usuários do Auth
    const { data: authUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      logs.push(`Erro ao listar usuários: ${listError.message}`)
      return NextResponse.json({ error: "Erro ao listar usuários" }, { status: 500 })
    }

    logs.push(`Total de usuários encontrados: ${authUsers.users.length}`)
    logs.push(`Emails: ${authUsers.users.map(u => u.email).join(', ')}`)

    const recepcionistas = [
      'tatianag.calaca@gmail.com',
      'recepcionista@teste.com'
    ]

    const resultados = []

    for (const email of recepcionistas) {
      try {
        logs.push(`\n--- Processando ${email} ---`)
        
        // Procurar usuário no Auth
        const authUser = authUsers.users.find(u => u.email === email)
        
        if (!authUser) {
          logs.push(`Usuário ${email} NÃO encontrado no Auth`)
          resultados.push({
            email,
            status: "Usuário não encontrado no Auth",
            sucesso: false
          })
          continue
        }

        logs.push(`Usuário encontrado com ID: ${authUser.id}`)
        logs.push(`Email confirmado: ${authUser.email_confirmed_at ? 'SIM' : 'NÃO'}`)
        
        // Definir senha e confirmar email
        logs.push("Definindo senha e confirmando email...")
        
        const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
          authUser.id,
          {
            password: "123456",
            email_confirm: true,
          }
        )

        if (updateError) {
          logs.push(`Erro ao atualizar usuário: ${updateError.message}`)
          resultados.push({
            email,
            status: `Erro ao definir senha: ${updateError.message}`,
            sucesso: false
          })
          continue
        }

        logs.push("Senha definida e email confirmado com sucesso!")
        resultados.push({
          email,
          status: "Senha definida com sucesso! Nova senha: 123456",
          sucesso: true
        })

      } catch (error: any) {
        logs.push(`Erro inesperado para ${email}: ${error.message}`)
        resultados.push({
          email,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    logs.push(`\n=== RESULTADO FINAL ===`)
    logs.push(`Sucessos: ${sucessos}, Falhas: ${falhas}`)

    return NextResponse.json({
      success: true,
      message: `Definição de senhas concluída! ${sucessos} sucessos, ${falhas} falhas`,
      resultados,
      logs: logs.join('\n')
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 