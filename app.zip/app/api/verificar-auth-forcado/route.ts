import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("=== VERIFICAÇÃO FORÇADA DO AUTH ===")
    
    // Criar nova instância do cliente
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    console.log("URL:", process.env.NEXT_PUBLIC_SUPABASE_URL)
    console.log("Service Role Key length:", process.env.SUPABASE_SERVICE_ROLE_KEY?.length || 0)
    
    // Buscar todos os usuários do Auth
    const { data: authUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      console.error("Erro ao listar usuários:", listError)
      return NextResponse.json({ 
        error: "Erro ao listar usuários",
        details: listError.message 
      }, { status: 500 })
    }

    console.log(`Total de usuários encontrados: ${authUsers.users.length}`)
    
    // Listar todos os usuários com detalhes
    const usuariosDetalhados = authUsers.users.map(user => ({
      id: user.id,
      email: user.email,
      email_confirmed: user.email_confirmed_at ? true : false,
      created_at: user.created_at,
      last_sign_in: user.last_sign_in_at
    }))

    console.log("Usuários detalhados:", usuariosDetalhados)

    // Verificar especificamente os recepcionistas
    const recepcionistas = [
      'tatianag.calaca@gmail.com',
      'recepcionista@teste.com'
    ]

    const recepcionistasEncontrados = authUsers.users.filter(user => 
      user.email && recepcionistas.includes(user.email)
    )

    console.log(`Recepcionistas encontrados: ${recepcionistasEncontrados.length}`)

    // Tentar buscar usuários específicos
    const resultadosEspecificos = []
    
    for (const email of recepcionistas) {
      try {
        const { data: userData, error: userError } = await supabaseAdmin.auth.admin.getUserById(email)
        
        if (userError) {
          console.log(`Erro ao buscar ${email}:`, userError.message)
          resultadosEspecificos.push({
            email,
            encontrado: false,
            erro: userError.message
          })
        } else {
          console.log(`Usuário ${email} encontrado:`, userData.user?.id)
          resultadosEspecificos.push({
            email,
            encontrado: true,
            id: userData.user?.id
          })
        }
      } catch (error: any) {
        console.log(`Erro inesperado para ${email}:`, error.message)
        resultadosEspecificos.push({
          email,
          encontrado: false,
          erro: error.message
        })
      }
    }

    return NextResponse.json({
      success: true,
      total_usuarios: authUsers.users.length,
      usuarios_detalhados: usuariosDetalhados,
      recepcionistas_encontrados: recepcionistasEncontrados.map(user => ({
        id: user.id,
        email: user.email,
        email_confirmed: user.email_confirmed_at ? true : false,
        created_at: user.created_at
      })),
      emails_todos: authUsers.users.map(u => u.email).filter(Boolean),
      resultados_especificos: resultadosEspecificos
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 