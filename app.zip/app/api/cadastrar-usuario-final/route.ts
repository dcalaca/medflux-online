import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o usuário é médico (pode cadastrar recepcionistas)
    const { data: usuarioData, error: usuarioError } = await supabase
      .from("usuarios")
      .select("tipo, clinica_id")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuarioData) {
      console.error("Erro ao buscar usuário:", usuarioError)
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (usuarioData.tipo !== "medico" && usuarioData.tipo !== "adm") {
      return NextResponse.json({ error: "Sem permissão para cadastrar usuários" }, { status: 403 })
    }
    
    const body = await request.json()
    const { nome, email } = body

    // Validações
    if (!nome || !email) {
      return NextResponse.json({ error: "Nome e email são obrigatórios" }, { status: 400 })
    }

    // Verificar se o email já existe na tabela usuarios
    const { data: existingUser } = await supabase
      .from("usuarios")
      .select("id, nome, tipo")
      .eq("email", email)
      .single()

    if (existingUser) {
      return NextResponse.json({ 
        error: "Email já cadastrado", 
        details: `O email ${email} já está cadastrado para ${existingUser.nome} (${existingUser.tipo})`,
        code: "EMAIL_ALREADY_EXISTS"
      }, { status: 400 })
    }

    // Criar usuário diretamente na tabela usuarios (sem Auth por enquanto)
    // O usuário poderá fazer login posteriormente através de um processo de recuperação
    const novoUsuarioId = crypto.randomUUID()
    
    console.log("Tentando inserir usuário:", {
      id: novoUsuarioId,
      email,
      nome,
      telefone: body.telefone,
      clinica_id: usuarioData.clinica_id,
      tipo: "recepcionista",
      ativo: true,
    })
    
    const { data: insertData, error: insertError } = await supabase
      .from("usuarios")
      .insert({
        id: novoUsuarioId,
        email,
        nome,
        telefone: body.telefone,
        clinica_id: usuarioData.clinica_id,
        tipo: "recepcionista",
        ativo: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()

    if (insertError) {
      console.error("Erro ao inserir usuário na tabela:", insertError)
      console.error("Detalhes do erro:", {
        code: insertError.code,
        message: insertError.message,
        details: insertError.details,
        hint: insertError.hint
      })
      return NextResponse.json({ 
        error: "Erro ao salvar dados do usuário", 
        details: insertError.message,
        code: insertError.code
      }, { status: 500 })
    }

    console.log("Usuário inserido com sucesso:", insertData)

    return NextResponse.json({ 
      success: true, 
      message: "Recepcionista cadastrado com sucesso! O login será criado posteriormente.",
      user: insertData[0]
    })
  } catch (error) {
    console.error("Erro na API de cadastro:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 