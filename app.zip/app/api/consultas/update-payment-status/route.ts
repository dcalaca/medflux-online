import { createServerClient } from "@/lib/supabase/server"
import { NextRequest, NextResponse } from "next/server"

export async function PUT(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    
    // Verificar autenticação
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Buscar dados do usuário
    const { data: usuario, error: usuarioError } = await supabase
      .from("usuarios")
      .select("*")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuario) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    // Verificar se é médico ou atendente
    if (usuario.tipo !== "medico" && usuario.tipo !== "atendente") {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Obter dados da requisição
    const { consultaId, status_pagamento } = await request.json()

    if (!consultaId || !status_pagamento) {
      return NextResponse.json({ error: "Dados inválidos" }, { status: 400 })
    }

    // Verificar se o status é válido
    const statusValidos = ["pendente", "pago", "cancelado"]
    if (!statusValidos.includes(status_pagamento)) {
      return NextResponse.json({ error: "Status inválido" }, { status: 400 })
    }

    // Buscar a consulta para verificar permissões
    const { data: consulta, error: consultaError } = await supabase
      .from("consultas")
      .select("*")
      .eq("id", consultaId)
      .single()

    if (consultaError || !consulta) {
      return NextResponse.json({ error: "Consulta não encontrada" }, { status: 404 })
    }

    // Verificar se o usuário tem permissão para esta consulta
    if (usuario.tipo === "medico" && consulta.medico_id !== user.id) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    if (consulta.clinica_id !== usuario.clinica_id) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Atualizar o status de pagamento da consulta
    const { error: updateError } = await supabase
      .from("consultas")
      .update({ 
        status_pagamento: status_pagamento,
        updated_at: new Date().toISOString()
      })
      .eq("id", consultaId)

    if (updateError) {
      console.error("Erro ao atualizar status de pagamento:", updateError)
      return NextResponse.json({ error: "Erro ao atualizar status de pagamento" }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true, 
      message: "Status de pagamento atualizado com sucesso" 
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 