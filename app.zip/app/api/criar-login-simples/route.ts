import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json({ error: "Email é obrigatório" }, { status: 400 })
    }

    console.log(`Criando login para: ${email}`)

    // 1. Verificar se o usuário existe na tabela usuarios
    const { data: usuario, error: usuarioError } = await supabase
      .from("usuarios")
      .select("id, nome, tipo, clinica_id")
      .eq("email", email)
      .single()

    if (usuarioError || !usuario) {
      return NextResponse.json({ 
        error: "Usuário não encontrado na tabela usuarios",
        details: `Email ${email} não encontrado`
      }, { status: 404 })
    }

    console.log(`Usuário encontrado: ${usuario.nome} (${usuario.tipo})`)

    // 2. Verificar se já tem Auth
    try {
      const { data: authUser } = await supabase.auth.admin.getUserById(usuario.id)
      
      if (authUser.user) {
        return NextResponse.json({ 
          error: "Usuário já possui login",
          details: `O usuário ${usuario.nome} já possui uma conta de autenticação`
        }, { status: 400 })
      }
    } catch (error) {
      // Se não encontrou no Auth, continuar com a criação
      console.log("Usuário não encontrado no Auth, criando...")
    }

    // 3. Criar usuário no Auth usando signUp (que funciona sem admin)
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email: email,
      password: "123456",
      options: {
        data: {
          nome: usuario.nome,
          tipo: usuario.tipo,
          clinica_id: usuario.clinica_id
        }
      }
    })

    if (signUpError) {
      console.error("Erro ao criar usuário no Auth:", signUpError)
      return NextResponse.json({ 
        error: "Erro ao criar usuário no sistema de autenticação",
        details: signUpError.message
      }, { status: 500 })
    }

    console.log("Usuário criado no Auth:", signUpData.user?.id)

    // 4. Atualizar o ID na tabela usuarios para usar o mesmo ID do Auth
    if (signUpData.user) {
      const { error: updateError } = await supabase
        .from("usuarios")
        .update({
          id: signUpData.user.id,
          updated_at: new Date().toISOString(),
        })
        .eq("email", email)

      if (updateError) {
        console.error("Erro ao atualizar ID do usuário:", updateError)
        return NextResponse.json({ 
          error: "Erro ao atualizar dados do usuário", 
          details: updateError.message
        }, { status: 500 })
      }
    }

    console.log("Login criado com sucesso para:", usuario.nome)

    return NextResponse.json({ 
      success: true, 
      message: `Login criado com sucesso para ${usuario.nome}! Um email de confirmação foi enviado para ${email}. A senha padrão é: 123456`,
      user: usuario,
      authUser: signUpData.user
    })
  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 