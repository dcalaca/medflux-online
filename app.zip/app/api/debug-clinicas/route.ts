import { createServerClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = await createServerClient()
    
    // Verificar se há dados na tabela clinicas
    const { data: clinicas, error } = await supabase
      .from("clinicas")
      .select("*")
      .order("nome")

    if (error) {
      return NextResponse.json({ 
        error: "Erro ao buscar clínicas", 
        details: error 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      totalClinicas: clinicas?.length || 0,
      clinicas: clinicas || []
    })

  } catch (error) {
    return NextResponse.json({ 
      error: "Erro interno do servidor", 
      details: error 
    }, { status: 500 })
  }
} 