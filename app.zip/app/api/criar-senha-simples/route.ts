import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { email, senha = "123456" } = body

    if (!email) {
      return NextResponse.json({ error: "Email é obrigatório" }, { status: 400 })
    }

    console.log(`Definindo senha para: ${email}`)

    // 1. Verificar se o usuário existe na tabela usuarios
    const { data: usuario, error: usuarioError } = await supabase
      .from("usuarios")
      .select("id, nome, tipo")
      .eq("email", email)
      .single()

    if (usuarioError || !usuario) {
      return NextResponse.json({ 
        error: "Usuário não encontrado na tabela usuarios",
        details: `Email ${email} não encontrado`
      }, { status: 404 })
    }

    console.log(`Usuário encontrado: ${usuario.nome} (${usuario.tipo})`)

    // 2. Criar usuário no Auth
    try {
      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email: email,
        password: senha,
        email_confirm: true,
        user_metadata: {
          nome: usuario.nome,
          tipo: usuario.tipo
        }
      })

      if (authError) {
        return NextResponse.json({ 
          error: "Erro ao criar usuário no Auth",
          details: authError.message
        }, { status: 500 })
      }

      return NextResponse.json({ 
        success: true,
        message: `Login criado com sucesso para ${usuario.nome}! Senha: ${senha}`,
        senha: senha,
        user: authUser.user
      })

    } catch (error: any) {
      console.error("Erro completo:", error)
      return NextResponse.json({ 
        error: "Erro interno",
        details: error.message
      }, { status: 500 })
    }

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 