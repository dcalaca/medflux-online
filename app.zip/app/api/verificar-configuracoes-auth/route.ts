import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== VERIFICANDO CONFIGURAÇÕES DE AUTH ===")

    // 1. Verificar se conseguimos acessar as configurações
    logs.push("\n--- TESTANDO ACESSO ÀS CONFIGURAÇÕES ---")
    
    // Tentar obter informações do projeto
    const { data: projectInfo, error: projectError } = await supabaseAdmin
      .from('auth.users')
      .select('count')
      .limit(1)

    if (projectError) {
      logs.push(`❌ Erro ao acessar auth.users: ${projectError.message}`)
    } else {
      logs.push(`✅ Acesso a auth.users OK`)
    }

    // 2. Verificar configurações do cliente
    logs.push("\n--- CONFIGURAÇÕES DO CLIENTE ---")
    logs.push(`🔗 URL: ${process.env.NEXT_PUBLIC_SUPABASE_URL}`)
    logs.push(`🔑 Service Role Key: ${process.env.SUPABASE_SERVICE_ROLE_KEY ? 'PRESENTE' : 'AUSENTE'}`)
    logs.push(`📏 Service Role Key Length: ${process.env.SUPABASE_SERVICE_ROLE_KEY?.length || 0}`)
    logs.push(`🔑 Anon Key: ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? 'PRESENTE' : 'AUSENTE'}`)
    logs.push(`📏 Anon Key Length: ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.length || 0}`)

    // 3. Testar diferentes métodos de autenticação
    logs.push("\n--- TESTANDO MÉTODOS DE AUTH ---")
    
    // Testar signInWithPassword
    const testClient = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )

    const { data: signInTest, error: signInError } = await testClient.auth.signInWithPassword({
      email: 'tatianag.calaca@gmail.com',
      password: '123456'
    })

    if (signInError) {
      logs.push(`❌ Erro no signInWithPassword: ${signInError.message}`)
      logs.push(`🔍 Código: ${signInError.status}`)
      logs.push(`🔍 Nome: ${signInError.name}`)
    } else {
      logs.push(`✅ signInWithPassword funcionou!`)
      logs.push(`👤 User ID: ${signInTest.user?.id}`)
    }

    // 4. Verificar se há problemas de CORS ou configuração
    logs.push("\n--- VERIFICANDO PROBLEMAS DE CONFIGURAÇÃO ---")
    
    // Testar se conseguimos fazer uma requisição simples
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/auth/v1/user`, {
        headers: {
          'apikey': process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
        }
      })
      
      if (response.ok) {
        logs.push(`✅ Requisição HTTP direta OK`)
      } else {
        logs.push(`❌ Requisição HTTP falhou: ${response.status}`)
      }
    } catch (error: any) {
      logs.push(`❌ Erro na requisição HTTP: ${error.message}`)
    }

    // 5. Verificar se o problema é específico da Tatiana
    logs.push("\n--- TESTANDO OUTROS USUÁRIOS ---")
    
    // Listar todos os usuários para ver se outros funcionam
    const { data: allUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      logs.push(`❌ Erro ao listar usuários: ${listError.message}`)
    } else {
      logs.push(`📊 Total de usuários: ${allUsers.users.length}`)
      logs.push(`📧 Emails: ${allUsers.users.map(u => u.email).join(', ')}`)
      
      // Verificar se há outros usuários confirmados
      const confirmedUsers = allUsers.users.filter(u => u.email_confirmed_at)
      logs.push(`✅ Usuários confirmados: ${confirmedUsers.length}`)
      logs.push(`📧 Emails confirmados: ${confirmedUsers.map(u => u.email).join(', ')}`)
    }

    return NextResponse.json({
      success: true,
      message: "Verificação de configurações concluída",
      logs: logs.join('\n'),
      signInSuccess: !signInError,
      signInError: signInError ? signInError.message : null,
      totalUsers: allUsers?.users.length || 0,
      confirmedUsers: allUsers?.users.filter(u => u.email_confirmed_at).length || 0
    })

  } catch (error: any) {
    console.error("Erro na API:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: error.message
    }, { status: 500 })
  }
} 