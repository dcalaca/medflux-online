import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("Verificando variáveis de ambiente...")
    
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY
    
    console.log("SUPABASE_URL:", supabaseUrl ? "Configurado" : "NÃO CONFIGURADO")
    console.log("SERVICE_ROLE_KEY:", serviceRoleKey ? "Configurado" : "NÃO CONFIGURADO")
    
    return NextResponse.json({ 
      success: true, 
      message: "Verificação concluída",
      supabaseUrl: supabaseUrl ? "OK" : "FALTANDO",
      serviceRoleKey: serviceRoleKey ? "OK" : "FALTANDO"
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 