import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o usuário é médico (pode cadastrar recepcionistas)
    const { data: usuarioData, error: usuarioError } = await supabase
      .from("usuarios")
      .select("tipo, clinica_id")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuarioData) {
      console.error("Erro ao buscar usuário:", usuarioError)
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (usuarioData.tipo !== "medico" && usuarioData.tipo !== "adm") {
      return NextResponse.json({ error: "Sem permissão para cadastrar usuários" }, { status: 403 })
    }
    
    const body = await request.json()
    const { nome, email, telefone } = body

    // Validações
    if (!nome || !email) {
      return NextResponse.json({ error: "Nome e email são obrigatórios" }, { status: 400 })
    }

    // Verificar se o email já existe
    const { data: existingUser } = await supabase
      .from("usuarios")
      .select("id, nome, tipo")
      .eq("email", email)
      .single()

    if (existingUser) {
      return NextResponse.json({ 
        error: "Email já cadastrado", 
        details: `O email ${email} já está cadastrado para ${existingUser.nome} (${existingUser.tipo})`,
        code: "EMAIL_ALREADY_EXISTS"
      }, { status: 400 })
    }

    console.log(`Criando recepcionista: ${nome} (${email})`)

    // 1. Criar usuário no Supabase Auth (MESMO CÓDIGO DO MÉDICO)
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email,
      password: "123456", // Senha padrão
      options: {
        data: {
          nome: nome,
          telefone: telefone,
          tipo: "recepcionista", // Tipo específico para recepcionistas
          clinica_id: usuarioData.clinica_id
        },
      },
    })

    if (authError) {
      console.error("Erro ao criar usuário no Auth:", authError)
      return NextResponse.json({ 
        error: "Erro ao criar usuário no sistema de autenticação",
        details: authError.message
      }, { status: 500 })
    }

    if (authData.user) {
      // 2. Criar usuário na tabela usuarios (MESMO CÓDIGO DO MÉDICO)
      const { error: usuarioError } = await supabase.from("usuarios").insert({
        id: authData.user.id,
        email: email,
        nome: nome,
        telefone: telefone,
        clinica_id: usuarioData.clinica_id,
        tipo: "recepcionista", // Tipo específico para recepcionistas
        ativo: true,
      })

      if (usuarioError) {
        console.error("Erro ao criar usuário na tabela:", usuarioError)
        return NextResponse.json({ 
          error: "Erro ao salvar dados do usuário", 
          details: usuarioError.message
        }, { status: 500 })
      }

      console.log("Recepcionista criado com sucesso:", authData.user.id)

      return NextResponse.json({ 
        success: true, 
        message: `Recepcionista ${nome} cadastrado com sucesso! Um email de confirmação foi enviado para ${email}. A senha padrão é: 123456`,
        user: authData.user
      })
    }

    return NextResponse.json({ 
      success: true, 
      message: `Recepcionista ${nome} cadastrado com sucesso! Um email de confirmação foi enviado para ${email}. A senha padrão é: 123456`
    })

  } catch (error) {
    console.error("Erro na API de cadastro:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 