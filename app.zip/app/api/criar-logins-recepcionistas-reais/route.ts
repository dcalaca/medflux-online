import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== CRIANDO LOGINS PARA RECEPCIONISTAS REAIS ===")
    
    // Buscar recepcionistas da tabela usuarios
    const { data: recepcionistas, error: buscaError } = await supabaseAdmin
      .from("usuarios")
      .select("*")
      .eq("tipo", "recepcionista")
      .eq("ativo", true)

    if (buscaError) {
      logs.push(`Erro ao buscar recepcionistas: ${buscaError.message}`)
      return NextResponse.json({ error: "Erro ao buscar recepcionistas" }, { status: 500 })
    }

    if (!recepcionistas || recepcionistas.length === 0) {
      return NextResponse.json({ message: "Nenhum recepcionista encontrado" })
    }

    logs.push(`Encontrados ${recepcionistas.length} recepcionistas na tabela usuarios`)

    // Buscar usuários existentes no Auth
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (authError) {
      logs.push(`Erro ao listar usuários do Auth: ${authError.message}`)
      return NextResponse.json({ error: "Erro ao listar usuários do Auth" }, { status: 500 })
    }

    const emailsExistentes = authUsers.users.map(u => u.email)
    logs.push(`Emails existentes no Auth: ${emailsExistentes.join(', ')}`)

    const resultados = []

    for (const recepcionista of recepcionistas) {
      try {
        logs.push(`\n--- Processando ${recepcionista.email} ---`)
        logs.push(`ID na tabela: ${recepcionista.id}`)
        logs.push(`Nome: ${recepcionista.nome}`)
        
        // Verificar se já existe no Auth
        if (emailsExistentes.includes(recepcionista.email)) {
          logs.push("Email já existe no Auth, pulando...")
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Já existe no Auth",
            sucesso: true
          })
          continue
        }

        logs.push("Criando usuário no Auth...")
        
        // Criar usuário no Auth
        const { data: authData, error: createError } = await supabaseAdmin.auth.admin.createUser({
          email: recepcionista.email,
          password: "123456",
          email_confirm: true,
          user_metadata: {
            nome: recepcionista.nome,
            telefone: recepcionista.telefone,
          },
        })

        if (createError) {
          logs.push(`Erro ao criar ${recepcionista.email}: ${createError.message}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Erro: ${createError.message}`,
            sucesso: false
          })
          continue
        }

        if (!authData.user) {
          logs.push(`Falha ao criar usuário para ${recepcionista.email}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Falha ao criar usuário no Auth",
            sucesso: false
          })
          continue
        }

        logs.push(`Usuário criado no Auth com ID: ${authData.user.id}`)

        // Atualizar o ID na tabela usuarios para sincronizar
        const { error: updateError } = await supabaseAdmin
          .from("usuarios")
          .update({ id: authData.user.id })
          .eq("email", recepcionista.email)

        if (updateError) {
          logs.push(`Erro ao atualizar ID para ${recepcionista.email}: ${updateError.message}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Login criado mas erro ao sincronizar: ${updateError.message}`,
            sucesso: false
          })
          continue
        }

        logs.push(`Login criado e sincronizado com sucesso para ${recepcionista.email}`)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: "Login criado com sucesso! Senha: 123456",
          sucesso: true
        })

      } catch (error: any) {
        logs.push(`Erro inesperado para ${recepcionista.email}: ${error.message}`)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    logs.push(`\n=== RESULTADO FINAL ===`)
    logs.push(`Sucessos: ${sucessos}, Falhas: ${falhas}`)

    return NextResponse.json({
      success: true,
      message: `Processo concluído! ${sucessos} sucessos, ${falhas} falhas`,
      resultados,
      logs: logs.join('\n')
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 