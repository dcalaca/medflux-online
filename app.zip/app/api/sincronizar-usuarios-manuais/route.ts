import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== SINCRONIZANDO USUÁRIOS MANUAIS ===")
    
    // Lista de recepcionistas que devem existir
    const recepcionistas = [
      {
        id: '051bdd17-c7c9-4bb8-b495-16250e91eab6',
        email: 'tatianag.calaca@gmail.com',
        nome: 'Tatiana Calaça'
      },
      {
        id: '23dcfd03-1f0c-44e1-a28c-99ff6309363e',
        email: 'recepcionista@teste.com',
        nome: 'Teste Recepcionista'
      }
    ]

    // Buscar todos os usuários do Auth
    const { data: authUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      logs.push(`Erro ao listar usuários: ${listError.message}`)
      return NextResponse.json({ error: "Erro ao listar usuários" }, { status: 500 })
    }

    logs.push(`Total de usuários no Auth: ${authUsers.users.length}`)
    logs.push(`Emails no Auth: ${authUsers.users.map(u => u.email).join(', ')}`)

    const resultados = []

    for (const recepcionista of recepcionistas) {
      try {
        logs.push(`\n--- Verificando ${recepcionista.email} ---`)
        
        // Procurar usuário no Auth
        const authUser = authUsers.users.find(u => u.email === recepcionista.email)
        
        if (!authUser) {
          logs.push(`Usuário ${recepcionista.email} NÃO encontrado no Auth`)
          logs.push("INSTRUÇÕES:")
          logs.push("1. Vá para o Supabase Dashboard")
          logs.push("2. Acesse Authentication > Users")
          logs.push("3. Clique em 'Add User'")
          logs.push(`4. Email: ${recepcionista.email}`)
          logs.push("5. Senha: 123456")
          logs.push("6. Marque 'Auto-confirm email'")
          logs.push("7. Clique em 'Create User'")
          logs.push("8. Depois execute esta API novamente")
          
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Usuário não encontrado no Auth - Criar manualmente no Dashboard",
            sucesso: false
          })
          continue
        }

        logs.push(`Usuário encontrado no Auth com ID: ${authUser.id}`)
        logs.push(`Email confirmado: ${authUser.email_confirmed_at ? 'SIM' : 'NÃO'}`)
        
        // Verificar se precisa confirmar email
        if (!authUser.email_confirmed_at) {
          logs.push("Confirmando email...")
          
          const { error: confirmError } = await supabaseAdmin.auth.admin.updateUserById(
            authUser.id,
            {
              email_confirm: true,
            }
          )

          if (confirmError) {
            logs.push(`Erro ao confirmar email: ${confirmError.message}`)
            resultados.push({
              email: recepcionista.email,
              nome: recepcionista.nome,
              status: `Erro ao confirmar email: ${confirmError.message}`,
              sucesso: false
            })
            continue
          }
          
          logs.push("Email confirmado com sucesso!")
        }

        // Verificar se precisa definir senha
        if (!authUser.encrypted_password) {
          logs.push("Definindo senha...")
          
          const { error: passwordError } = await supabaseAdmin.auth.admin.updateUserById(
            authUser.id,
            {
              password: "123456",
            }
          )

          if (passwordError) {
            logs.push(`Erro ao definir senha: ${passwordError.message}`)
            resultados.push({
              email: recepcionista.email,
              nome: recepcionista.nome,
              status: `Erro ao definir senha: ${passwordError.message}`,
              sucesso: false
            })
            continue
          }
          
          logs.push("Senha definida com sucesso!")
        }

        // Sincronizar ID na tabela usuarios
        logs.push("Sincronizando ID na tabela usuarios...")
        
        const { error: updateError } = await supabaseAdmin
          .from("usuarios")
          .update({ id: authUser.id })
          .eq("email", recepcionista.email)

        if (updateError) {
          logs.push(`Erro ao sincronizar ID: ${updateError.message}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Login OK mas erro ao sincronizar: ${updateError.message}`,
            sucesso: false
          })
          continue
        }

        logs.push("Sincronização concluída com sucesso!")
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: "Usuário sincronizado com sucesso! Senha: 123456",
          sucesso: true
        })

      } catch (error: any) {
        logs.push(`Erro inesperado para ${recepcionista.email}: ${error.message}`)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    logs.push(`\n=== RESULTADO FINAL ===`)
    logs.push(`Sucessos: ${sucessos}, Falhas: ${falhas}`)

    return NextResponse.json({
      success: true,
      message: `Sincronização concluída! ${sucessos} sucessos, ${falhas} falhas`,
      resultados,
      logs: logs.join('\n')
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 