import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

// Usar service_role key para ter permissões de admin
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    console.log("API chamada - redefinindo senha da Tatiana...")
    
    // Redefinir senha da Tatiana especificamente
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
      '051bdd17-c7c9-4bb8-b495-16250e91eab6', // ID da Tatiana
      {
        password: "123456", // Nova senha padrão
        email_confirm: true, // Confirmar email automaticamente
      }
    )

    if (updateError) {
      console.error("Erro ao redefinir senha:", updateError)
      return NextResponse.json({ 
        error: "Erro ao redefinir senha", 
        details: updateError.message 
      }, { status: 500 })
    }

    console.log("Senha redefinida com sucesso!")
    return NextResponse.json({ 
      success: true, 
      message: "Senha redefinida com sucesso! Nova senha: 123456"
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 