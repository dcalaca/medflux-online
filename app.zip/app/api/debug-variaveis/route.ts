import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("=== DEBUG VARIÁVEIS DE AMBIENTE ===")
    
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY
    
    console.log("NEXT_PUBLIC_SUPABASE_URL:", supabaseUrl)
    console.log("SUPABASE_SERVICE_ROLE_KEY:", serviceRoleKey ? "CONFIGURADO" : "NÃO CONFIGURADO")
    
    if (serviceRoleKey) {
      console.log("Service Role Key (primeiros 20 chars):", serviceRoleKey.substring(0, 20) + "...")
    }
    
    return NextResponse.json({ 
      success: true, 
      supabaseUrl: supabaseUrl ? "OK" : "FALTANDO",
      serviceRoleKey: serviceRoleKey ? "OK" : "FALTANDO",
      serviceRoleKeyLength: serviceRoleKey ? serviceRoleKey.length : 0
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 