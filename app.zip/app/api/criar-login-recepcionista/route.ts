import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o usuário é médico ou admin
    const { data: usuarioData, error: usuarioError } = await supabase
      .from("usuarios")
      .select("tipo")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuarioData) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (usuarioData.tipo !== "medico" && usuarioData.tipo !== "admin") {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 })
    }
    
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json({ error: "Email é obrigatório" }, { status: 400 })
    }

    // Buscar usuário na tabela usuarios
    const { data: usuarioExistente, error: buscaError } = await supabase
      .from("usuarios")
      .select("*")
      .eq("email", email)
      .eq("tipo", "recepcionista")
      .single()

    if (buscaError || !usuarioExistente) {
      return NextResponse.json({ error: "Recepcionista não encontrado" }, { status: 404 })
    }

    // Verificar se já existe no Auth
    const { data: authUser } = await supabase.auth.admin.listUsers()
    const userExists = authUser.users.find(u => u.email === email)

    if (userExists) {
      return NextResponse.json({ error: "Usuário já existe no sistema de autenticação" }, { status: 400 })
    }

    // Criar usuário no Auth com senha padrão
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: usuarioExistente.email,
      password: "123456", // Senha padrão
      email_confirm: true,
      user_metadata: {
        nome: usuarioExistente.nome,
        telefone: usuarioExistente.telefone,
      },
    })

    if (authError) {
      console.error("Erro ao criar usuário no Auth:", authError)
      return NextResponse.json({ 
        error: "Erro ao criar usuário no Auth", 
        details: authError.message 
      }, { status: 500 })
    }

    if (!authData.user) {
      return NextResponse.json({ error: "Falha ao criar usuário no Auth" }, { status: 500 })
    }

    // Atualizar o ID na tabela usuarios para corresponder ao Auth
    const { error: updateError } = await supabase
      .from("usuarios")
      .update({ id: authData.user.id })
      .eq("email", email)

    if (updateError) {
      console.error("Erro ao atualizar ID:", updateError)
      return NextResponse.json({ 
        error: "Erro ao sincronizar usuário", 
        details: updateError.message 
      }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true, 
      message: "Login criado com sucesso! Senha padrão: 123456",
      user: {
        id: authData.user.id,
        email: authData.user.email,
        nome: usuarioExistente.nome
      }
    })
  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 