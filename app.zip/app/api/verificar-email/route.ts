import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json({ error: "Email é obrigatório" }, { status: 400 })
    }

    // Verificar se o email já existe na tabela usuarios
    const { data: existingUser } = await supabase
      .from("usuarios")
      .select("id, nome, tipo, ativo")
      .eq("email", email)
      .single()

    if (existingUser) {
      return NextResponse.json({ 
        exists: true,
        user: existingUser,
        message: `O email ${email} já está cadastrado para ${existingUser.nome} (${existingUser.tipo})`
      })
    }

    return NextResponse.json({ 
      exists: false,
      message: "Email disponível para cadastro"
    })
  } catch (error) {
    console.error("Erro na API de verificação de email:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 