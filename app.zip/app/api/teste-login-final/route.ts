import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const supabaseAnon = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== TESTE FINAL DE LOGIN DA TATIANA ===")

    // 1. Verificar se a Tatiana existe via Admin API
    logs.push("\n--- VERIFICANDO VIA ADMIN API ---")
    const { data: adminUsers, error: adminError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (adminError) {
      logs.push(`❌ Erro Admin API: ${adminError.message}`)
    } else {
      logs.push(`📊 Total de usuários Admin: ${adminUsers.users.length}`)
      logs.push(`📧 Emails Admin: ${adminUsers.users.map(u => u.email).join(', ')}`)
      
      const tatianaAdmin = adminUsers.users.find(u => u.email === 'tatianag.calaca@gmail.com')
      if (tatianaAdmin) {
        logs.push(`✅ Tatiana encontrada via Admin: ${tatianaAdmin.id}`)
        logs.push(`📧 Email: ${tatianaAdmin.email}`)
        logs.push(`✅ Email confirmado: ${tatianaAdmin.email_confirmed_at ? 'SIM' : 'NÃO'}`)
        logs.push(`🔐 Tem senha: ${(tatianaAdmin as any).encrypted_password ? 'SIM' : 'NÃO'}`)
      } else {
        logs.push(`❌ Tatiana NÃO encontrada via Admin`)
      }
    }

    // 2. Tentar login via Anon API
    logs.push("\n--- TESTANDO LOGIN VIA ANON API ---")
    const { data: signInData, error: signInError } = await supabaseAnon.auth.signInWithPassword({
      email: 'tatianag.calaca@gmail.com',
      password: '123456'
    })

    if (signInError) {
      logs.push(`❌ Erro no login: ${signInError.message}`)
      logs.push(`🔍 Código do erro: ${signInError.status}`)
      logs.push(`🔍 Nome do erro: ${signInError.name}`)
    } else {
      logs.push(`✅ Login funcionou!`)
      logs.push(`👤 User ID: ${signInData.user?.id}`)
      logs.push(`📧 Email: ${signInData.user?.email}`)
      logs.push(`✅ Email confirmado: ${signInData.user?.email_confirmed_at ? 'SIM' : 'NÃO'}`)
    }

    // 3. Verificar configurações do Supabase
    logs.push("\n--- VERIFICANDO CONFIGURAÇÕES ---")
    logs.push(`🔗 URL: ${process.env.NEXT_PUBLIC_SUPABASE_URL}`)
    logs.push(`🔑 Anon Key: ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? 'PRESENTE' : 'AUSENTE'}`)
    logs.push(`📏 Anon Key Length: ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.length || 0}`)

    // 4. Tentar obter sessão atual
    logs.push("\n--- VERIFICANDO SESSÃO ATUAL ---")
    const { data: sessionData, error: sessionError } = await supabaseAnon.auth.getSession()
    
    if (sessionError) {
      logs.push(`❌ Erro na sessão: ${sessionError.message}`)
    } else {
      logs.push(`📊 Sessão: ${sessionData.session ? 'ATIVA' : 'INATIVA'}`)
      if (sessionData.session) {
        logs.push(`👤 User ID na sessão: ${sessionData.session.user.id}`)
      }
    }

    return NextResponse.json({
      success: true,
      message: "Teste final concluído",
      logs: logs.join('\n'),
      loginSuccess: !signInError,
      loginError: signInError ? signInError.message : null,
      user: signInData?.user || null,
      sessionActive: !!sessionData.session
    })

  } catch (error: any) {
    console.error("Erro na API:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: error.message
    }, { status: 500 })
  }
} 