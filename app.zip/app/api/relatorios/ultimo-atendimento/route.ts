import { createServerClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET() {
  const supabase = await createServerClient();

  // Buscar todos os pacientes
  const { data: pacientes, error: pacientesError } = await supabase
    .from("pacientes")
    .select("id, nome")
    .order("nome", { ascending: true });

  if (pacientesError) {
    return NextResponse.json({ error: pacientesError.message }, { status: 500 });
  }

  // Buscar últimas consultas de cada paciente
  const { data: consultas, error: consultasError } = await supabase
    .from("consultas")
    .select("id, paciente_id, data_hora, status, observacoes, tipo_consulta_id")
    .order("data_hora", { ascending: false });

  if (consultasError) {
    return NextResponse.json({ error: consultasError.message }, { status: 500 });
  }

  // Buscar tipos de consulta
  const { data: tipos, error: tiposError } = await supabase
    .from("tipos_consulta")
    .select("id, nome");

  if (tiposError) {
    return NextResponse.json({ error: tiposError.message }, { status: 500 });
  }

  // Montar relatório: para cada paciente, pegar a consulta mais recente
  const relatorio = pacientes.map((paciente) => {
    const ultimaConsulta = consultas.find((c) => c.paciente_id === paciente.id);
    const tipo = tipos.find((t) => t.id === ultimaConsulta?.tipo_consulta_id);
    return {
      paciente_id: paciente.id,
      paciente_nome: paciente.nome,
      data_hora: ultimaConsulta?.data_hora || null,
      status: ultimaConsulta?.status || null,
      observacoes: ultimaConsulta?.observacoes || null,
      tipo_consulta: tipo?.nome || null,
    };
  });

  return NextResponse.json({ relatorio });
} 