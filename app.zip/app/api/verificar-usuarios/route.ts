import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    console.log("=== VERIFICANDO USUÁRIOS ===")
    
    // Verificar usuários na tabela usuarios
    const { data: usuarios, error: usuariosError } = await supabaseAdmin
      .from("usuarios")
      .select("*")
      .eq("tipo", "recepcionista")
      .eq("ativo", true)

    if (usuariosError) {
      console.error("Erro ao buscar usuários:", usuariosError)
      return NextResponse.json({ error: "Erro ao buscar usuários" }, { status: 500 })
    }

    console.log("Usuários encontrados na tabela usuarios:", usuarios)

    // Verificar usuários no Auth
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers()

    if (authError) {
      console.error("Erro ao listar usuários do Auth:", authError)
      return NextResponse.json({ error: "Erro ao listar usuários do Auth" }, { status: 500 })
    }

    console.log("Usuários encontrados no Auth:", authUsers.users.map(u => ({ id: u.id, email: u.email })))

    // Verificar se os emails dos recepcionistas existem no Auth
    const emailsRecepcionistas = usuarios?.map(u => u.email) || []
    const emailsAuth = authUsers.users.map(u => u.email)

    const recepcionistasSemAuth = usuarios?.filter(u => !emailsAuth.includes(u.email)) || []

    return NextResponse.json({
      success: true,
      usuarios: usuarios,
      authUsers: authUsers.users.map(u => ({ id: u.id, email: u.email })),
      recepcionistasSemAuth: recepcionistasSemAuth,
      totalRecepcionistas: usuarios?.length || 0,
      totalAuthUsers: authUsers.users.length,
      recepcionistasSemAuthCount: recepcionistasSemAuth.length
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 