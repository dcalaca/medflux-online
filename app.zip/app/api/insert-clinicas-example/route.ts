import { createServerClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function POST() {
  try {
    const supabase = await createServerClient()
    
    // Inserir clínicas de exemplo
    const clinicasExemplo = [
      {
        id: 'f47ac10b-58cc-4372-a567-0e02b2c3d479',
        nome: 'Clínica Exemplo',
        endereco: 'Rua das Flores, 123 - Centro - São Paulo/SP',
        telefone: '(11) 99999-9999',
        email: 'contato@clinicaexemplo.com.br',
        cnpj: '12.345.678/0001-90'
      },
      {
        id: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
        nome: 'Clínica São Lucas',
        endereco: 'Av. Paulista, 1000 - Bela Vista - São Paulo/SP',
        telefone: '(11) 88888-8888',
        email: 'contato@saolucas.com.br',
        cnpj: '98.765.432/0001-10'
      },
      {
        id: 'b2c3d4e5-f6g7-8901-bcde-f23456789012',
        nome: 'Clínica Santa Maria',
        endereco: 'Rua Augusta, 500 - Consolação - São Paulo/SP',
        telefone: '(11) 77777-7777',
        email: 'contato@santamaria.com.br',
        cnpj: '11.222.333/0001-44'
      }
    ]

    const { data, error } = await supabase
      .from("clinicas")
      .upsert(clinicasExemplo as any, { 
        onConflict: 'id',
        ignoreDuplicates: false 
      })

    if (error) {
      return NextResponse.json({ 
        error: "Erro ao inserir clínicas", 
        details: error 
      }, { status: 500 })
    }

    // Buscar clínicas para verificar
    const { data: clinicas, error: errorBusca } = await supabase
      .from("clinicas")
      .select("*")
      .order("nome")

    if (errorBusca) {
      return NextResponse.json({ 
        error: "Erro ao buscar clínicas", 
        details: errorBusca 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Clínicas inseridas com sucesso",
      totalClinicas: clinicas?.length || 0,
      clinicas: clinicas || []
    })

  } catch (error) {
    return NextResponse.json({ 
      error: "Erro interno do servidor", 
      details: error 
    }, { status: 500 })
  }
} 