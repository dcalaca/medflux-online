import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

// Usar service_role key para ter permissões de admin
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    console.log("Redefinindo senhas dos recepcionistas...")
    
    // Lista de recepcionistas para redefinir senha
    const recepcionistas = [
      {
        id: '051bdd17-c7c9-4bb8-b495-16250e91eab6',
        email: 'tatianag.calaca@gmail.com',
        nome: 'Tatiana Calaça'
      },
      {
        id: '23dcfd03-1f0c-44e1-a28c-99ff6309363e',
        email: 'recepcionista@teste.com',
        nome: 'Teste Recepcionista'
      }
    ]

    const resultados = []

    for (const recepcionista of recepcionistas) {
      try {
        console.log(`Redefinindo senha para ${recepcionista.email}...`)
        
        // Redefinir senha do usuário no Auth
        const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
          recepcionista.id,
          {
            password: "123456", // Nova senha padrão
            email_confirm: true, // Confirmar email automaticamente
          }
        )

        if (updateError) {
          console.error(`Erro ao redefinir senha para ${recepcionista.email}:`, updateError)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Erro: ${updateError.message}`,
            sucesso: false
          })
          continue
        }

        console.log(`Senha redefinida com sucesso para ${recepcionista.email}`)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: "Senha redefinida com sucesso! Nova senha: 123456",
          sucesso: true
        })

      } catch (error: any) {
        console.error(`Erro inesperado para ${recepcionista.email}:`, error)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    console.log(`Processo concluído! ${sucessos} sucessos, ${falhas} falhas`)

    return NextResponse.json({ 
      success: true, 
      message: `Processo concluído! ${sucessos} sucessos, ${falhas} falhas`,
      resultados
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 