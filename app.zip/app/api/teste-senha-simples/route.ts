import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("API de teste chamada!")
    
    return NextResponse.json({ 
      success: true, 
      message: "API funcionando! Teste de conexão OK"
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 