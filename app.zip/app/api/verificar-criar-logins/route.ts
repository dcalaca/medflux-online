import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o usuário é médico ou admin
    const { data: usuarioData, error: usuarioError } = await supabase
      .from("usuarios")
      .select("tipo")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuarioData) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (usuarioData.tipo !== "medico" && usuarioData.tipo !== "adm") {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 })
    }

    // Buscar todos os recepcionistas na tabela usuarios
    const { data: recepcionistas, error: buscaError } = await supabase
      .from("usuarios")
      .select("*")
      .eq("tipo", "recepcionista")
      .eq("ativo", true)

    if (buscaError) {
      return NextResponse.json({ error: "Erro ao buscar recepcionistas" }, { status: 500 })
    }

    if (!recepcionistas || recepcionistas.length === 0) {
      return NextResponse.json({ message: "Nenhum recepcionista encontrado" })
    }

    console.log(`Encontrados ${recepcionistas.length} recepcionistas`)

    const resultados = []
    const emails = recepcionistas.map(r => r.email)

    // Verificar quais já existem no Auth
    const { data: authUsers } = await supabase.auth.admin.listUsers()
    const emailsExistentes = authUsers.users.map(u => u.email)

    for (const recepcionista of recepcionistas) {
      if (emailsExistentes.includes(recepcionista.email)) {
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: "Já existe no Auth",
          sucesso: true
        })
        continue
      }

      try {
        // Criar usuário no Auth
        const { data: authData, error: authError } = await supabase.auth.admin.createUser({
          email: recepcionista.email,
          password: "123456", // Senha padrão
          email_confirm: true,
          user_metadata: {
            nome: recepcionista.nome,
            telefone: recepcionista.telefone,
          },
        })

        if (authError) {
          console.error(`Erro ao criar ${recepcionista.email}:`, authError)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Erro: ${authError.message}`,
            sucesso: false
          })
          continue
        }

        if (!authData.user) {
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Falha ao criar usuário no Auth",
            sucesso: false
          })
          continue
        }

        // Atualizar o ID na tabela usuarios
        const { error: updateError } = await supabase
          .from("usuarios")
          .update({ id: authData.user.id })
          .eq("email", recepcionista.email)

        if (updateError) {
          console.error(`Erro ao atualizar ID para ${recepcionista.email}:`, updateError)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Erro ao sincronizar: ${updateError.message}`,
            sucesso: false
          })
          continue
        }

        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: "Login criado com sucesso! Senha: 123456",
          sucesso: true
        })

      } catch (error: any) {
        console.error(`Erro inesperado para ${recepcionista.email}:`, error)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    return NextResponse.json({ 
      success: true, 
      message: `Processo concluído! ${sucessos} sucessos, ${falhas} falhas`,
      resultados
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 