import { createServerClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function DELETE(request: Request) {
  try {
    const supabase = await createServerClient()
    
    // Verificar autenticação
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Verificar se o usuário é médico
    const { data: usuarioLogado, error: errorUsuario } = await supabase
      .from("usuarios")
      .select("*")
      .eq("id", user.id as any)
      .single()

    if (errorUsuario || !usuarioLogado || (usuarioLogado as any).tipo !== "medico") {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Buscar o ID do usuário a ser excluído
    const { id } = await request.json()
    
    if (!id) {
      return NextResponse.json({ error: "ID do usuário é obrigatório" }, { status: 400 })
    }

    // Verificar se o usuário existe e pertence à mesma clínica
    const { data: usuarioParaExcluir, error: errorBusca } = await supabase
      .from("usuarios")
      .select("*")
      .eq("id", id)
      .single()

    if (errorBusca || !usuarioParaExcluir) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    // Verificar se pertence à mesma clínica
    if ((usuarioParaExcluir as any).clinica_id !== (usuarioLogado as any).clinica_id) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Não permitir excluir a si mesmo
    if (id === user.id) {
      return NextResponse.json({ error: "Não é possível excluir a si mesmo" }, { status: 400 })
    }

    // Primeiro: Excluir do Auth (Supabase Auth)
    // Nota: Esta operação pode requerer permissões de admin no Supabase
    try {
      // Tentar excluir do Auth (pode falhar se não tiver permissões)
      const { error: authError } = await supabase.auth.admin.deleteUser(id)
      if (authError) {
        console.warn("Aviso: Não foi possível excluir do Auth:", authError)
        // Continuar mesmo se falhar no Auth, pois pode ser uma limitação de permissões
      }
    } catch (authError) {
      console.warn("Aviso: Não foi possível excluir do Auth:", authError)
      // Continuar mesmo se falhar no Auth
    }

    // Segundo: Excluir da tabela usuarios
    const { error: errorExclusao } = await supabase
      .from("usuarios")
      .delete()
      .eq("id", id)

    if (errorExclusao) {
      console.error("Erro ao excluir usuário da tabela:", errorExclusao)
      return NextResponse.json({ 
        error: "Erro ao excluir usuário da tabela", 
        details: errorExclusao 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Usuário excluído com sucesso"
    })

  } catch (error) {
    console.error("Erro interno:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor", 
      details: error 
    }, { status: 500 })
  }
} 