import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()

    if (userAuthError || !user) {
      return NextResponse.json({ 
        error: "Usuário não autenticado",
        code: "NOT_AUTHENTICATED"
      }, { status: 401 })
    }

    // Buscar dados do usuário
    const { data: usuario, error: usuarioError } = await supabase
      .from("usuarios")
      .select("id, nome, email, tipo, ativo, status_conta, dias_teste_restantes, data_inicio_teste")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuario) {
      return NextResponse.json({ 
        error: "Usuário não encontrado",
        code: "USER_NOT_FOUND"
      }, { status: 404 })
    }

    // Verificar se o usuário está ativo
    if (!usuario.ativo) {
      return NextResponse.json({ 
        error: "Conta desativada",
        code: "ACCOUNT_DISABLED",
        details: "Sua conta foi desativada. Entre em contato com o suporte."
      }, { status: 403 })
    }

    // Verificar status da conta
    if (usuario.status_conta === 'expirado') {
      return NextResponse.json({ 
        error: "Período gratuito expirado",
        code: "TRIAL_EXPIRED",
        details: "Seu período gratuito expirou. Renove sua assinatura para continuar usando o sistema.",
        dias_restantes: 0
      }, { status: 403 })
    }

    // Verificar dias restantes do teste
    if (usuario.status_conta === 'teste' && usuario.dias_teste_restantes !== null) {
      if (usuario.dias_teste_restantes <= 0) {
        // Bloquear usuário automaticamente
        await supabase
          .from("usuarios")
          .update({ 
            status_conta: 'expirado',
            ativo: false,
            updated_at: new Date().toISOString()
          })
          .eq("id", usuario.id)

        return NextResponse.json({ 
          error: "Período gratuito expirado",
          code: "TRIAL_EXPIRED",
          details: "Seu período gratuito expirou. Renove sua assinatura para continuar usando o sistema.",
          dias_restantes: 0
        }, { status: 403 })
      }

      if (usuario.dias_teste_restantes <= 7) {
        return NextResponse.json({ 
          success: true,
          warning: true,
          message: `Seu período gratuito expira em ${usuario.dias_teste_restantes} dias`,
          dias_restantes: usuario.dias_teste_restantes,
          usuario: {
            id: usuario.id,
            nome: usuario.nome,
            email: usuario.email,
            tipo: usuario.tipo,
            status_conta: usuario.status_conta
          }
        })
      }
    }

    // Usuário tem acesso
    return NextResponse.json({ 
      success: true,
      message: "Acesso permitido",
      dias_restantes: usuario.dias_teste_restantes,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        tipo: usuario.tipo,
        status_conta: usuario.status_conta
      }
    })

  } catch (error) {
    console.error("Erro na verificação de acesso:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: String(error)
    }, { status: 500 })
  }
} 