import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

// Usar service_role key para ter permissões de admin
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, nome, telefone } = body

    if (!email || !nome) {
      return NextResponse.json({ error: "Email e nome são obrigatórios" }, { status: 400 })
    }

    // Verificar se o usuário já existe no Auth
    const { data: existingUser } = await supabaseAdmin.auth.admin.listUsers()
    const userExists = existingUser.users.find(u => u.email === email)

    if (userExists) {
      return NextResponse.json({ error: "Usuário já existe no Auth" }, { status: 400 })
    }

    // Criar usuário no Auth com senha padrão
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: "123456", // Senha padrão
      email_confirm: true,
      user_metadata: {
        nome,
        telefone,
      },
    })

    if (authError) {
      console.error("Erro ao criar usuário no Auth:", authError)
      return NextResponse.json({ 
        error: "Erro ao criar usuário no Auth", 
        details: authError.message 
      }, { status: 500 })
    }

    if (!authData.user) {
      return NextResponse.json({ error: "Falha ao criar usuário no Auth" }, { status: 500 })
    }

    console.log("Usuário criado no Auth:", authData.user.id)

    return NextResponse.json({ 
      success: true, 
      message: "Login criado com sucesso! Senha padrão: 123456",
      user: {
        id: authData.user.id,
        email: authData.user.email,
        nome
      }
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 