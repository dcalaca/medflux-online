import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    console.log("📊 Buscando estatísticas de dias de teste...")

    // 1. Buscar estatísticas gerais
    const { data: estatisticas, error: estatisticasError } = await supabase
      .rpc('estatisticas_dias_teste')

    if (estatisticasError) {
      console.error("Erro ao buscar estatísticas:", estatisticasError)
      return NextResponse.json({ 
        error: "Erro ao buscar estatísticas",
        details: estatisticasError.message
      }, { status: 500 })
    }

    // 2. Buscar usuários próximos do vencimento
    const { data: usuariosProximos, error: usuariosError } = await supabase
      .rpc('usuarios_proximos_vencimento')

    if (usuariosError) {
      console.error("Erro ao buscar usuários próximos:", usuariosError)
      return NextResponse.json({ 
        error: "Erro ao buscar usuários próximos",
        details: usuariosError.message
      }, { status: 500 })
    }

    // 3. Buscar todos os usuários com detalhes
    const { data: todosUsuarios, error: todosError } = await supabase
      .from("usuarios")
      .select("id, nome, email, data_inicio_teste, dias_teste_restantes, status_conta")
      .not("data_inicio_teste", "is", null)
      .order("dias_teste_restantes", { ascending: true })

    if (todosError) {
      console.error("Erro ao buscar todos os usuários:", todosError)
      return NextResponse.json({ 
        error: "Erro ao buscar usuários",
        details: todosError.message
      }, { status: 500 })
    }

    // 4. Calcular estatísticas adicionais
    const estatisticasAdicionais = {
      total_usuarios: todosUsuarios?.length || 0,
      usuarios_ativos: todosUsuarios?.filter(u => u.dias_teste_restantes > 7).length || 0,
      usuarios_expirando: todosUsuarios?.filter(u => u.dias_teste_restantes >= 1 && u.dias_teste_restantes <= 7).length || 0,
      usuarios_expirados: todosUsuarios?.filter(u => u.dias_teste_restantes === 0).length || 0,
      media_dias_restantes: todosUsuarios?.length ? 
        todosUsuarios.reduce((acc, u) => acc + (u.dias_teste_restantes || 0), 0) / todosUsuarios.length : 0
    }

    console.log("📈 Estatísticas obtidas com sucesso")

    return NextResponse.json({ 
      success: true,
      estatisticas: estatisticas?.[0] || estatisticasAdicionais,
      usuarios_proximos_vencimento: usuariosProximos || [],
      todos_usuarios: todosUsuarios?.map(u => ({
        ...u,
        status_teste: u.dias_teste_restantes === 0 ? 'EXPIRADO' : 
                     u.dias_teste_restantes <= 7 ? 'EXPIRANDO' : 'ATIVO'
      })) || [],
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error("Erro na API de estatísticas:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: String(error)
    }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    console.log("🔄 Atualizando dias de teste via API...")

    // Executar função de atualização
    const { data: resultado, error: updateError } = await supabase
      .rpc('atualizar_dias_teste_completo')

    if (updateError) {
      console.error("Erro ao atualizar dias de teste:", updateError)
      return NextResponse.json({ 
        error: "Erro ao atualizar dias de teste",
        details: updateError.message
      }, { status: 500 })
    }

    console.log("✅ Dias de teste atualizados com sucesso")

    return NextResponse.json({ 
      success: true,
      message: "Dias de teste atualizados com sucesso",
      resultado,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error("Erro na API de atualização:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: String(error)
    }, { status: 500 })
  }
} 