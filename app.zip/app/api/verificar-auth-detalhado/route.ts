import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    console.log("=== VERIFICAÇÃO DETALHADA DO AUTH ===")
    
    // Buscar todos os usuários do Auth
    const { data: authUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      console.error("Erro ao listar usuários:", listError)
      return NextResponse.json({ error: "Erro ao listar usuários" }, { status: 500 })
    }

    console.log(`Total de usuários encontrados: ${authUsers.users.length}`)
    
    // Listar todos os usuários com detalhes
    const usuariosDetalhados = authUsers.users.map(user => ({
      id: user.id,
      email: user.email,
      email_confirmed: user.email_confirmed_at ? true : false,
      created_at: user.created_at,
      last_sign_in: user.last_sign_in_at,
      providers: user.app_metadata?.providers || []
    }))

    console.log("Usuários detalhados:", usuariosDetalhados)

    // Verificar especificamente os recepcionistas
    const recepcionistas = [
      'tatianag.calaca@gmail.com',
      'recepcionista@teste.com'
    ]

    const recepcionistasEncontrados = authUsers.users.filter(user => 
      user.email && recepcionistas.includes(user.email)
    )

    console.log(`Recepcionistas encontrados: ${recepcionistasEncontrados.length}`)

    return NextResponse.json({
      success: true,
      total_usuarios: authUsers.users.length,
      usuarios_detalhados: usuariosDetalhados,
      recepcionistas_encontrados: recepcionistasEncontrados.map(user => ({
        id: user.id,
        email: user.email,
        email_confirmed: user.email_confirmed_at ? true : false,
        created_at: user.created_at
      })),
      emails_todos: authUsers.users.map(u => u.email).filter(Boolean)
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 