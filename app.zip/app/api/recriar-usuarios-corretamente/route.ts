import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== RECRIANDO USUÁRIOS CORRETAMENTE ===")
    
    const recepcionistas = [
      {
        email: 'tatianag.calaca@gmail.com',
        nome: 'Tatiana Calaça'
      },
      {
        email: 'recepcionista@teste.com',
        nome: 'Teste Recepcionista'
      }
    ]

    const resultados = []

    for (const recepcionista of recepcionistas) {
      try {
        logs.push(`\n--- Processando ${recepcionista.email} ---`)
        
        // Primeiro, tentar deletar se existir
        logs.push("Verificando se usuário existe...")
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers()
        const existingUser = existingUsers.users.find(u => u.email === recepcionista.email)
        
        if (existingUser) {
          logs.push(`Usuário existe com ID: ${existingUser.id}, deletando...`)
          
          const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(existingUser.id)
          
          if (deleteError) {
            logs.push(`Erro ao deletar: ${deleteError.message}`)
            resultados.push({
              email: recepcionista.email,
              nome: recepcionista.nome,
              status: `Erro ao deletar usuário existente: ${deleteError.message}`,
              sucesso: false
            })
            continue
          }
          
          logs.push("Usuário deletado com sucesso")
        } else {
          logs.push("Usuário não existe, criando novo...")
        }

        // Aguardar um pouco para garantir que a deleção foi processada
        await new Promise(resolve => setTimeout(resolve, 1000))

        // Criar usuário corretamente
        logs.push("Criando usuário corretamente...")
        
        const { data: authData, error: createError } = await supabaseAdmin.auth.admin.createUser({
          email: recepcionista.email,
          password: "123456",
          email_confirm: true,
          user_metadata: {
            nome: recepcionista.nome,
          },
        })

        if (createError) {
          logs.push(`Erro ao criar usuário: ${createError.message}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Erro ao criar usuário: ${createError.message}`,
            sucesso: false
          })
          continue
        }

        if (!authData.user) {
          logs.push("Falha ao criar usuário")
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Falha ao criar usuário no Auth",
            sucesso: false
          })
          continue
        }

        logs.push(`Usuário criado com sucesso! ID: ${authData.user.id}`)

        // Sincronizar com a tabela usuarios
        logs.push("Sincronizando com tabela usuarios...")
        
        const { error: updateError } = await supabaseAdmin
          .from("usuarios")
          .update({ id: authData.user.id })
          .eq("email", recepcionista.email)

        if (updateError) {
          logs.push(`Erro ao sincronizar: ${updateError.message}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Login criado mas erro ao sincronizar: ${updateError.message}`,
            sucesso: false
          })
          continue
        }

        logs.push("Sincronização concluída com sucesso!")
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: "Usuário recriado com sucesso! Senha: 123456",
          sucesso: true
        })

      } catch (error: any) {
        logs.push(`Erro inesperado para ${recepcionista.email}: ${error.message}`)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    logs.push(`\n=== RESULTADO FINAL ===`)
    logs.push(`Sucessos: ${sucessos}, Falhas: ${falhas}`)

    return NextResponse.json({
      success: true,
      message: `Recriação concluída! ${sucessos} sucessos, ${falhas} falhas`,
      resultados,
      logs: logs.join('\n')
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 