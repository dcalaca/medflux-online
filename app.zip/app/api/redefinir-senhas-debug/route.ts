import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

// Usar service_role key para ter permissões de admin
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const logs = []
    logs.push("=== DEBUG REDEFINIR SENHAS ===")
    
    // Lista de recepcionistas para redefinir senha
    const recepcionistas = [
      {
        id: '051bdd17-c7c9-4bb8-b495-16250e91eab6',
        email: 'tatianag.calaca@gmail.com',
        nome: 'Tatiana Calaça'
      },
      {
        id: '23dcfd03-1f0c-44e1-a28c-99ff6309363e',
        email: 'recepcionista@teste.com',
        nome: 'Teste Recepcionista'
      }
    ]

    const resultados = []

    for (const recepcionista of recepcionistas) {
      try {
        logs.push(`\n--- Testando ${recepcionista.email} ---`)
        logs.push(`ID: ${recepcionista.id}`)
        
        // Primeiro verificar se o usuário existe
        const { data: existingUser, error: listError } = await supabaseAdmin.auth.admin.listUsers()
        
        if (listError) {
          logs.push(`Erro ao listar usuários: ${listError.message}`)
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: `Erro ao listar usuários: ${listError.message}`,
            sucesso: false
          })
          continue
        }

        const userExists = existingUser.users.find(u => u.id === recepcionista.id)
        logs.push(`Usuário existe no Auth: ${userExists ? "SIM" : "NÃO"}`)
        
        if (!userExists) {
          logs.push("Usuário não existe no Auth, criando...")
          
          // Criar usuário no Auth
          const { data: authData, error: createError } = await supabaseAdmin.auth.admin.createUser({
            email: recepcionista.email,
            password: "123456",
            email_confirm: true,
            user_metadata: {
              nome: recepcionista.nome,
            },
          })

          if (createError) {
            logs.push(`Erro ao criar usuário: ${createError.message}`)
            resultados.push({
              email: recepcionista.email,
              nome: recepcionista.nome,
              status: `Erro ao criar usuário: ${createError.message}`,
              sucesso: false
            })
            continue
          }

          logs.push("Usuário criado com sucesso!")
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Usuário criado com sucesso! Senha: 123456",
            sucesso: true
          })
        } else {
          logs.push("Usuário já existe, redefinindo senha...")
          
          // Redefinir senha do usuário existente
          const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
            recepcionista.id,
            {
              password: "123456",
              email_confirm: true,
            }
          )

          if (updateError) {
            logs.push(`Erro ao redefinir senha: ${updateError.message}`)
            resultados.push({
              email: recepcionista.email,
              nome: recepcionista.nome,
              status: `Erro ao redefinir senha: ${updateError.message}`,
              sucesso: false
            })
            continue
          }

          logs.push("Senha redefinida com sucesso!")
          resultados.push({
            email: recepcionista.email,
            nome: recepcionista.nome,
            status: "Senha redefinida com sucesso! Nova senha: 123456",
            sucesso: true
          })
        }

      } catch (error: any) {
        logs.push(`Erro inesperado para ${recepcionista.email}: ${error.message}`)
        resultados.push({
          email: recepcionista.email,
          nome: recepcionista.nome,
          status: `Erro inesperado: ${error.message}`,
          sucesso: false
        })
      }
    }

    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length

    logs.push(`\n=== RESULTADO FINAL ===`)
    logs.push(`Sucessos: ${sucessos}, Falhas: ${falhas}`)

    return NextResponse.json({ 
      success: true, 
      message: `Processo concluído! ${sucessos} sucessos, ${falhas} falhas`,
      resultados,
      logs: logs.join('\n')
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 