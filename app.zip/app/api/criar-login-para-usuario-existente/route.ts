import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Verificar se o usuário está autenticado
    const { data: { user }, error: userAuthError } = await supabase.auth.getUser()
    
    if (userAuthError || !user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o usuário é médico (pode cadastrar recepcionistas)
    const { data: usuarioData, error: usuarioError } = await supabase
      .from("usuarios")
      .select("tipo, clinica_id")
      .eq("id", user.id)
      .single()

    if (usuarioError || !usuarioData) {
      console.error("Erro ao buscar usuário:", usuarioError)
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (usuarioData.tipo !== "medico" && usuarioData.tipo !== "adm") {
      return NextResponse.json({ error: "Sem permissão para cadastrar usuários" }, { status: 403 })
    }
    
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json({ error: "Email é obrigatório" }, { status: 400 })
    }

    console.log(`Criando login para usuário existente: ${email}`)

    // 1. Buscar usuário na tabela usuarios
    const { data: existingUser, error: userError } = await supabase
      .from("usuarios")
      .select("id, nome, telefone, tipo, clinica_id")
      .eq("email", email)
      .single()

    if (userError || !existingUser) {
      return NextResponse.json({ 
        error: "Usuário não encontrado na tabela usuarios",
        details: `Email ${email} não encontrado`
      }, { status: 404 })
    }

    console.log(`Usuário encontrado: ${existingUser.nome} (${existingUser.tipo})`)

    // 2. Verificar se já tem Auth
    try {
      const { data: authUser } = await supabase.auth.admin.getUserById(existingUser.id)
      
      if (authUser.user) {
        return NextResponse.json({ 
          error: "Usuário já possui login",
          details: `O usuário ${existingUser.nome} já possui uma conta de autenticação`
        }, { status: 400 })
      }
    } catch (error) {
      // Se não encontrou no Auth, continuar com a criação
      console.log("Usuário não encontrado no Auth, criando...")
    }

    // 3. Criar usuário no Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: email,
      password: "123456", // Senha padrão
      email_confirm: false, // NÃO confirmar automaticamente - deixar ela confirmar
      user_metadata: {
        nome: existingUser.nome,
        tipo: existingUser.tipo,
        clinica_id: existingUser.clinica_id
      }
    })

    if (authError) {
      console.error("Erro ao criar usuário no Auth:", authError)
      return NextResponse.json({ 
        error: "Erro ao criar usuário no sistema de autenticação",
        details: authError.message
      }, { status: 500 })
    }

    console.log("Usuário criado no Auth:", authData.user?.id)

    // 4. Atualizar o ID na tabela usuarios para usar o mesmo ID do Auth
    const { error: updateError } = await supabase
      .from("usuarios")
      .update({
        id: authData.user!.id,
        updated_at: new Date().toISOString(),
      })
      .eq("email", email)

    if (updateError) {
      console.error("Erro ao atualizar ID do usuário:", updateError)
      
      // Se falhou na atualização, tentar remover do Auth
      try {
        await supabase.auth.admin.deleteUser(authData.user!.id)
      } catch (deleteError) {
        console.error("Erro ao remover usuário do Auth após falha:", deleteError)
      }
      
      return NextResponse.json({ 
        error: "Erro ao atualizar dados do usuário", 
        details: updateError.message
      }, { status: 500 })
    }

    console.log("Login criado com sucesso para:", existingUser.nome)

    return NextResponse.json({ 
      success: true, 
      message: `Login criado com sucesso para ${existingUser.nome}! Um email de confirmação foi enviado para ${email}. A senha padrão é: 123456`,
      user: existingUser,
      authUser: authData.user
    })
  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 