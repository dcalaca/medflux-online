import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("Testando conexão com Supabase...")
    
    // Usar service_role key para ter permissões de admin
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    )

    // Testar listar usuários
    const { data: users, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      console.error("Erro ao listar usuários:", listError)
      return NextResponse.json({ 
        error: "Erro ao conectar com Supabase", 
        details: listError.message 
      }, { status: 500 })
    }

    console.log("Conexão com Supabase OK!")
    console.log("Usuários encontrados:", users.users.length)

    return NextResponse.json({ 
      success: true, 
      message: "Conexão com Supabase funcionando!",
      usersCount: users.users.length
    })

  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
} 