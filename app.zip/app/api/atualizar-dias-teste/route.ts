import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    console.log("🔄 Iniciando atualização de dias de teste...")

    // 1. Buscar todos os usuários com data_inicio_teste
    const { data: usuarios, error: usuariosError } = await supabase
      .from("usuarios")
      .select("id, nome, email, data_inicio_teste, dias_teste_restantes")
      .not("data_inicio_teste", "is", null)

    if (usuariosError) {
      console.error("Erro ao buscar usuários:", usuariosError)
      return NextResponse.json({ 
        error: "Erro ao buscar usuários",
        details: usuariosError.message
      }, { status: 500 })
    }

    console.log(`📊 Encontrados ${usuarios?.length || 0} usuários para atualizar`)

    const resultados = []
    const hoje = new Date()

    // 2. Calcular e atualizar dias restantes para cada usuário
    for (const usuario of usuarios || []) {
      try {
        const dataInicio = new Date(usuario.data_inicio_teste)
        const diffMs = hoje.getTime() - dataInicio.getTime()
        const diasPassados = Math.floor(diffMs / (1000 * 60 * 60 * 24))
        const diasRestantes = Math.max(0, 30 - diasPassados)

        // 3. Atualizar na tabela
        const { error: updateError } = await supabase
          .from("usuarios")
          .update({ 
            dias_teste_restantes: diasRestantes,
            updated_at: new Date().toISOString()
          })
          .eq("id", usuario.id)

        if (updateError) {
          console.error(`❌ Erro ao atualizar usuário ${usuario.email}:`, updateError)
          resultados.push({
            id: usuario.id,
            email: usuario.email,
            sucesso: false,
            erro: updateError.message,
            dias_passados: diasPassados,
            dias_restantes: diasRestantes
          })
        } else {
          console.log(`✅ Usuário ${usuario.email}: ${diasPassados} dias passados, ${diasRestantes} dias restantes`)
          resultados.push({
            id: usuario.id,
            email: usuario.email,
            sucesso: true,
            dias_passados: diasPassados,
            dias_restantes: diasRestantes
          })
        }
      } catch (error) {
        console.error(`❌ Erro ao processar usuário ${usuario.email}:`, error)
        resultados.push({
          id: usuario.id,
          email: usuario.email,
          sucesso: false,
          erro: String(error)
        })
      }
    }

    // 4. Estatísticas
    const sucessos = resultados.filter(r => r.sucesso).length
    const falhas = resultados.filter(r => !r.sucesso).length
    const total = resultados.length

    console.log(`📈 Atualização concluída: ${sucessos} sucessos, ${falhas} falhas de ${total} usuários`)

    return NextResponse.json({ 
      success: true,
      message: `Atualização concluída: ${sucessos} sucessos, ${falhas} falhas`,
      estatisticas: {
        total,
        sucessos,
        falhas
      },
      resultados
    })

  } catch (error) {
    console.error("Erro na API de atualização:", error)
    return NextResponse.json({ 
      error: "Erro interno do servidor",
      details: String(error)
    }, { status: 500 })
  }
} 