import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock } from "lucide-react"
import Link from "next/link"

export default function PagamentoPendentePage() {
  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto">
        <Card className="text-center">
          <CardHeader className="pb-4">
            <div className="mx-auto w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
            <CardTitle className="text-2xl text-yellow-800">Pagamento Pendente</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <p className="text-gray-600">Seu pagamento está sendo processado.</p>
              <p className="text-gray-600">Você receberá uma confirmação em breve.</p>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <p className="text-blue-800 font-medium">⏳ Aguardando confirmação</p>
              <p className="text-blue-700 text-sm">O processamento pode levar alguns minutos</p>
            </div>

            <Button asChild className="w-full">
              <Link href="/dashboard">Ir para o Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
