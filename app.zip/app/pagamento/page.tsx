import DashboardLayout from "@/components/dashboard-layout"
import { PagamentoForm } from "@/components/pagamento-form"

export default function PagamentoPage() {
  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Ative seu Plano MedFlux</h1>
          <p className="text-gray-600">Comece a usar todos os recursos do sistema por apenas R$ 99/mês</p>
        </div>

        <PagamentoForm />
      </div>
    </DashboardLayout>
  )
}
