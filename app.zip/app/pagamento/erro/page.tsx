import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { XCircle } from "lucide-react"
import Link from "next/link"

export default function PagamentoErroPage() {
  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto">
        <Card className="text-center">
          <CardHeader className="pb-4">
            <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <CardTitle className="text-2xl text-red-800">Pagamento Não Aprovado</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <p className="text-gray-600">Houve um problema com seu pagamento.</p>
              <p className="text-gray-600">Verifique os dados do cartão e tente novamente.</p>
            </div>

            <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
              <p className="text-yellow-800 font-medium">💡 Dicas para resolver:</p>
              <ul className="text-yellow-700 text-sm mt-2 space-y-1">
                <li>• Verifique se o cartão tem limite disponível</li>
                <li>• Confirme se os dados estão corretos</li>
                <li>• Tente usar outro cartão</li>
              </ul>
            </div>

            <div className="flex gap-4">
              <Button asChild variant="outline" className="flex-1 bg-transparent">
                <Link href="/dashboard">Voltar ao Dashboard</Link>
              </Button>
              <Button asChild className="flex-1">
                <Link href="/pagamento">Tentar Novamente</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
