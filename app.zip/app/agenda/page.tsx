import { createServerClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { AgendaCalendar } from "@/components/agenda-calendar"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function AgendaPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: usuario, error: usuarioError } = await supabase.from("usuarios").select("*").eq("id", String(user.id)).single()

  const usuarioData = usuario as any;
  if (usuarioError || !usuarioData || (usuarioData.tipo !== "admin" && usuarioData.tipo !== "medico" && usuarioData.tipo !== "recepcionista")) {
    redirect("/dashboard")
  }

  // Buscar consultas do mês atual
  const hoje = new Date()
  const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1)
  const fimMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0)

  const { data: consultas, error: consultasError } = await supabase
    .from("consultas")
    .select(`
      *,
      pacientes (nome, telefone),
      tipos_consulta (nome, cor)
    `)
    .eq("medico_id", user.id)
    .eq("clinica_id", usuario.clinica_id)
    .gte("data_hora", inicioMes.toISOString())
    .lte("data_hora", fimMes.toISOString())
    .order("data_hora", { ascending: true })

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Agenda</h1>
            <p className="text-muted-foreground">Gerencie seus agendamentos e consultas</p>
          </div>
          <Button asChild>
            <Link href="/agenda/nova-consulta">
              <Plus className="w-4 h-4 mr-2" />
              Nova Consulta
            </Link>
          </Button>
        </div>

        <AgendaCalendar consultas={consultas || []} />
      </div>
    </DashboardLayout>
  )
}
