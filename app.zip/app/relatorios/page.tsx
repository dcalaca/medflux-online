import { TrialGuard } from "@/components/trial-guard"
import DashboardLayout from "@/components/dashboard-layout"
import { RelatoriosFinanceiros } from "@/components/relatorios-financeiros"

export default function RelatoriosPage() {
  return (
    <TrialGuard>
      <DashboardLayout>
        <RelatoriosFinanceiros />
      </DashboardLayout>
    </TrialGuard>
  )
}
