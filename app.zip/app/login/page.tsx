"use client"

export const dynamic = "force-dynamic"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, AlertCircle } from "lucide-react"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  // Verificar parâmetros da URL
  const confirmed = searchParams.get("confirmed")
  const error = searchParams.get("error")

  useEffect(() => {
    if (confirmed === "true") {
      toast({
        title: "Email confirmado com sucesso!",
        description: "Sua conta foi ativada. Agora você pode fazer login.",
      })
    }
    if (error === "confirmation_failed") {
      toast({
        title: "Erro na confirmação",
        description: "Não foi possível confirmar seu email. Tente novamente.",
        variant: "destructive",
      })
    }
  }, [confirmed, error, toast])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log("🔄 Iniciando processo de login...")
    setLoading(true)
    const supabase = createClient()

    try {
      console.log("📧 Email:", email)
      console.log("🔐 Tentando fazer login...")

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      console.log("📊 Resultado do login:", { data, error })

      if (error) {
        console.error("❌ Erro no login:", error)

        // Mensagens de erro mais específicas
        let errorMessage = error.message
        if (error.message.includes("Email not confirmed")) {
          errorMessage = "Por favor, confirme seu email antes de fazer login. Verifique sua caixa de entrada."
        } else if (error.message.includes("Invalid login credentials")) {
          errorMessage = "Email ou senha incorretos. Verifique seus dados e tente novamente."
        } else if (error.message.includes("Email link is invalid or has expired")) {
          errorMessage = "Link de confirmação expirado. Registre-se novamente."
        }

        toast({
          title: "Erro no login",
          description: errorMessage,
          variant: "destructive",
        })
        return
      }

      if (data.user) {
        console.log("✅ Usuário logado:", data.user.id)

        // Buscar perfil do usuário
        console.log("🔍 Buscando perfil do usuário...")
        const { data: usuario, error: userError } = await supabase
          .from("usuarios")
          .select("tipo, nome, clinica_id")
          .eq("id", data.user.id)
          .single()

        console.log("👤 Perfil do usuário:", { usuario, userError })

        if (userError) {
          console.error("❌ Erro ao buscar perfil:", userError)
          toast({
            title: "Erro ao carregar perfil",
            description: "Não foi possível carregar seus dados. Tente novamente.",
            variant: "destructive",
          })
          return
        }

        if (usuario) {
          console.log("🎯 Redirecionando usuário tipo:", usuario.tipo)

          toast({
            title: "Login realizado com sucesso!",
            description: `Bem-vindo, ${usuario.nome}!`,
          })

          // Redirecionar para dashboard
          console.log("🏥 Redirecionando para dashboard...")
          router.push("/dashboard")
          router.refresh()
        } else {
          console.error("❌ Perfil de usuário não encontrado")
          toast({
            title: "Erro no login",
            description: "Perfil de usuário não encontrado. Entre em contato com o suporte.",
            variant: "destructive",
          })
        }
      } else {
        console.error("❌ Dados do usuário não retornados")
        toast({
          title: "Erro no login",
          description: "Não foi possível fazer login. Tente novamente.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("💥 Erro inesperado no login:", error)
      toast({
        title: "Erro no login",
        description: "Ocorreu um erro inesperado. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      console.log("🏁 Finalizando processo de login...")
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <Image src="/logo.png" alt="MedFlux" width={200} height={60} className="mx-auto" />
          <h2 className="mt-6 text-3xl font-bold text-gray-900">Faça login em sua conta</h2>
          <p className="mt-2 text-sm text-gray-600">
            Ou{" "}
            <Link href="/registro" className="font-medium text-blue-600 hover:text-blue-500">
              registre-se gratuitamente
            </Link>
          </p>
        </div>

        {/* Alertas de confirmação */}
        {confirmed === "true" && (
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              Email confirmado com sucesso! Agora você pode fazer login.
            </AlertDescription>
          </Alert>
        )}

        {error === "confirmation_failed" && (
          <Alert className="border-red-200 bg-red-50" variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Erro na confirmação do email. Tente clicar no link novamente ou entre em contato com o suporte.
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Login</CardTitle>
            <CardDescription>Entre com seu e-mail e senha para acessar o sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="seu@email.com"
                  autoComplete="email"
                />
              </div>

              <div>
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Entrando..." : "Entrar"}
              </Button>
            </form>

            <div className="mt-4 text-center space-y-2">
              <p className="text-sm">
                <Link href="/esqueci-senha" className="font-medium text-blue-600 hover:text-blue-500">
                  Esqueci minha senha
                </Link>
              </p>
              <p className="text-sm text-gray-600">
                Não recebeu o email de confirmação?{" "}
                <button
                  type="button"
                  className="font-medium text-blue-600 hover:text-blue-500"
                  onClick={() => {
                    toast({
                      title: "Email de confirmação",
                      description: "Verifique sua caixa de entrada e spam. Se não encontrar, registre-se novamente.",
                    })
                  }}
                >
                  Clique aqui
                </button>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
